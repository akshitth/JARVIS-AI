@echo off
title J.A.R.V.I.S. - Just A Rather Very Intelligent System
cd /d "c:\Users\hp\OneDrive\Desktop\JARVIS"
echo Starting JARVIS... > launch.log
C:\Python312\python.exe -u main.py >> launch.log 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] JARVIS exited with error code %ERRORLEVEL% >> launch.log
)
