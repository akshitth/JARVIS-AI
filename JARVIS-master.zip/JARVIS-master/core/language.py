"""
J.A.R.V.I.S. — Language Detection for TTS

Two decisions live here.

reply_language() picks the language JARVIS ANSWERS in, from the user's own
words: English in, English out; Hindi or Hinglish in, Hinglish out.

pick_voice() then picks the voice from the reply's text. The British voice is
right for English but mispronounces Hindi words badly enough to be hard to
follow, so Hinglish lines go to an Indian-accented voice instead
(EDGE_TTS_VOICE_HI, see config.py for why Prabhat and not Madhur).

The threshold below is what keeps that from being annoying. A response is only
sent to the Indian voice when it is genuinely Hindi-leaning — one stray "hai"
in an English sentence must not flip the voice, because a voice that changes on
near-identical sentences is worse than either voice alone.

Setting TTS_AUTO_SWITCH_VOICE = False collapses this to a single voice, in
which case EDGE_TTS_VOICE_HI is used only for actual DEVANAGARI script, which
an English voice cannot pronounce at all.

Detection is deliberately lexical rather than statistical — responses are one
or two sentences, far too short for a language classifier to be reliable, and
a wordlist of romanized Hindi function words is both faster and more accurate
at that length.
"""

import re

from config import EDGE_TTS_VOICE_EN, EDGE_TTS_VOICE_HI, TTS_AUTO_SWITCH_VOICE

# Romanized Hindi function words. Content words (naam, ghar) are deliberately
# left out — function words are what actually signal that a sentence is Hindi.
_HINDI_MARKERS = {
    "hai", "hain", "hoon", "hun", "tha", "thi", "raha", "rahi",
    "rahe", "kar", "karo", "karna", "kiya", "karne", "kya", "kyun", "kaise",
    "kaisa", "kaisi", "kab", "kahan", "kaha", "kaun", "kitna", "kitni", "kitne",
    "mera", "meri", "mere", "aapka", "aapki", "aapke", "tumhara", "iska", "uska",
    "aap", "tum", "mai", "hum", "yeh", "ye", "wo", "woh", "koi", "kuch",
    "sab", "abhi", "aaj", "kal", "phir", "bhi", "toh", "se", "mein",
    "ke", "ka", "ki", "ko", "aur", "lekin", "magar", "nahi", "nahin",
    "haan", "ji", "bhai", "yaar", "acha", "accha", "theek", "thik", "bilkul",
    "zara", "jaldi", "der", "baje", "baad", "pehle", "liye", "wala", "wali",
    "diya", "dijiye", "dena", "lena", "gaya", "gayi", "chal", "chalo", "chala",
    "dekh", "dekho", "suno", "bata", "batao", "yaad", "bhool", "laga", "lagao",
    "khol", "kholo", "band", "raha", "hoga", "hogi", "honge", "sakta", "sakti",
    "chahiye", "milega", "rakh", "rakho", "samajh", "gaana", "gaane", "baarish",
    "ghante", "ghanta", "raat", "subah", "shaam", "mausam",
    # Verb endings and particles. A user's COMMAND is often English nouns with
    # only the verb in Hindi ("screenshot le lo", "volume badha do", "music
    # bajao"), and without these the reply language came out as English.
    "le", "lo", "lelo", "de", "dedo", "karde", "kardo", "karein", "kijiye",
    "dein", "badha", "badhao", "badhado", "sunao", "suna", "bajao", "baja",
    "bolo", "dikhao", "dikha", "hatao", "jao", "thoda", "zyada", "kam",
    "mujhe", "humein", "apna", "apni", "wapas", "namaste",
    # Ways of saying "never mind". "mat" is deliberately absent (English word).
    "rehne", "rahne", "chhodo", "chodo", "ruko", "ruk",
}
# Deliberately NOT markers, despite being real Hindi words: "the", "to", "me",
# "hi", "ho", "main", "par", "minute", "din". Each is also a common ENGLISH
# word, and on a one-sentence response those collisions were enough to send
# pure-English lines to the Hindi voice.

_WORD = re.compile(r"[a-zA-Z']+")
_DEVANAGARI = re.compile(r"[ऀ-ॿ]")

# Below this share of Hindi words the line is treated as English. One stray
# "hai" in an otherwise English sentence should not flip the voice.
_HINDI_THRESHOLD = 0.12


def hindi_ratio(text: str) -> float:
    """Share of words that are romanized Hindi markers (0.0 - 1.0)."""
    words = [w.lower() for w in _WORD.findall(text or "")]
    if not words:
        return 0.0
    return sum(1 for w in words if w in _HINDI_MARKERS) / len(words)


def is_hindi(text: str) -> bool:
    """True when this response should be spoken by the Hindi voice."""
    if not text:
        return False
    # Actual Devanagari is unambiguous.
    if _DEVANAGARI.search(text):
        return True
    return hindi_ratio(text) >= _HINDI_THRESHOLD


# Acknowledgements that carry no language of their own. "okay" after a Hindi
# command should keep the conversation in Hindi rather than flip to English.
_NEUTRAL_WORDS = {"ok", "okay", "okey", "hmm", "jarvis", "sir", "please"}


def reply_language(user_text: str, fallback: str = "hi") -> str:
    """Which language JARVIS should ANSWER this utterance in: "en" or "hi".

    The reply mirrors the user. Speak English and JARVIS answers in English
    (and so in the English voice); speak Hindi or Hinglish and it answers in
    Hinglish. Deciding on the user's words rather than on the reply is the whole
    point -- every reply used to be written in Hinglish, so the voice picker
    correctly heard Hindi and English questions got the Hindi voice.
    """
    words = [w.lower() for w in _WORD.findall(user_text or "")]
    if not words and not _DEVANAGARI.search(user_text or ""):
        return fallback
    if words and all(w in _NEUTRAL_WORDS for w in words):
        return fallback
    return "hi" if is_hindi(user_text) else "en"


def has_devanagari(text: str) -> bool:
    """True when the text contains Devanagari script the English voice can't read."""
    return bool(_DEVANAGARI.search(text or ""))


def pick_voice(text: str) -> str:
    """The edge-tts voice for this response.

    One voice for everything by default — see the module docstring.
    """
    if not TTS_AUTO_SWITCH_VOICE:
        return EDGE_TTS_VOICE_HI if has_devanagari(text) else EDGE_TTS_VOICE_EN
    return EDGE_TTS_VOICE_HI if is_hindi(text) else EDGE_TTS_VOICE_EN


def describe(text: str) -> str:
    """Short label explaining the voice choice, for the log line."""
    if not TTS_AUTO_SWITCH_VOICE:
        if has_devanagari(text):
            return "Devanagari script (English voice cannot read it)"
        return "single-voice mode"
    return "Hindi/Hinglish" if is_hindi(text) else "English"
