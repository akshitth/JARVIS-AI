"""
J.A.R.V.I.S. — Intent Dispatcher (local execution layer)

Gemini decides WHAT the user wants; everything here decides what actually
happens, and does it locally. The only intents that reach the network again
are `general_question` and open-ended `small_talk`, and even those check
memory.json first.

Four behaviours worth knowing about:

  LANGUAGE       Every reply mirrors the language of the utterance it answers:
                 English in, English out (and the English voice); Hindi or
                 Hinglish in, Hinglish out. Replies used to be Hinglish no
                 matter what, so an English question got the Hindi voice.
  CONFIRMATION   Risky intents (lock, shutdown, restart) never execute on the
                 first utterance. They ask "Sir, confirm kar dein?" and arm a
                 pending action that the next yes/no resolves.
  CLARIFICATION  A command missing its object ("call karo", "open") asks for
                 the missing piece instead of silently doing nothing, and the
                 answer is merged back into the original intent.
  DEFERRED WORK  Locking or shutting down mid-sentence would cut JARVIS off, so
                 the action is returned as `after_speaking` for the caller to
                 run once TTS has finished.
"""

import os
import re
import time

from config import CONFIRM_INTENTS
from core.language import reply_language
from skills.app_control import open_app, close_app, resolve_app
from skills.briefing import build_briefing
from skills.easter_eggs import execute_iron_man_easter_egg, play_arc_reactor_sound
from skills.lock_pc import execute_lock
from skills.media import play_music
from skills.persona import answer_question, small_talk
from skills.system_actions import (
    take_screenshot, set_volume, shutdown_pc, restart_pc,
)
from skills.system_info import get_system_info
from skills.time_date import get_time, get_date
from skills.web_search import web_search


def _log(msg):
    try:
        print(msg, flush=True)
    except UnicodeEncodeError:
        print(msg.encode("ascii", "replace").decode("ascii"), flush=True)


# ── Confirmation vocabulary (English + Hinglish) ─────
_YES = re.compile(
    r"^\s*(?:yes|yeah|yep|yup|ya|sure|ok|okay|okey|confirm(?:ed)?|do\s*it|go\s*ahead|"
    r"proceed|affirmative|please\s*do|haan|haa+n?|ha|ji|ji\s*haan|bilkul|theek\s*hai|"
    r"thik\s*hai|kar\s*do|kar\s*de|karo|chalo|done|absolutely)\b",
    re.IGNORECASE,
)
_NO = re.compile(
    r"^\s*(?:no|nope|nah|cancel|stop|abort|don'?t|do\s*not|negative|forget\s*it|"
    r"nahi+n?|nai|mat\s*kar\w*|rehne\s*do|rahne\s*do|ruk\s*(?:o|ja\w*)?|chhodo|chodo)\b",
    re.IGNORECASE,
)

CONFIRMATION_TIMEOUT = 30      # seconds a pending confirmation stays armed
CLARIFICATION_TIMEOUT = 30

# Bare verbs that mean nothing without an object. Rather than doing nothing,
# JARVIS asks for the missing half: (pattern, is_search, hinglish, english).
_INCOMPLETE = [
    (r"^\s*(?:call|phone|dial)\s*(?:kar\w*|karo|do|de)?\s*$", False,
     "Sir, kise call karna hai?", "Sir, who should I call?"),
    (r"^\s*(?:message|msg|text|whatsapp|sms)\s*(?:kar\w*|karo|do|de)?\s*$", False,
     "Sir, kise message karna hai?", "Sir, who should I message?"),
    (r"^\s*(?:e-?mail|mail)\s*(?:kar\w*|karo|do|de)?\s*$", False,
     "Sir, kise email karna hai?", "Sir, who should I email?"),
    (r"^\s*(?:search|google|dhoond\w*)\s*(?:kar\w*|karo|do|de)?\s*$", True,
     "Sir, kya search karna hai?", "Sir, what should I search for?"),
    (r"^\s*(?:open|khol\w*|chalu)\s*(?:kar\w*|karo|do|de)?\s*$", False,
     "Sir, kya open karna hai?", "Sir, what should I open?"),
    (r"^\s*(?:close|band)\s*(?:kar\w*|karo|do|de)?\s*$", False,
     "Sir, kya close karna hai?", "Sir, what should I close?"),
    (r"^\s*(?:remind\w*|reminder|yaad\s*dila\w*)\s*(?:kar\w*|karo|do|de)?\s*$", False,
     "Sir, kis cheez ka aur kitni der baad reminder set karun?",
     "Sir, what should I remind you about, and when?"),
    (r"^\s*(?:play|baja\w*|laga\s*do)\s*$", False,
     "Sir, kya play karun — music?", "Sir, what should I play — music?"),
]

# Which slot each intent needs filled before it can run: (slot, hinglish, english).
_REQUIRED_SLOT = {
    "open_app": ("app", "Sir, kaunsa app open karun?", "Sir, which app should I open?"),
    "close_app": ("app", "Sir, kaunsa app close karun?", "Sir, which app should I close?"),
    "web_search": ("query", "Sir, kya search karna hai?", "Sir, what should I search for?"),
    "remember": ("what", "Sir, kya yaad rakhna hai?", "Sir, what should I remember?"),
    "recall": ("what", "Sir, kya yaad dilaun?", "Sir, what should I recall?"),
    "forget": ("what", "Sir, kya bhoolna hai?", "Sir, what should I forget?"),
}

# Local answers for questions about the conversation itself — no API call.
_CONTEXT_QUESTIONS = re.compile(
    r"(?:what\s+did\s+i\s+(?:just\s+)?(?:ask|say)|maine\s+(?:abhi\s+)?kya\s+"
    r"(?:poocha|pucha|kaha|bola)|last\s+question|pichla\s+sawal)",
    re.IGNORECASE,
)


class Result:
    """The outcome of dispatching one intent."""

    __slots__ = ("speech", "action", "after_speaking", "awaiting", "hud_progress",
                 "sleep_after")

    def __init__(self, speech, action="", after_speaking=None, awaiting=None,
                 hud_progress=None, sleep_after=False):
        self.speech = speech                  # what JARVIS says
        self.action = action or "responding"  # the ACTION half of the log line
        self.after_speaking = after_speaking  # callable to run once TTS ends
        self.awaiting = awaiting              # "confirmation" | "clarification" | None
        self.hud_progress = hud_progress      # interim line to show while working
        # Terminal actions: once the PC is locked or going down there is nobody
        # to talk to, so JARVIS must drop to STANDBY rather than leave a live
        # mic running behind a lock screen.
        self.sleep_after = sleep_after

    def __repr__(self):
        return f"Result({self.action!r}, awaiting={self.awaiting})"


class Services:
    """Everything the dispatcher may need from the running app.

    All optional, so tests can construct a dispatcher with nothing wired up and
    still exercise the routing logic.
    """

    def __init__(self, memory=None, profile=None, context=None, vision=None,
                 listener=None, reminders=None, progress=None,
                 iron_man_effect=None, dry_run=False):
        self.memory = memory
        self.profile = profile
        self.context = context
        self.vision = vision
        self.listener = listener
        self.reminders = reminders
        self.progress = progress                # callable(str) -> show interim text
        self.iron_man_effect = iron_man_effect  # callable() -> HUD effect
        # dry_run makes every side effect a no-op, so the test suite can run the
        # full pipeline without opening apps or locking the machine.
        self.dry_run = dry_run
        self.performed = []                     # audit trail, used by tests

    def did(self, what: str):
        self.performed.append(what)


class Dispatcher:
    """Executes parsed intents locally."""

    def __init__(self, services: Services | None = None):
        self.services = services or Services()
        self._pending_action = None       # (intent, params, armed_at, raw)
        self._pending_slot = None         # (intent, params, slot, armed_at)
        # Language of the utterance currently being answered. Starts in Hinglish
        # because that is the user's profile language.
        self._lang = "hi"

    # ── Language ─────────────────────────────────────
    @property
    def language(self) -> str:
        """"en" or "hi": the language of the last thing the user said."""
        return self._lang

    def _hear(self, text: str, fallback: str | None = None):
        """Adopt the language of what the user just said."""
        self._lang = reply_language(text, fallback=fallback or self._lang)

    def _t(self, hinglish: str, english: str) -> str:
        """Pick the reply matching the user's language."""
        return english if self._lang == "en" else hinglish

    # ── Pending-state helpers ────────────────────────
    @property
    def awaiting_confirmation(self) -> bool:
        return self._pending_action is not None and (
            time.time() - self._pending_action[2] < CONFIRMATION_TIMEOUT)

    @property
    def awaiting_clarification(self) -> bool:
        return self._pending_slot is not None and (
            time.time() - self._pending_slot[3] < CLARIFICATION_TIMEOUT)

    def clear_pending(self):
        self._pending_action = None
        self._pending_slot = None

    def resolve_pending(self, text: str) -> Result | None:
        """Offline check run BEFORE intent parsing.

        Returns a Result when this utterance answers an outstanding question,
        otherwise None so normal parsing continues.
        """
        # Expired pendings should not silently swallow a new command.
        if self._pending_action and not self.awaiting_confirmation:
            self._pending_action = None
        if self._pending_slot and not self.awaiting_clarification:
            self._pending_slot = None

        if self.awaiting_confirmation:
            intent, params, _armed, armed_raw = self._pending_action
            # "haan" answers in Hindi and "yes" in English, but a bare "okay"
            # carries no language -- it keeps the language of the command.
            self._hear(text, fallback=reply_language(armed_raw, fallback=self._lang))
            if _YES.match(text or ""):
                self._pending_action = None
                _log(f"[JARVIS][CONFIRM] Confirmed -> executing {intent}")
                return self._execute(intent, params, confirmed=True)
            if _NO.match(text or ""):
                self._pending_action = None
                _log(f"[JARVIS][CONFIRM] Declined -> cancelling {intent}")
                return Result(self._t("Theek hai Sir, cancel kar diya.",
                                      "Alright Sir, cancelled."),
                              f"cancelled {intent}")
            # Anything else is a new command; drop the stale confirmation.
            _log("[JARVIS][CONFIRM] Not a yes/no — dropping the pending action")
            self._pending_action = None
            return None

        if self.awaiting_clarification:
            intent, params, slot, _armed = self._pending_slot
            answer = (text or "").strip()
            if answer and not _NO.match(answer):
                self._pending_slot = None
                self._hear(answer)
                params = dict(params)
                params[slot] = answer
                _log(f"[JARVIS][CLARIFY] Filled '{slot}' = {answer!r} for {intent}")
                return self._execute(intent, params, raw=answer)
            self._pending_slot = None
            if answer and _NO.match(answer):
                self._hear(answer)
                return Result(self._t("Koi baat nahi, Sir.", "No problem, Sir."),
                              "cancelled clarification")
        return None

    # ── Entry point ──────────────────────────────────
    def dispatch(self, parsed) -> Result:
        """Execute a parsed Intent (see core/intent_engine.Intent)."""
        intent = parsed.intent
        params = dict(parsed.params or {})
        raw = parsed.raw_text or ""
        self._hear(raw)

        # A bare verb with no object gets a question, not silence.
        for pattern, is_search, hinglish, english in _INCOMPLETE:
            if re.match(pattern, raw.strip(), re.IGNORECASE):
                slot_intent = "web_search" if is_search else intent
                slot = "query" if is_search else "what"
                self._pending_slot = (slot_intent, params, slot, time.time())
                return Result(self._t(hinglish, english),
                              "asking for the missing detail", awaiting="clarification")

        # A known intent whose required slot is empty gets the same treatment.
        if intent in _REQUIRED_SLOT:
            slot, hinglish, english = _REQUIRED_SLOT[intent]
            if not str(params.get(slot, "")).strip():
                self._pending_slot = (intent, params, slot, time.time())
                return Result(self._t(hinglish, english),
                              f"asking which {slot}", awaiting="clarification")

        # Risky intents ask first.
        if intent in CONFIRM_INTENTS:
            self._pending_action = (intent, params, time.time(), raw)
            hinglish_label, english_label = {
                "lock_pc": ("PC lock", "lock the PC"),
                "shutdown": ("PC shut down", "shut down the PC"),
                "restart": ("PC restart", "restart the PC"),
            }.get(intent, (intent, intent))
            return Result(
                self._t(f"Sir, {hinglish_label} karne ja raha hoon. Confirm kar dein?",
                        f"Sir, shall I {english_label}? Please confirm."),
                f"awaiting confirmation for {intent}",
                awaiting="confirmation",
            )

        return self._execute(intent, params, raw=raw)

    def execute(self, intent: str, params: dict | None = None,
                raw: str = "") -> Result:
        """Run an intent directly, skipping parsing (used by the fast path)."""
        if raw:
            self._hear(raw)
        return self._execute(intent, params or {}, raw=raw)

    # ── The actual work ──────────────────────────────
    def _execute(self, intent: str, params: dict, confirmed: bool = False,
                 raw: str = "") -> Result:
        if confirmed:
            _log(f"[JARVIS][DISPATCH] Executing confirmed action: {intent}")
        services = self.services
        dry = services.dry_run
        lang = self._lang
        t = self._t

        # ── Time / date ──────────────────────────────
        if intent == "time":
            return Result(get_time(lang), "telling the time")

        if intent == "date":
            return Result(get_date(lang), "telling the date")

        # ── Apps ─────────────────────────────────────
        # Gemini sometimes reads "open camera" as open_app. JARVIS's camera IS
        # its vision system, so route it there rather than launching the Windows
        # Camera app, which would also lock the webcam away from vision.
        if intent in ("open_app", "close_app") and re.fullmatch(
                r"\s*(?:the\s+)?(?:web\s*)?(?:camera|cam)(?:\s+app)?\s*",
                str(params.get("app", "")), re.IGNORECASE):
            intent = "vision_on" if intent == "open_app" else "vision_off"

        if intent == "open_app":
            requested = str(params.get("app", "")).strip()
            _target, label = resolve_app(requested)
            if dry:
                services.did(f"open_app:{label}")
                return Result(t(f"{label} khol raha hoon, Sir.", f"Opening {label}, Sir."),
                              f"opening {label}")
            ok, label = open_app(requested)
            if ok:
                return Result(t(f"{label} khol raha hoon, Sir.", f"Opening {label}, Sir."),
                              f"opening {label}")
            return Result(t(f"Maaf kijiye Sir, {label} system par mila nahi.",
                            f"Sorry Sir, I couldn't find {label} on this system."),
                          f"could not find {label}")

        if intent == "close_app":
            requested = str(params.get("app", "")).strip()
            _target, label = resolve_app(requested)
            if dry:
                services.did(f"close_app:{label}")
                return Result(t(f"{label} band kar raha hoon, Sir.", f"Closing {label}, Sir."),
                              f"closing {label}")
            closed, label = close_app(requested)
            if closed:
                return Result(t(f"{label} band kar diya, Sir.", f"{label} is closed, Sir."),
                              f"closing {label}")
            return Result(t(f"{label} chal hi nahi raha tha, Sir.",
                            f"{label} wasn't running, Sir."),
                          f"{label} was not running")

        # ── System ───────────────────────────────────
        if intent == "system_info":
            info_type = str(params.get("type") or params.get("info") or "all").lower()
            aliases = {"memory": "ram", "storage": "disk", "power": "battery",
                       "charge": "battery", "everything": "all", "system": "all"}
            info_type = aliases.get(info_type, info_type)
            return Result(get_system_info(info_type, lang), f"reporting {info_type}")

        if intent == "screenshot":
            if dry:
                services.did("screenshot")
                return Result(t("Screenshot le liya, Sir.", "Screenshot taken, Sir."),
                              "taking a screenshot")
            ok, detail = take_screenshot()
            if ok:
                return Result(
                    t("Screenshot le liya, Sir. Pictures ke JARVIS folder mein save ho gaya.",
                      "Screenshot taken, Sir. It's saved in the JARVIS folder under Pictures."),
                    f"screenshot saved to {os.path.basename(detail)}")
            return Result(t("Screenshot nahi le paya, Sir.", "I couldn't take a screenshot, Sir."),
                          "screenshot failed")

        if intent == "volume_control":
            action = str(params.get("action") or params.get("direction") or "").lower()
            if dry:
                services.did(f"volume:{action}")
                return Result(t(f"Volume {action} kar diya, Sir.", f"Volume {action}, Sir."),
                              f"volume {action}")
            ok, applied = set_volume(action)
            if not ok:
                return Result(t("Volume adjust nahi kar paya, Sir.",
                                "I couldn't adjust the volume, Sir."), "volume failed")
            if lang == "en":
                spoken = {"up": "turned up", "down": "turned down", "mute": "muted",
                          "unmute": "unmuted", "max": "set to maximum",
                          "min": "set to minimum"}.get(applied, "adjusted")
            else:
                spoken = {"up": "badha diya", "down": "kam kar diya", "mute": "mute kar diya",
                          "unmute": "unmute kar diya", "max": "full kar diya",
                          "min": "sabse kam kar diya"}.get(applied, "adjust kar diya")
            return Result(f"Volume {spoken}, Sir.", f"volume {applied}")

        # ── Power (only reached after confirmation) ──
        if intent == "lock_pc":
            def _lock():
                if not dry:
                    execute_lock()
                services.did("lock_pc")
            return Result(t("Systems lock kar raha hoon, Sir. Take care.",
                            "Locking the systems, Sir. Take care."),
                          "locking the PC", after_speaking=_lock, sleep_after=True)

        if intent == "shutdown":
            def _shutdown():
                if not dry:
                    shutdown_pc(delay_seconds=10)
                services.did("shutdown")
            return Result(t("PC shut down kar raha hoon, Sir. Dus second mein band ho jayega.",
                            "Shutting down the PC, Sir. It will power off in ten seconds."),
                          "shutting down", after_speaking=_shutdown, sleep_after=True)

        if intent == "restart":
            def _restart():
                if not dry:
                    restart_pc(delay_seconds=10)
                services.did("restart")
            return Result(t("PC restart kar raha hoon, Sir. Dus second mein reboot hoga.",
                            "Restarting the PC, Sir. It will reboot in ten seconds."),
                          "restarting", after_speaking=_restart, sleep_after=True)

        # ── Media ────────────────────────────────────
        if intent == "play_music":
            if dry:
                services.did("play_music")
                return Result(t("Music laga raha hoon, Sir.", "Playing music, Sir."),
                              "opening Spotify")
            play_music()
            return Result(t("Music laga raha hoon, Sir. Enjoy kijiye.",
                            "Playing music, Sir. Enjoy."), "opening Spotify")

        # ── Web ──────────────────────────────────────
        if intent == "web_search":
            query = str(params.get("query") or params.get("q") or "").strip()
            if dry:
                services.did(f"web_search:{query}")
            else:
                web_search(query)
            return Result(t(f"{query} search kar raha hoon, Sir. Browser mein results khul gaye.",
                            f"Searching for {query}, Sir. The results are open in your browser."),
                          f"searching for {query}")

        # ── Reminders ────────────────────────────────
        if intent == "set_reminder":
            return self._set_reminder(params)

        # ── Memory ───────────────────────────────────
        no_memory = t("Memory system available nahi hai, Sir.",
                      "The memory system isn't available, Sir.")
        if intent == "remember":
            what = str(params.get("what") or params.get("text") or "").strip()
            if services.memory is None:
                return Result(no_memory, "memory unavailable")
            saved = services.memory.remember(what)
            return Result(t(f"Yaad rakh liya, Sir: {saved}.",
                            f"Got it, Sir. I'll remember: {saved}."),
                          f"remembering '{saved}'")

        if intent == "recall":
            what = str(params.get("what") or params.get("query") or "").strip()
            if services.memory is None:
                return Result(no_memory, "memory unavailable")
            found = services.memory.recall(what)
            if found:
                return Result(t(f"Aapne bataya tha — {found}, Sir.",
                                f"You told me: {found}, Sir."),
                              f"recalled '{found}'")
            return Result(t("Iske baare mein kuch yaad nahi hai, Sir. "
                            "Bataiye toh yaad rakh lunga.",
                            "I don't have anything on that, Sir. "
                            "Tell me and I'll remember it."),
                          "nothing in memory")

        if intent == "forget":
            what = str(params.get("what") or "").strip()
            if services.memory is None:
                return Result(no_memory, "memory unavailable")
            removed = services.memory.forget(what)
            if removed:
                return Result(t(f"Bhool gaya, Sir: {removed}.", f"Forgotten, Sir: {removed}."),
                              f"forgot '{removed}'")
            return Result(t("Aisi koi memory mili hi nahi, Sir.",
                            "I couldn't find a memory like that, Sir."),
                          "nothing to forget")

        # ── Vision ───────────────────────────────────
        if intent == "vision_on":
            if services.vision is None or dry:
                services.did("vision_on")
                return Result(t("Vision activate kar raha hoon, Sir.", "Activating vision, Sir."),
                              "activating the camera")
            ok, message = services.vision.start()
            if lang != "en":
                # The vision module speaks English; give the common outcomes a
                # Hinglish line so the reply still matches the user.
                if not ok:
                    message = "Camera start nahi ho paya, Sir."
                elif "already" in message.lower():
                    message = "Vision pehle se active hai, Sir."
                elif "register" in message.lower():
                    message = "Owner face register kar raha hoon, Sir. Camera ki taraf dekhiye."
                else:
                    message = "Vision online hai, Sir. Main dekh raha hoon."
            return Result(message, "activating the camera" if ok else "camera failed")

        if intent == "vision_off":
            if services.vision is None or dry:
                services.did("vision_off")
                return Result(t("Vision band kar diya, Sir.", "Vision is off, Sir."),
                              "deactivating the camera")
            services.vision.stop()
            return Result(t("Vision deactivate kar diya, Sir. Camera off hai.",
                            "Vision deactivated, Sir. The camera is off."),
                          "deactivating the camera")

        if intent == "vision_describe":
            if services.vision is None or dry:
                services.did("vision_describe")
                return Result(t("Camera abhi off hai, Sir.", "The camera is off right now, Sir."),
                              "camera is off")
            if services.progress:
                services.progress(t("Dekh raha hoon, Sir...", "Looking, Sir..."))
            return Result(services.vision.describe_scene(), "describing the scene")

        # ── Briefing ─────────────────────────────────
        if intent == "morning_briefing":
            if services.progress:
                services.progress(t("Briefing taiyaar kar raha hoon, Sir...",
                                    "Preparing your briefing, Sir..."))
            text = build_briefing(profile=services.profile,
                                  reminder_manager=services.reminders,
                                  memory_store=services.memory,
                                  lang=lang)
            return Result(text, "delivering the daily briefing")

        # ── Easter egg ───────────────────────────────
        if intent == "easter_egg_ironman":
            if not dry:
                if services.iron_man_effect:
                    services.iron_man_effect()
                play_arc_reactor_sound()
                return Result(execute_iron_man_easter_egg(), "running the Iron Man sequence")
            services.did("easter_egg_ironman")
            return Result("And I am the voice behind the suit, Sir.",
                          "running the Iron Man sequence")

        # ── Mic maintenance ──────────────────────────
        if intent == "recalibrate":
            if services.listener is not None and not dry:
                services.listener.recalibrate()
            services.did("recalibrate")
            return Result(t("Ambient noise ke liye recalibrate kar raha hoon, Sir. "
                            "Thodi der chup rahiye.",
                            "Recalibrating for ambient noise, Sir. "
                            "Please stay quiet for a moment."),
                          "recalibrating the microphone")

        if intent == "change_mic":
            return self._change_mic()

        if intent == "use_mic":
            index = params.get("index")
            if services.listener is not None and not dry and index is not None:
                services.listener.request_device_switch(int(index), manual=True)
            services.did(f"use_mic:{index}")
            return Result(t(f"Microphone {index} par switch kar raha hoon, Sir.",
                            f"Switching to microphone {index}, Sir."),
                          f"switching to microphone {index}")

        if intent == "sensitivity":
            direction = params.get("direction", "up")
            if services.listener is None or dry:
                services.did(f"sensitivity:{direction}")
                return Result(t(f"Mic sensitivity {direction} kar di, Sir.",
                                f"Mic sensitivity {direction}, Sir."),
                              f"sensitivity {direction}")
            if direction == "up":
                threshold = services.listener.increase_sensitivity()
                return Result(t(f"Mic sensitivity badha di, Sir. Threshold ab {threshold:.4f} hai.",
                                f"Mic sensitivity increased, Sir. The threshold is now {threshold:.4f}."),
                              "increasing mic sensitivity")
            threshold = services.listener.decrease_sensitivity()
            return Result(t(f"Mic sensitivity kam kar di, Sir. Threshold ab {threshold:.4f} hai.",
                            f"Mic sensitivity decreased, Sir. The threshold is now {threshold:.4f}."),
                          "decreasing mic sensitivity")

        # ── Conversation ─────────────────────────────
        if intent in ("general_question", "small_talk", "unknown"):
            return self._answer(intent, params, raw)

        return Result(t("Ye samajh nahi aaya, Sir. Dobara boliye?",
                        "I didn't understand that, Sir. Could you say it again?"),
                      f"unhandled intent {intent}")

    # ── Helpers for the longer branches ──────────────
    def _set_reminder(self, params: dict) -> Result:
        services = self.services
        t = self._t
        seconds = params.get("seconds")
        amount = params.get("amount")
        unit = params.get("unit")
        message = str(params.get("message") or params.get("what") or "your reminder").strip()

        if seconds is None:
            # Gemini returns human time like "5 minutes" / "10 min" / "1 hour".
            spoken_time = str(params.get("time") or params.get("when") or "")
            match = re.search(r"(\d+)\s*(second|sec|minute|min|hour|hr|ghant)", spoken_time, re.I)
            if match:
                amount = int(match.group(1))
                token = match.group(2).lower()
                if token.startswith(("minute", "min")):
                    seconds, unit = amount * 60, "minutes"
                elif token.startswith(("hour", "hr", "ghant")):
                    seconds, unit = amount * 3600, "hours"
                else:
                    seconds, unit = amount, "seconds"

        if seconds is None:
            self._pending_slot = ("set_reminder", params, "time", time.time())
            return Result(t("Sir, kitni der baad reminder set karun?",
                            "Sir, how long from now should I set the reminder?"),
                          "asking when to remind", awaiting="clarification")

        if services.reminders is None or services.dry_run:
            services.did(f"set_reminder:{seconds}s:{message}")
            return Result(t(f"Reminder set ho gaya, Sir. {message} ke liye yaad dila dunga.",
                            f"Reminder set, Sir. I'll remind you about {message}."),
                          f"setting a reminder in {seconds}s")
        speech = services.reminders.set_reminder(int(seconds), message, amount, unit,
                                                 lang=self._lang)
        return Result(speech, f"setting a reminder in {seconds}s")

    def _change_mic(self) -> Result:
        services = self.services
        t = self._t
        if services.listener is None or services.dry_run:
            services.did("change_mic")
            return Result(t("Microphone list terminal mein hai, Sir.",
                            "The microphone list is in the terminal, Sir."),
                          "listing microphones")
        try:
            from core.mic_select import list_input_devices
            devices, default = list_input_devices()
            _log("[JARVIS] ===== Available microphones =====")
            for index, name in devices:
                tag = "  (current)" if index == services.listener.device_index else (
                    "  (default)" if index == default else "")
                _log(f"[JARVIS]   [{index}] {name}{tag}")
            _log("[JARVIS] =================================")
        except Exception as e:
            _log(f"[JARVIS] Could not list microphones: {e}")
            return Result(t("Microphone list nahi nikal paya, Sir.",
                            "I couldn't list the microphones, Sir."),
                          "listing microphones failed")
        return Result(t("Microphones terminal mein list kar diye, Sir. "
                        "'Use microphone' ke saath number boliye.",
                        "I've listed the microphones in the terminal, Sir. "
                        "Say 'use microphone' followed by the number."),
                      "listing microphones")

    def _answer(self, intent: str, params: dict, raw: str = "") -> Result:
        """general_question / small_talk / unknown — the only network path left.

        The raw utterance is the last resort on purpose. Gemini is only asked to
        extract a question for general_question, so "How are you?" comes back as
        small_talk with NO params at all -- and answering an empty string used to
        mean JARVIS replied "samajh nahi aaya" to a question it had understood
        perfectly. Whatever was actually said is always a usable question.
        """
        services = self.services
        t = self._t
        question = str(
            params.get("question") or params.get("text") or params.get("query") or ""
        ).strip()
        if not question:
            question = str(params.get("what") or "").strip()
        # `unknown` is excluded on purpose. It is where mis-transcribed noise
        # lands ("Dewey.", "E acerro."), and answering that through Gemini would
        # have JARVIS confidently reply to things nobody said.
        if not question and intent != "unknown":
            question = (raw or "").strip()

        # "What did I just ask?" is answerable from session context alone.
        if services.context is not None and _CONTEXT_QUESTIONS.search(question):
            previous = services.context.last_user_text()
            if previous:
                return Result(t(f'Aapne poocha tha, Sir: "{previous}".',
                                f'You asked: "{previous}", Sir.'),
                              "recalling the last question")
            return Result(t("Is session mein abhi tak kuch poocha nahi, Sir.",
                            "You haven't asked me anything yet this session, Sir."),
                          "no previous question")

        # memory.json before the API — a fact JARVIS was told costs no quota.
        if services.memory is not None and question:
            remembered = services.memory.recall(question)
            if remembered:
                return Result(t(f"Aapne bataya tha — {remembered}, Sir.",
                                f"You told me: {remembered}, Sir."),
                              "answering from memory (no API call)")

        if not question:
            return Result(t("Samajh nahi aaya, Sir. Dobara boliye?",
                            "I didn't catch that, Sir. Could you say it again?"),
                          "did not understand")

        # Dry run stops here: the memory check above has already run, and the
        # test suite has no reason to spend quota generating prose.
        if services.dry_run:
            services.did(f"ask_gemini:{question}")
            return Result(f"(dry run) would ask Gemini: {question}",
                          f"asking Gemini ({intent})")

        if services.progress:
            services.progress(t("Soch raha hoon, Sir...", "Thinking, Sir..."))

        handler = small_talk if intent == "small_talk" else answer_question
        answer, source = handler(question, profile=services.profile,
                                 context=services.context,
                                 memory_store=services.memory,
                                 lang=self._lang)
        label = {"memory": "answering from memory",
                 "offline": "Gemini cooling down, told the user"}.get(
                     source, f"asking Gemini ({intent})")
        return Result(answer, label)
