"""
J.A.R.V.I.S. — Command Pipeline

One utterance in, one decision out. This is the whole command-processing flow
in the order it actually runs:

    1. OFFLINE FAST PATH   wake word / standby / easter egg  (< 0.1s, no API)
    2. PENDING ANSWER      a yes/no to a confirmation, or the missing detail
                           for a clarification  (offline)
    3. INTENT PARSING      Gemini decides what the user meant, with session
                           context and known memories attached; the offline
                           pattern matcher backs it up
    4. LOCAL EXECUTION     core/dispatcher.py performs the action
    5. LOG + CONTEXT       one pipeline line to the terminal, and the turn is
                           added to the rolling session context

main.py owns the microphone, the HUD and the speaker; this module owns the
thinking. Keeping them apart is what makes the pipeline testable without Qt or
a working audio device.
"""

import time

from core import fast_path
from core.intent_engine import parse_intent


class Outcome:
    """What the caller should do about one utterance."""

    __slots__ = ("kind", "intent", "confidence", "source", "speech", "action",
                 "after_speaking", "awaiting", "daddy_home", "latency_ms",
                 "sleep_after")

    def __init__(self, kind, speech="", action="", intent="", confidence=0.0,
                 source="", after_speaking=None, awaiting=None,
                 daddy_home=False, latency_ms=0, sleep_after=False):
        self.kind = kind                  # "wake" | "sleep" | "command" | "ignored"
        self.speech = speech
        self.action = action
        self.intent = intent
        self.confidence = confidence
        self.source = source              # "gemini" | "fallback" | "local"
        self.after_speaking = after_speaking
        self.awaiting = awaiting
        # True once the action leaves nobody at the keyboard (lock/shutdown/
        # restart): the caller must drop to STANDBY instead of listening on.
        self.sleep_after = sleep_after
        self.daddy_home = daddy_home
        self.latency_ms = latency_ms

    def __repr__(self):
        return (f"Outcome({self.kind}, intent={self.intent!r}, "
                f"action={self.action!r})")


class Pipeline:
    """Turns transcribed text into an Outcome."""

    def __init__(self, dispatcher, memory=None, profile=None, context=None,
                 log_fn=None):
        self.dispatcher = dispatcher
        self.memory = memory
        self.profile = profile
        self.context = context
        self._log_fn = log_fn or _default_log

    def log(self, msg):
        try:
            self._log_fn(msg)
        except UnicodeEncodeError:
            self._log_fn(msg.encode("ascii", "replace").decode("ascii"))

    def _pipeline_line(self, heard, intent, confidence, action, source, ms):
        """The single line that shows the whole pipeline for one command."""
        line = (f"HEARD: {heard} -> INTENT: {intent} "
                f"(confidence: {confidence:.2f}) -> ACTION: {action}")
        self.log(f"[JARVIS][PIPELINE] {line}   [{source}, {ms}ms]")

    def handle(self, text: str, awake: bool = True) -> Outcome:
        """Process one utterance."""
        started = time.time()
        text = (text or "").strip()
        if not text:
            return Outcome("ignored")

        # ── 1. Offline fast path ─────────────────────
        hit = fast_path.check(text, awake=awake)
        if hit is not None:
            if hit.kind == fast_path.WAKE:
                self.log(f"[JARVIS][FAST] Wake word ({hit.elapsed_ms:.2f}ms, offline)")
                return Outcome("wake", speech=hit.response, action="waking up",
                               intent="wake_word", confidence=1.0, source="local",
                               daddy_home=hit.daddy_home)
            if hit.kind == fast_path.SLEEP:
                self.log(f"[JARVIS][FAST] Standby command ({hit.elapsed_ms:.2f}ms, offline)")
                self.dispatcher.clear_pending()
                return Outcome("sleep", speech=hit.response, action="going to standby",
                               intent="standby", confidence=1.0, source="local")
            if hit.kind == fast_path.EASTER_EGG:
                self.log(f"[JARVIS][FAST] Easter egg ({hit.elapsed_ms:.2f}ms, offline)")
                result = self.dispatcher.execute("easter_egg_ironman")
                self._pipeline_line(text, "easter_egg_ironman", 1.0, result.action,
                                    "local", int((time.time() - started) * 1000))
                self._remember_turn(text, result.speech, "easter_egg_ironman")
                return Outcome("command", result.speech, result.action,
                               "easter_egg_ironman", 1.0, "local",
                               result.after_speaking, result.awaiting,
                               sleep_after=result.sleep_after)

        # Asleep and not a wake word: nothing to do.
        if not awake:
            return Outcome("ignored")

        # ── 2. An answer to something JARVIS asked ───
        pending = self.dispatcher.resolve_pending(text)
        if pending is not None:
            self._pipeline_line(text, "confirmation/clarification", 1.0,
                                pending.action, "local",
                                int((time.time() - started) * 1000))
            self._remember_turn(text, pending.speech, "pending")
            return Outcome("command", pending.speech, pending.action,
                           "pending_answer", 1.0, "local",
                           pending.after_speaking, pending.awaiting,
                           sleep_after=pending.sleep_after)

        # ── 3. Intent parsing (Gemini first) ─────────
        parsed = parse_intent(
            text,
            context=self.context.as_prompt() if self.context else "",
            memory_hint=self._memory_hint(),
        )

        # ── 4. Local execution ───────────────────────
        result = self.dispatcher.dispatch(parsed)

        # ── 5. Log + context ─────────────────────────
        self._pipeline_line(text, parsed.intent, parsed.confidence, result.action,
                            parsed.source, parsed.latency_ms)
        self._remember_turn(text, result.speech, parsed.intent)

        return Outcome("command", result.speech, result.action, parsed.intent,
                       parsed.confidence, parsed.source, result.after_speaking,
                       result.awaiting, latency_ms=parsed.latency_ms,
                       sleep_after=result.sleep_after)

    # ── helpers ──────────────────────────────────────
    def _memory_hint(self) -> str:
        """A few stored facts, so the parser can resolve 'my meeting' etc."""
        if self.memory is None or not self.memory.count():
            return ""
        return "; ".join(entry["text"] for entry in self.memory.all()[-5:])

    def _remember_turn(self, user_text: str, jarvis_text: str, intent: str):
        if self.context is not None:
            self.context.add(user_text, jarvis_text, intent)


def _default_log(msg):
    print(msg, flush=True)
