"""
J.A.R.V.I.S. — Automatic microphone selection.

No prompts. On startup (and every few seconds while running, for hot-swap):
  * If a headset mic (Bluetooth / wired / USB) is connected AND openable -> use it.
  * Otherwise -> the default laptop mic (Microphone Array).

A device being LISTED is not enough — Windows keeps Bluetooth Hands-Free
endpoints in the list even when the headset is off — so candidates are probed
with a real open before being chosen.
"""

import os

from config import BASE_DIR

MIC_CONFIG_FILE = os.path.join(BASE_DIR, "mic_config.json")   # legacy; no longer written

# Substrings (lowercase) that identify a headset / external mic.
HEADSET_KEYWORDS = [
    "headset", "hands-free", "hands free", "headphone", "earphone", "earbud",
    "airpod", "buds", "oneplus", "bullets", "boat", "jbl", "soundcore",
    "realme", "bluetooth", "wireless", "usb audio",
]


def _log(msg):
    try:
        print(msg, flush=True)
    except UnicodeEncodeError:
        print(msg.encode("ascii", "replace").decode("ascii"), flush=True)


def is_headset(name: str) -> bool:
    name_l = (name or "").lower()
    return any(k in name_l for k in HEADSET_KEYWORDS)


def list_input_devices():
    """Return (devices, default_index) where devices is [(index, name), ...].
    Uses a FRESH PyAudio instance so newly connected devices are visible."""
    import pyaudio
    pa = pyaudio.PyAudio()
    devices = []
    default_index = None
    try:
        try:
            default_index = pa.get_default_input_device_info().get("index")
        except Exception:
            default_index = None
        for i in range(pa.get_device_count()):
            info = pa.get_device_info_by_index(i)
            if info.get("maxInputChannels", 0) > 0:
                devices.append((i, info.get("name", f"Device {i}")))
    finally:
        pa.terminate()
    return devices, default_index


def can_open(index, rate=16000) -> bool:
    """True if the device actually opens for input (a listed-but-disconnected
    Bluetooth headset fails here). Cheap: open + immediately close."""
    import pyaudio
    pa = pyaudio.PyAudio()
    try:
        s = pa.open(format=pyaudio.paInt16, channels=1, rate=rate, input=True,
                    input_device_index=index, frames_per_buffer=480)
        try:
            s.close()
        except Exception:
            pass
        return True
    except Exception:
        return False
    finally:
        pa.terminate()


def pick_best(devices, default_index, can_open=None):
    """Return (index, name, is_headset). Priority:
      1. first OPENABLE headset-looking device
      2. the default (laptop) mic
      3. any openable device
    `can_open` is injectable; None resolves the module-level probe at CALL time
    (so monkeypatching mic_select.can_open works)."""
    probe = can_open if can_open is not None else globals()["can_open"]
    name_of = dict(devices)

    for i, n in devices:
        if is_headset(n) and probe(i):
            return i, n, True

    if default_index is not None and default_index in name_of and probe(default_index):
        return default_index, name_of[default_index], False

    for i, n in devices:
        if probe(i):
            return i, n, False
    return None, "none", False


def auto_select_microphone():
    """Silently pick the best mic and print ONE line saying which and why.
    Returns (index, name, is_headset)."""
    try:
        devices, default_index = list_input_devices()
        idx, name, headset = pick_best(devices, default_index)
    except Exception as e:
        _log(f"[JARVIS] Mic auto-select failed ({e}); using system default.")
        return None, "default", False
    if idx is None:
        _log("[JARVIS] Auto-selected mic: none found — using system default.")
        return None, "default", False
    reason = "headset detected" if headset else "no headset found, using laptop mic"
    _log(f"[JARVIS] Auto-selected mic: [{idx}] {name} ({reason})")
    return idx, name, headset


def clear_saved_device():
    """Remove the legacy manual-choice file (auto-selection supersedes it)."""
    try:
        if os.path.exists(MIC_CONFIG_FILE):
            os.remove(MIC_CONFIG_FILE)
    except Exception:
        pass
