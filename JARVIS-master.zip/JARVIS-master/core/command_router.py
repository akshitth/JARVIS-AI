"""
J.A.R.V.I.S. — Offline Intent Fallback (pattern matching)

This is NOT the primary path any more. Every command now goes to Gemini for
intent parsing (see core/intent_engine.py). This module is the safety net:
when Gemini is rate-limited, offline, or slow, JARVIS falls back here so it
never goes deaf.

It emits the SAME intent vocabulary as the Gemini parser, so the dispatcher
cannot tell which of the two produced a result.

Hindi word order is the opposite of English — the object comes before the verb
("Chrome khol do" vs "open Chrome") — so most rules exist in both shapes.
"""

import re

# Every intent the dispatcher knows how to execute.
KNOWN_INTENTS = {
    "open_app", "close_app", "time", "date", "system_info", "lock_pc",
    "shutdown", "restart", "play_music", "web_search", "set_reminder",
    "volume_control", "screenshot", "remember", "recall", "forget",
    "vision_on", "vision_off", "vision_describe", "easter_egg_ironman",
    "morning_briefing", "change_mic", "recalibrate", "general_question",
    "small_talk", "unknown",
    # Local-only extras the Gemini prompt doesn't list but JARVIS supports.
    "sensitivity", "use_mic",
}


def _normalize(text: str) -> str:
    """Lowercase, strip punctuation, collapse whitespace, drop the wake word."""
    t = (text or "").lower().strip()
    t = re.sub(r"[^\w\s'ऀ-ॿ]", " ", t)
    t = re.sub(r"\b(?:hey\s+)?jarvis\b", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


# ── Devanagari keyword bridge ────────────────────────
# Whisper's auto-detect sometimes returns Hindi in Devanagari rather than
# romanized. Rather than a full transliterator, the handful of command words
# that actually matter get mapped to their romanized form up front.
_DEVANAGARI = {
    "समय": "time", "बजे": "baje", "कितने": "kitne", "खोल": "khol",
    "खोलो": "kholo", "चालू": "chalu", "बंद": "band", "करो": "karo",
    "कर": "kar", "दो": "do", "गाना": "gaana", "गाने": "gaane",
    "संगीत": "music", "बजाओ": "bajao", "सुनाओ": "sunao", "लॉक": "lock",
    "बैटरी": "battery", "तारीख": "date", "आज": "aaj", "याद": "yaad",
    "रखो": "rakho", "भूल": "bhool", "देखो": "dekho", "दिखाओ": "dikhao",
    "सुबह": "subah", "नमस्ते": "namaste", "क्या": "kya", "है": "hai",
    "कब": "kab", "मेरा": "mera", "मेरी": "meri", "बताओ": "batao",
}


def _romanize(text: str) -> str:
    """Replace known Devanagari command words with their romanized form."""
    if not re.search(r"[ऀ-ॿ]", text):
        return text
    for dev, rom in _DEVANAGARI.items():
        text = text.replace(dev, f" {rom} ")
    return re.sub(r"\s+", " ", text).strip()


# ── Verb vocabulary ──────────────────────────────────
_OPEN_VERBS = r"(?:khol\s*do|khol\s*de|kholo|khol|chala\s*do|chalao|chalu\s*kar(?:o|do)?|chalu|shuru\s*kar(?:o|do)?|open\s*kar(?:o|do)?|start\s*kar(?:o|do)?|laga\s*do|lagao|on\s*kar(?:o|do)?)"
_CLOSE_VERBS = r"(?:band\s*kar(?:o|do|de)?|band|bandh|close\s*kar(?:o|do)?|hata\s*do|off\s*kar(?:o|do)?)"
_TRAILING_JUNK = r"\s*\b(?:please|plz|zara|jara|na|yaar|bhai|sir|abhi|now|for\s+me|karo|kar\s*do|do|de|dena)\b\s*$"


def _clean_target(name: str) -> str:
    """Trim politeness/filler off an extracted app name or query."""
    name = (name or "").strip()
    for _ in range(4):                      # strip several stacked fillers
        new = re.sub(_TRAILING_JUNK, "", name).strip()
        if new == name:
            break
        name = new
    name = re.sub(r"^(?:the|a|an|mera|meri|mere|ye|yeh|wo|woh|that|this|koi|ek)\s+", "", name).strip()
    return name


def fallback_intent(text: str) -> tuple[str, dict, float]:
    """Parse an utterance offline.

    Returns (intent, params, confidence). Confidence is deliberately a little
    lower than Gemini's so the log makes it obvious which parser answered.
    """
    raw = (text or "").strip()
    t = _normalize(_romanize(raw))

    if not t:
        return "unknown", {}, 0.0

    # ── Easter egg ───────────────────────────────────
    if re.search(r"i\s*(?:am|'?m)\s+iron\s*man", t):
        return "easter_egg_ironman", {}, 0.95

    # ── Daily briefing / greeting ────────────────────
    if re.search(r"\b(?:good\s*morning|subah\s*bakhair|morning\s*briefing|daily\s*briefing|briefing)\b", t) or \
            re.search(r"\bnamaste\b", t):
        return "morning_briefing", {}, 0.9

    # ── Mic maintenance (local-only intents) ─────────
    if re.search(r"\brecalibrat", t) or re.search(r"(?:re)?calibrate\s+(?:the\s+)?(?:mic|noise|audio|ambient)", t):
        return "recalibrate", {}, 0.9
    m = re.search(r"(?:use|select|set)\s+(?:the\s+)?mic(?:rophone)?\s+(?:number\s+)?(\d+)", t)
    if m:
        return "use_mic", {"index": int(m.group(1))}, 0.9
    if re.search(r"(?:change|switch|badal)\s+(?:the\s+)?(?:my\s+)?mic(?:rophone)?", t) or \
            re.search(r"\bmic(?:rophone)?\s+(?:change|badlo|badal)", t):
        return "change_mic", {}, 0.9
    if re.search(r"(?:increase|raise|boost|turn\s+up|more|badhao|badha)\s+(?:the\s+)?(?:mic(?:rophone)?\s+)?sensitivity", t) or \
            re.search(r"\bmore\s+sensitive\b", t):
        return "sensitivity", {"direction": "up"}, 0.9
    if re.search(r"(?:decrease|reduce|lower|turn\s+down|less|kam)\s+(?:the\s+)?(?:mic(?:rophone)?\s+)?sensitivity", t) or \
            re.search(r"\bless\s+sensitive\b", t):
        return "sensitivity", {"direction": "down"}, 0.9

    # ── Memory: remember / forget / recall ───────────
    # Recall is checked BEFORE remember: 'do you remember X' is a question,
    # and the remember rule would otherwise store the question as a fact.
    m = (re.search(r"(?:do\s+you\s+remember|kya\s+(?:tumhe|aapko)\s+yaad\s+hai|yaad\s+hai\s+(?:tumhe|aapko)?|recall)\s+(.+)", t)
         or re.search(r"(.+?)\s+yaad\s+hai\s*(?:kya)?$", t))
    if m:
        what = _clean_target(m.group(1))
        if what:
            return "recall", {"what": what}, 0.8

    m = (re.search(r"(?:bhool\s*ja(?:o|na)?|bhul\s*ja(?:o|na)?|forget|delete\s+(?:the\s+)?memory\s*(?:about)?)\s+(.+)", t)
         or re.search(r"(.+?)\s+(?:bhool\s*ja(?:o|na)?|bhul\s*ja(?:o|na)?)$", t))
    if m:
        what = _clean_target(m.group(1))
        if what and what not in ("it", "that", "sab", "everything"):
            return "forget", {"what": what}, 0.85

    m = (re.search(r"(?:yaad\s*(?:rakh(?:na|o|lo)?|rakhna)|remember\s*(?:that|this)?|note\s*(?:kar\s*lo|karo|down)|save\s*(?:this|that))\s+(.+)", t)
         or re.search(r"(.+?)\s+(?:yaad\s*rakh(?:na|o|lo)?|yaad\s*rakhna|note\s*kar\s*lo)$", t))
    if m:
        what = _clean_target(m.group(1))
        if what:
            return "remember", {"what": what}, 0.85

    # ── Vision ───────────────────────────────────────
    if re.search(r"what\s+(?:do|can)\s+you\s+see", t) or \
            re.search(r"what(?:'s| is)\s+in\s+front\s+of\s+you", t) or \
            re.search(r"describe\s+(?:what\s+you\s+see|the\s+(?:room|scene))", t) or \
            re.search(r"(?:kya\s+dikh\s+raha|samne\s+kya|dekh\s+kar\s+batao|batao\s+kya\s+dikh)", t):
        return "vision_describe", {}, 0.9
    # "Camera" always means JARVIS's own vision, never the Windows Camera app --
    # both grab the same webcam, and only vision gives gestures and face
    # recognition. These rules run before open_app for exactly that reason.
    # "open" was missing from both word orders, so "Camera open kar do" fell
    # through to general_question and "open camera" launched the wrong app.
    _art = r"(?:the\s+|your\s+|my\s+)?"
    _cam = r"(?:vision|camera|cam|webcam|eyes|aankhen)"
    if re.search(rf"\b(?:activate|enable|turn\s+on|switch\s+on|open|start|launch|on\s*kar\w*|khol\w*|chalu\s*kar\w*|chala\w*)\s+{_art}{_cam}\b", t) or \
            re.search(rf"\b{_cam}\s+(?:on|chalu|khol\w*|open|start|chala\w*|shuru)\b", t) or \
            re.search(r"look\s+at\s+me|(?:can\s+you\s+)?see\s+me|mujhe\s+dekh(?:o|na)?|dekho\s+mujhe", t):
        return "vision_on", {}, 0.9
    if re.search(rf"\b(?:deactivate|disable|turn\s+off|switch\s+off|close|stop|band\s*kar\w*)\s+{_art}{_cam}\b", t) or \
            re.search(rf"\b{_cam}\s+(?:off|band\w*|close|stop)\b", t) or \
            re.search(r"stop\s+(?:looking|watching)|dekhna\s+band", t):
        return "vision_off", {}, 0.9

    # ── Screenshot ───────────────────────────────────
    if re.search(r"\b(?:screenshot|screen\s*shot|screen\s*grab|screen\s+capture)\b", t) or \
            re.search(r"screen\s+(?:ka\s+)?(?:photo|pic|snap)", t):
        return "screenshot", {}, 0.9

    # ── Volume ───────────────────────────────────────
    if re.search(r"\b(?:mute|silent|chup)\b", t) and not re.search(r"unmute", t):
        return "volume_control", {"action": "mute"}, 0.85
    if re.search(r"\bunmute\b", t) or re.search(r"awaaz\s+wapas", t):
        return "volume_control", {"action": "unmute"}, 0.85
    if re.search(r"(?:volume|awaaz|sound)\s*(?:up|badhao|badha\s*do|tez|zyada)", t) or \
            re.search(r"(?:increase|raise|turn\s+up)\s+(?:the\s+)?(?:volume|sound|awaaz)", t):
        return "volume_control", {"action": "up"}, 0.85
    if re.search(r"(?:volume|awaaz|sound)\s*(?:down|kam|dheere|halka)", t) or \
            re.search(r"(?:decrease|lower|reduce|turn\s+down)\s+(?:the\s+)?(?:volume|sound|awaaz)", t):
        return "volume_control", {"action": "down"}, 0.85

    # ── Time ─────────────────────────────────────────
    # "kitne baje", "time kya hua", "what time is it", "bhai time bata"
    if re.search(r"\bkitne\s*baj", t) or re.search(r"\bbaje\s*(?:hain|hai|h)\b", t) or \
            re.search(r"\btime\b", t) or re.search(r"\bsamay\b", t) or \
            re.search(r"what(?:'s| is)?\s*(?:the)?\s*time", t) or re.search(r"\bo'?clock\b", t):
        # "remind me in 5 minutes" also contains 'time'-ish words — reminders are
        # matched later, so exclude the obvious reminder phrasing here.
        if not re.search(r"\b(?:remind|reminder|alarm|timer)\b", t):
            return "time", {}, 0.85

    # ── Date ─────────────────────────────────────────
    if re.search(r"\b(?:date|tareekh|tarikh)\b", t) or \
            re.search(r"what\s+day\s+is\s+(?:it|today)", t) or \
            re.search(r"\baaj\s+(?:kya|kaun\s*sa)\s+(?:din|date|tarikh|tareekh)", t) or \
            re.search(r"\btoday(?:'s)?\s+(?:date|day)\b", t):
        return "date", {}, 0.85

    # ── Reminders ────────────────────────────────────
    m = re.search(r"(?:remind\s+me|reminder|alarm|timer)\D*?(\d+)\s*(minute|min|hour|hr|second|sec|ghante|ghanta|minat)\w*\s*(?:me|mein|later|baad)?\s*(?:to\s+|ke\s+liye\s+|for\s+)?(.*)", t)
    if not m:
        m = re.search(r"(\d+)\s*(minute|min|hour|hr|second|sec|ghante|ghanta|minat)\w*\s*(?:baad|me|mein|later)\s+(?:yaad\s+dila\w*|remind\w*)\s*(.*)", t)
    if m:
        amount = int(m.group(1))
        unit_raw = m.group(2)
        message = _clean_target(m.group(3)) or "your reminder"
        if unit_raw.startswith(("min", "minat")):
            seconds, unit = amount * 60, "minutes"
        elif unit_raw.startswith(("hour", "hr", "ghant")):
            seconds, unit = amount * 3600, "hours"
        else:
            seconds, unit = amount, "seconds"
        return "set_reminder", {"seconds": seconds, "message": message,
                                "amount": amount, "unit": unit}, 0.85

    # ── Lock / shutdown / restart ────────────────────
    # "sab band kar de" = lock everything; "PC band kar do" = shut down.
    if re.search(r"\block\b", t) or re.search(r"\bsab\s+(?:kuch\s+)?band\b", t) or \
            re.search(r"secure\s+the\s+systems?", t) or re.search(r"\block\s*down\b", t):
        if not re.search(r"unlock", t):
            return "lock_pc", {}, 0.9
    if re.search(r"\brestart\b|\breboot\b|\bdobara\s+(?:chalu|start)\b|\bre\s*start\b", t):
        return "restart", {}, 0.9
    if re.search(r"\bshut\s*down\b|\bshutdown\b|\bpower\s*off\b|\bturn\s+off\s+(?:the\s+)?(?:pc|computer|laptop|system)\b", t) or \
            re.search(rf"\b(?:pc|computer|laptop|system)\s+{_CLOSE_VERBS}", t):
        return "shutdown", {}, 0.9

    # ── Music ────────────────────────────────────────
    _music = r"(?:music|gaana|gana|gaane|gane|song|songs|playlist|spotify|bhajan)"
    if re.search(rf"{_music}", t) and re.search(r"\b(?:play|laga|lagao|chala|chalao|bajao|baja|suna|sunao|sun|put\s+on|start|khol)\w*", t):
        return "play_music", {}, 0.85
    if re.search(r"\b(?:kuch|koi)\s+suna\s*(?:do|de|dijiye)?\b", t) or re.search(r"\bsunao\b", t):
        return "play_music", {}, 0.8
    if re.search(rf"\bplay\s+(?:some\s+|kuch\s+)?{_music}\b", t):
        return "play_music", {}, 0.9

    # ── System info ──────────────────────────────────
    sysinfo = [
        (r"\b(?:battery|charge|charging|batry)\b", "battery"),
        (r"\b(?:cpu|processor)\b", "cpu"),
        (r"\b(?:ram|memory|mem)\b", "ram"),
        (r"\b(?:disk|storage|hard\s*drive|space)\b", "disk"),
        (r"\bsystem\s*(?:info|status|stats|health|kaisa|kaise)\b", "all"),
        (r"\bsystem\s+kaisa\s+chal", "all"),
        (r"\b(?:pc|laptop|computer)\s+(?:kaisa|kaise|status)\b", "all"),
    ]
    for pattern, info_type in sysinfo:
        if re.search(pattern, t):
            return "system_info", {"type": info_type}, 0.85

    # ── Web search ───────────────────────────────────
    m = (re.search(r"(?:search|google|look\s*up)\s+(?:kar\s*(?:do|o|de)?\s+)?(?:for\s+)?(.+)", t)
         or re.search(r"(.+?)\s+(?:search|google)\s*kar(?:o|do)?$", t))
    if m:
        query = _clean_target(m.group(1))
        if query:
            return "web_search", {"query": query}, 0.85

    # ── Close app ────────────────────────────────────
    m = re.search(r"(?:close|quit|exit|kill)\s+(.+)", t)
    if m:
        app = _clean_target(m.group(1))
        if app:
            return "close_app", {"app": app}, 0.85
    m = re.search(rf"^(.+?)\s+{_CLOSE_VERBS}\s*$", t)
    if m:
        app = _clean_target(m.group(1))
        if app and app not in ("sab", "sab kuch", "everything"):
            return "close_app", {"app": app}, 0.8

    # ── Open app ─────────────────────────────────────
    # English word order: verb first.
    m = re.search(r"(?:open|launch|start|run)\s+(?:up\s+)?(.+)", t)
    if m:
        app = _clean_target(m.group(1))
        if app:
            return "open_app", {"app": app}, 0.85
    # Hindi word order: object first, verb last ("Chrome khol do").
    m = re.search(rf"^(.+?)\s+{_OPEN_VERBS}\s*$", t)
    if m:
        app = _clean_target(m.group(1))
        if app:
            return "open_app", {"app": app}, 0.8

    # ── Small talk ───────────────────────────────────
    small_talk = [
        r"\bjoke\b", r"\bchutkula\b", r"tell me something (?:interesting|fun|cool)",
        r"who\s+are\s+you", r"what\s+are\s+you", r"what\s+can\s+you\s+do",
        r"how\s+are\s+you", r"kaise\s+ho", r"kya\s+haal",
        r"\bthanks?\b", r"thank\s+you", r"shukriya", r"\bdhanyavad\b",
        r"i\s+love\s+you", r"you(?:'re| are)\s+(?:the\s+)?best",
        r"good\s+(?:evening|night|afternoon)", r"\bhello\b", r"\bhi\b",
    ]
    for pattern in small_talk:
        if re.search(pattern, t):
            return "small_talk", {"text": raw}, 0.7

    # ── Anything else is a question for the AI ───────
    return "general_question", {"question": raw}, 0.5


def route_command(text: str) -> tuple[str, dict]:
    """Backwards-compatible wrapper — returns (intent, params) only."""
    intent, params, _confidence = fallback_intent(text)
    return intent, params
