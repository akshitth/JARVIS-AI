"""
J.A.R.V.I.S. — Offline Fast Path

A handful of utterances are TIME-SENSITIVE and must never wait on a network
round trip. They are matched here, locally, in well under 0.1 seconds, before
anything is sent to Gemini for intent parsing:

  * wake words        ("Hey JARVIS", "Daddy's home")
  * standby commands  ("JARVIS standby", "that'll be all")
  * easter eggs       ("I am Iron Man")

Push-to-talk (Ctrl+Space) is also part of the offline path, but it is a
keyboard hotkey handled in main.py rather than a phrase, so it never reaches
this module.

Everything else returns None and continues to the intent engine.
"""

import time

from core.wake_word import check_wake_word, check_sleep_command, is_daddy_home
from core.language import reply_language
from skills.easter_eggs import check_easter_egg

# Kinds of fast-path hit.
WAKE = "wake"
SLEEP = "sleep"
EASTER_EGG = "easter_egg"


class FastHit:
    """A locally-resolved utterance."""

    __slots__ = ("kind", "response", "daddy_home", "elapsed_ms")

    def __init__(self, kind, response="", daddy_home=False, elapsed_ms=0.0):
        self.kind = kind
        self.response = response
        self.daddy_home = daddy_home
        self.elapsed_ms = elapsed_ms

    def __repr__(self):
        return f"FastHit({self.kind}, {self.elapsed_ms:.2f}ms)"


def check(text: str, awake: bool) -> FastHit | None:
    """Resolve an utterance offline, or return None to let Gemini parse it.

    `awake` matters because wake words are only meaningful in STANDBY and sleep
    commands are only meaningful when ACTIVE.
    """
    started = time.perf_counter()

    def _elapsed():
        return (time.perf_counter() - started) * 1000.0

    if not text or not text.strip():
        return None

    # Easter eggs win over everything — they are the whole point of being fun,
    # and they must never cost an API call.
    if check_easter_egg(text):
        return FastHit(EASTER_EGG, elapsed_ms=_elapsed())

    if not awake:
        is_wake, response = check_wake_word(text)
        if is_wake:
            return FastHit(WAKE, response, is_daddy_home(text), _elapsed())
        return None

    if check_sleep_command(text):
        # Sleep commands are mostly English ("that'll be all", "go to sleep"),
        # so the farewell follows the language they were said in.
        if reply_language(text) == "en":
            farewell = "Going to standby, Sir. Call me if you need anything."
        else:
            farewell = "Standby mode mein ja raha hoon, Sir. Zarurat ho toh bula lijiye."
        return FastHit(SLEEP, farewell, elapsed_ms=_elapsed())

    return None
