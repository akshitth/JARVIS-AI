"""
J.A.R.V.I.S. — State Machine

Three explicit states describe exactly what JARVIS is doing at any moment:

  STANDBY  - Idle. Mic is on but only WAKE WORDS are processed. No commands
             are run and NO Gemini API calls are ever made in this state.
  ACTIVE   - Awake (a wake word was heard). Mic is on and full commands are
             processed and routed.
  SPEAKING - JARVIS is talking. The mic is completely OFF (no listening).

Transition map:
  STANDBY  --(wake word)-------> ACTIVE
  ACTIVE   --(command spoken)---> SPEAKING
  SPEAKING --(TTS finished)-----> ACTIVE
  ACTIVE   --(10s inactivity)---> STANDBY

(The spoken wake greeting and the "going to standby" line mean SPEAKING can
also be entered from / returned to STANDBY, so those edges are allowed too.)

All logging here is intentionally ASCII-only so the current state always
prints cleanly to the Windows console.
"""

import threading
from enum import Enum


def _log(msg):
    print(msg, flush=True)


class State(Enum):
    STANDBY = "STANDBY"
    ACTIVE = "ACTIVE"
    SPEAKING = "SPEAKING"


# Allowed transitions: from-state -> set of valid to-states.
_ALLOWED = {
    State.STANDBY:  {State.ACTIVE, State.SPEAKING},
    State.ACTIVE:   {State.SPEAKING, State.STANDBY},
    State.SPEAKING: {State.ACTIVE, State.STANDBY},
}


class StateMachine:
    """Thread-safe holder for the current JARVIS state.

    on_change(old_state, new_state) is invoked (outside the lock) on every
    successful transition so the UI layer can react. It may be called from any
    thread, so the callback must itself be thread-safe (e.g. emit a Qt signal).
    """

    def __init__(self, on_change=None):
        self._state = State.STANDBY
        self._on_change = on_change
        self._lock = threading.RLock()
        _log("[JARVIS][STATE] ====================================")
        _log(f"[JARVIS][STATE]   INITIAL STATE: {self._state.value}")
        _log("[JARVIS][STATE] ====================================")

    @property
    def state(self) -> State:
        return self._state

    def is_standby(self) -> bool:
        return self._state is State.STANDBY

    def is_active(self) -> bool:
        return self._state is State.ACTIVE

    def is_speaking(self) -> bool:
        return self._state is State.SPEAKING

    def to(self, new_state: State, reason: str = "") -> bool:
        """Transition to new_state. Returns True if the state actually changed."""
        with self._lock:
            old = self._state
            if new_state is old:
                return False
            if new_state not in _ALLOWED.get(old, set()):
                _log(f"[JARVIS][STATE] !! ignored invalid transition "
                     f"{old.value} -> {new_state.value}")
                return False
            self._state = new_state
            line = f"[JARVIS][STATE] {old.value} --> {new_state.value}"
            if reason:
                line += f"   ({reason})"
            _log(line)
            cb = self._on_change
        # Call the callback OUTSIDE the lock to avoid any chance of deadlock.
        if cb:
            try:
                cb(old, new_state)
            except Exception as e:  # never let a UI hiccup break state logic
                _log(f"[JARVIS][STATE] on_change error: {e}")
        return True

    def heartbeat(self):
        """Print the current state. Called periodically so it is always visible."""
        _log(f"[JARVIS][STATE] . current = {self._state.value}")
