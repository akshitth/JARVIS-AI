"""
J.A.R.V.I.S. — Speaker Module
Handles Text-to-Speech using Coqui TTS (primary, offline) with edge-tts fallback.

Robustness guarantees (added after the "text shows but no voice" bug):
  * TTS engine status is reported on startup: 'TTS engine status: OK|FAILED'.
  * Every response is SPOKEN and, if generation/playback fails, the error is
    printed and the whole speak is retried ONCE before giving up.
  * Playback is verified — if pygame never actually starts playing (e.g. the
    default output device is a disconnected Bluetooth headset), the mixer is
    reinitialised on a real, openable output device and the audio replayed.
  * The Speaker thread ALWAYS releases the speaking_lock (try/finally) so a TTS
    hiccup can never leave the listener permanently muted.
"""

import os
import threading
import tempfile
import time

import pygame

_tts_engine = None
_tts_type = None  # "coqui" or "edge"
_tts_lock = threading.Lock()
# Serialises ALL pygame audio (mixer) init/quit. SDL's mixer init/quit is NOT
# thread-safe — the main thread (report_tts_status) and the Speaker thread both
# reach _init_pygame at boot, and letting them init/quit concurrently hard-
# crashes the process with no traceback. This lock makes audio setup atomic.
_audio_lock = threading.RLock()
_pygame_initialized = False

# One-word health used by report_tts_status() / main boot log.
TTS_STATUS = "UNKNOWN"       # "OK" | "FAILED" | "UNKNOWN"
TTS_DETAIL = ""

# Name of the output device the mixer is currently using (best-effort).
_output_device = None


def _log(msg):
    """Print with flush for Windows (ASCII-safe)."""
    try:
        print(msg, flush=True)
    except UnicodeEncodeError:
        print(msg.encode("ascii", "replace").decode("ascii"), flush=True)


def _list_output_devices():
    """Best-effort list of CONNECTED output device names (SDL2). A disconnected
    Bluetooth headset will NOT appear here — that's exactly what we want, since
    we must never route audio to a device that isn't really there.

    Call only with the mixer already initialised (SDL audio subsystem up) — this
    avoids a second, racy pygame.init() from another thread."""
    try:
        from pygame._sdl2 import audio as sdl2_audio
    except Exception:
        return []
    try:
        names = sdl2_audio.get_audio_device_names(False)  # False = output/playback
        return [n for n in names if n]
    except Exception:
        return []


def _mixer_init(devicename=None):
    """Initialise pygame.mixer, optionally on a specific output device.
    Returns True on success."""
    try:
        if pygame.mixer.get_init():
            pygame.mixer.quit()
    except Exception:
        pass
    kwargs = dict(frequency=24000, size=-16, channels=1, buffer=4096)
    if devicename:
        kwargs["devicename"] = devicename
    try:
        pygame.mixer.init(**kwargs)
        return True
    except Exception as e:
        _log(f"[JARVIS] Pygame mixer init failed ({devicename or 'default'}): {e}")
        # Last resort: bare defaults.
        try:
            pygame.mixer.init()
            return True
        except Exception as e2:
            _log(f"[JARVIS] Pygame mixer completely failed: {e2}")
            return False


def _init_pygame():
    """Initialise pygame mixer for audio playback on a real output device.
    Thread-safe: serialised by _audio_lock so concurrent boot-time callers can't
    race the (non-thread-safe) SDL mixer init."""
    global _pygame_initialized, _output_device
    if _pygame_initialized:
        return

    with _audio_lock:
        if _pygame_initialized:
            return

        # Bring the mixer up FIRST (on the system default output). SDL follows
        # the Windows default device; bringing the mixer up also initialises the
        # SDL audio subsystem so we can then enumerate connected devices.
        if not _mixer_init():
            _log("[JARVIS] Pygame mixer could not be initialized — voice disabled")
            return

        _pygame_initialized = True
        # Enumerate only CONNECTED outputs, so a disconnected Bluetooth endpoint
        # can never be reported/selected. SDL doesn't expose the chosen name, so
        # report the first connected device for visibility.
        devices = _list_output_devices()
        if devices:
            _log(f"[JARVIS] Audio output devices detected: {devices}")
        _output_device = devices[0] if devices else "system default"
        _log(f"[JARVIS] Pygame mixer initialized (output: {_output_device})")


def _init_tts():
    """Try Coqui TTS first, fall back to edge-tts. Sets TTS_STATUS."""
    global _tts_engine, _tts_type, TTS_STATUS, TTS_DETAIL

    if _tts_engine is not None:
        return

    with _tts_lock:
        if _tts_engine is not None:
            return

        # Try Coqui TTS (offline, preferred)
        try:
            from TTS.api import TTS as CoquiTTS
            _log("[JARVIS] Loading Coqui TTS model...")
            from config import COQUI_MODEL, COQUI_SPEAKER
            engine = CoquiTTS(model_name=COQUI_MODEL, progress_bar=True)
            _tts_engine = engine
            _tts_type = "coqui"
            TTS_STATUS, TTS_DETAIL = "OK", f"Coqui {COQUI_MODEL}"
            _log(f"[JARVIS] Coqui TTS loaded: {COQUI_MODEL} (speaker: {COQUI_SPEAKER})")
            return
        except Exception as e:
            _log(f"[JARVIS] Coqui TTS unavailable ({e}); falling back to edge-tts...")

        # Fallback: edge-tts (online, fast, high quality)
        try:
            import edge_tts  # noqa: F401
            from config import (EDGE_TTS_VOICE_EN, EDGE_TTS_VOICE_HI,
                                TTS_AUTO_SWITCH_VOICE)
            _tts_engine = "edge"
            _tts_type = "edge"
            if TTS_AUTO_SWITCH_VOICE:
                TTS_DETAIL = f"edge-tts {EDGE_TTS_VOICE_EN} / {EDGE_TTS_VOICE_HI}"
                _log(f"[JARVIS] edge-tts ready (English: {EDGE_TTS_VOICE_EN}, "
                     f"Hindi: {EDGE_TTS_VOICE_HI} - auto-switched per response)")
            else:
                TTS_DETAIL = f"edge-tts {EDGE_TTS_VOICE_EN}"
                _log(f"[JARVIS] edge-tts ready ({EDGE_TTS_VOICE_EN} for English "
                     f"AND Hinglish - one voice throughout)")
            TTS_STATUS = "OK"
        except Exception as e:
            _tts_engine = None
            _tts_type = None
            TTS_STATUS, TTS_DETAIL = "FAILED", str(e)
            _log(f"[JARVIS] ERROR: No TTS engine available! {e}")


def report_tts_status() -> str:
    """Ensure TTS + audio are initialised and print a single status line.
    Returns 'OK' or 'FAILED'. Safe to call from the boot sequence."""
    _init_tts()
    _init_pygame()
    ok = _tts_engine is not None and _pygame_initialized
    status = "OK" if ok else "FAILED"
    detail = TTS_DETAIL if ok else (TTS_DETAIL or "no engine / no audio device")
    _log(f"[JARVIS] TTS engine status: {status}  ({detail})")
    return status


def _generate_audio(text: str) -> str | None:
    """Generate speech audio to a temp file. Returns the path or None on failure.

    The edge-tts voice is chosen PER RESPONSE: Hinglish lines get the Hindi
    voice, pure English lines the British one (see core/language.py)."""
    if _tts_type == "edge":
        tmp_file = os.path.join(tempfile.gettempdir(), "jarvis_speech.mp3")
    else:
        tmp_file = os.path.join(tempfile.gettempdir(), "jarvis_speech.wav")

    try:
        os.remove(tmp_file)
    except OSError:
        pass

    if _tts_type == "coqui":
        from config import COQUI_SPEAKER
        _tts_engine.tts_to_file(text=text, file_path=tmp_file, speaker=COQUI_SPEAKER)

    elif _tts_type == "edge":
        import asyncio
        import edge_tts
        from core.language import pick_voice, describe

        voice = pick_voice(text)
        _log(f"[JARVIS][TTS] {describe(text)} detected -> voice {voice}")

        async def _generate():
            communicate = edge_tts.Communicate(text, voice)
            await communicate.save(tmp_file)

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(_generate())
        finally:
            loop.close()

    if os.path.exists(tmp_file) and os.path.getsize(tmp_file) > 0:
        return tmp_file
    return None


def _play_file(path: str) -> bool:
    """Play an audio file through pygame. Returns True only if playback ACTUALLY
    started (get_busy became True) — otherwise the audio went nowhere (e.g. a
    dead output device) and the caller can retry on a different device."""
    _init_pygame()
    if not _pygame_initialized:
        return False
    try:
        pygame.mixer.music.load(path)
        pygame.mixer.music.set_volume(1.0)
        pygame.mixer.music.play()
    except Exception as e:
        _log(f"[JARVIS] Audio playback error: {e}")
        return False

    became_busy = False
    t0 = time.time()
    while time.time() - t0 < 0.6:            # give it up to 0.6s to actually start
        if pygame.mixer.music.get_busy():
            became_busy = True
            break
        time.sleep(0.02)

    while pygame.mixer.music.get_busy():     # wait for playback to finish
        time.sleep(0.05)
    try:
        pygame.mixer.music.unload()
    except Exception:
        pass
    return became_busy


def _reinit_on_working_device() -> bool:
    """Playback produced silence — the current output device is dead (likely a
    disconnected Bluetooth headset). Reinitialise the mixer on the first REAL,
    connected output device so audio reaches the actual speakers."""
    global _pygame_initialized, _output_device
    with _audio_lock:
        devices = _list_output_devices()
        for name in devices:
            if _mixer_init(devicename=name):
                _pygame_initialized = True
                _output_device = name
                _log(f"[JARVIS] Re-routed audio to output device: {name}")
                return True
        # Fall back to the plain default.
        if _mixer_init():
            _pygame_initialized = True
            _output_device = "system default"
            return True
        return False


def _speak_once(text: str) -> bool:
    """Generate + play one utterance. Returns True if the user could hear it."""
    path = _generate_audio(text)
    if not path:
        _log("[JARVIS] TTS generated empty or missing audio file")
        return False
    _log(f"[JARVIS] Playing speech ({os.path.getsize(path)} bytes, output: {_output_device})...")
    played = _play_file(path)
    if not played:
        # Audio didn't actually come out — try a real output device once.
        _log("[JARVIS] Playback produced no sound — re-routing output device and retrying")
        if _reinit_on_working_device():
            played = _play_file(path)
    try:
        os.remove(path)
    except OSError:
        pass
    return played


def speak(text: str, on_start=None, on_done=None):
    """
    Speak the given text using the available TTS engine. Blocks until complete.
    Every call fires on_start (once, before playback) and on_done (once, always).
    On failure the error is printed and the whole speak is retried ONCE.
    """
    _init_tts()
    _init_pygame()

    if on_start:
        try:
            on_start()
        except Exception as e:
            _log(f"[JARVIS] on_start callback error: {e}")

    try:
        if _tts_engine is None:
            _log(f"[JARVIS] (no TTS engine) Would say: {text}")
            return

        ok = False
        for attempt in (1, 2):                       # retry ONCE on failure
            try:
                ok = _speak_once(text)
                if ok:
                    break
                _log(f"[JARVIS] TTS attempt {attempt} produced no audio for: {text!r}")
            except Exception as e:
                _log(f"[JARVIS] TTS error (attempt {attempt}): {e}")
                import traceback
                traceback.print_exc()
            if attempt == 1:
                time.sleep(0.2)
        if not ok:
            _log(f"[JARVIS] TTS FAILED after retry — response was shown as text only: {text!r}")
    finally:
        if on_done:
            try:
                on_done()
            except Exception as e:
                _log(f"[JARVIS] on_done callback error: {e}")


class Speaker(threading.Thread):
    """Background thread for non-blocking speech."""

    def __init__(self):
        super().__init__(daemon=True)
        self._queue = []
        self._lock = threading.Lock()
        self._event = threading.Event()
        self._stop = threading.Event()
        self.is_speaking = False
        self.on_start = None
        self.on_done = None
        # Held for the ENTIRE duration of TTS playback so the listener can
        # discard all audio while JARVIS speaks. Wired to the same Lock the
        # Listener checks (set by the orchestrator in main.py).
        self.speaking_lock = threading.Lock()

    def run(self):
        _init_tts()
        _init_pygame()

        while not self._stop.is_set():
            self._event.wait(timeout=0.1)
            self._event.clear()

            while True:
                with self._lock:
                    if not self._queue:
                        break
                    text = self._queue.pop(0)

                self.is_speaking = True
                # Hold speaking_lock for the whole TTS so the listener discards
                # every frame captured while JARVIS talks (anti self-talk loop).
                # try/finally guarantees the lock is ALWAYS released and
                # is_speaking is cleared even if TTS raises — so a hiccup can
                # never leave the listener permanently muted or the lock stuck.
                acquired = self.speaking_lock.acquire(timeout=10)
                if not acquired:
                    _log("[JARVIS] WARNING: speaking_lock stuck — speaking anyway")
                try:
                    speak(text, on_start=self.on_start, on_done=self.on_done)
                finally:
                    if acquired:
                        try:
                            self.speaking_lock.release()
                        except RuntimeError:
                            pass
                    self.is_speaking = False

    def say(self, text: str):
        """Queue text to be spoken."""
        if not text:
            return
        with self._lock:
            self._queue.append(text)
        self._event.set()

    def boot_test(self):
        """Speak a startup line so the user can confirm voice output works."""
        self.say("All systems online, sir.")

    def stop(self):
        self._stop.set()
        self._event.set()
