"""
J.A.R.V.I.S. — Listener Module
Handles microphone input and faster-whisper based speech-to-text.

Built for NOISY environments:
  * WebRTC VAD detects actual human speech and ignores AC/fans/keyboards/chatter
    (far more reliable than a bare RMS threshold).
  * noisereduce cleans the recorded audio before Whisper for better accuracy.
  * Push-to-talk (Ctrl+Space) bypasses VAD entirely — captures only while held.
  * 'recalibrate' (or F5) re-measures ambient noise on demand (home <-> office).
  * A selectable input device (headset vs laptop mic), remembered across runs.
  * A live RMS level is pushed to the HUD so you can see if your voice lands.
"""

import collections
import os
import queue
import threading
import time

import numpy as np

from config import (WHISPER_DEVICE, WHISPER_COMPUTE_TYPE, WHISPER_LANGUAGE,
                    WHISPER_CPU_THREADS, WHISPER_MODEL_WAKE,
                    WHISPER_MODEL_COMMAND)

try:
    import webrtcvad
    _VAD_OK = True
except Exception:
    _VAD_OK = False

# faster-whisper model, loaded once and cached in memory for the whole session
# Keyed by model name: JARVIS keeps a fast model for wake words and an
# accurate one for commands, and both must survive in memory.
_whisper_models = {}
_whisper_lock = threading.Lock()


def _log(msg):
    try:
        print(msg, flush=True)
    except UnicodeEncodeError:
        print(msg.encode("ascii", "replace").decode("ascii"), flush=True)


def _load_whisper(model_name: str):
    """Load a faster-whisper model once and cache it by name.

    Cached per name rather than in a single slot, because JARVIS keeps two
    models resident (fast for wake words, accurate for commands) and a single
    slot would thrash between them on every state change.
    """
    cached = _whisper_models.get(model_name)
    if cached is not None:
        return cached
    with _whisper_lock:
        cached = _whisper_models.get(model_name)
        if cached is None:
            from faster_whisper import WhisperModel
            _log(f"[JARVIS] Loading faster-whisper model: {model_name} "
                 f"({WHISPER_DEVICE}/{WHISPER_COMPUTE_TYPE})...")
            _log("[JARVIS] (First run will download the model, please wait...)")
            threads = WHISPER_CPU_THREADS or (os.cpu_count() or 4)
            cached = WhisperModel(
                model_name,
                device=WHISPER_DEVICE,
                compute_type=WHISPER_COMPUTE_TYPE,
                cpu_threads=threads,
            )
            _whisper_models[model_name] = cached
            _log(f"[JARVIS] faster-whisper '{model_name}' loaded successfully!")
    return cached


def preload_whisper(model_name: str = None):
    """Warm BOTH models on startup, so neither the first wake word nor the first
    command pays a load stall. They stay in memory (base ~75MB, small ~480MB)."""
    _load_whisper(WHISPER_MODEL_WAKE)
    return _load_whisper(WHISPER_MODEL_COMMAND)


# ── Audio recording parameters ──
RATE = 16000          # Whisper expects 16kHz
CHANNELS = 1
VAD_FRAME_MS = 30     # WebRTC VAD needs 10/20/30ms frames
CHUNK = int(RATE * VAD_FRAME_MS / 1000)   # 480 samples = one 30ms VAD frame
FORMAT_WIDTH = 2      # 16-bit audio = 2 bytes per sample

# ── Speech-detection parameters ──
# Primary detector is WebRTC VAD (human-speech vs noise). RMS is kept only for
# the HUD level bar and the adaptive threshold used by the green/red indicator.
VAD_AGGRESSIVENESS = 1          # 0..3 — lower = more permissive (better for quiet mics)
VAD_START_FRAMES = 5            # ~0.15s of voiced frames to START recording
SILENCE_AFTER_SPEECH_SEC = 0.7  # Stop ~0.7s after you stop speaking (snappy)
VAD_SILENCE_FRAMES = int(SILENCE_AFTER_SPEECH_SEC * 1000 / VAD_FRAME_MS)  # ~23 frames
MAX_RECORDING_SEC = 12          # Max recording length
MIN_RECORDING_SEC = 0.8         # Discard VAD recordings shorter than this
PTT_MIN_SEC = 0.3               # Push-to-talk: shorter min (you triggered it on purpose)
AMBIENT_CALIBRATION_SEC = 3     # Measure ambient noise this long (startup + recalibrate)
AMBIENT_MULTIPLIER = 1.5        # HUD threshold = this x AVERAGE ambient RMS (adaptive)
SENSITIVITY_STEP = 0.10         # "increase/decrease sensitivity" moves threshold +/-10%
HOTSWAP_CHECK_SEC = 4.0         # re-scan for connected/disconnected headsets this often
_THRESHOLD_GUARD = 1e-4         # tiny non-zero guard so a dead-silent mic can't give threshold 0
LEVEL_REPORT_EVERY = 3          # push a mic-level update to the HUD every N frames (~90ms)


class Listener(threading.Thread):
    """
    Background thread that continuously listens to the microphone.
    Uses direct PyAudio recording with simple RMS-based VAD.
    Produces transcribed text into a queue.
    """

    def __init__(self, whisper_model_name: str = "base", result_queue: queue.Queue = None,
                 level_callback=None, speaking_lock=None, state_is_speaking=None,
                 device_index=None, ptt_result_callback=None, device_change_callback=None):
        super().__init__(daemon=True)
        self.whisper_model_name = whisper_model_name
        # Which model transcribes the next clip. STANDBY only has to spot a wake
        # word, so it uses the fast one; ACTIVE needs the exact words. main.py
        # flips this from the state machine via set_awake().
        self._awake = False
        self.result_queue = result_queue or queue.Queue()
        # Called ~5x/sec with (current_rms, threshold) so the UI can show a live
        # mic-level indicator. Runs on this thread — keep the callback cheap.
        self._level_callback = level_callback
        # Chosen input device (headset vs laptop mic); None = system default.
        self.device_index = device_index
        # Push-to-talk results are delivered here (so they can auto-wake JARVIS),
        # falling back to the normal result_queue if not wired.
        self._ptt_result_callback = ptt_result_callback
        self._stop_event = threading.Event()
        self._listening = threading.Event()
        self._listening.set()  # Start in listening mode
        self._pyaudio = None
        self._stream = None

        # WebRTC VAD — primary speech detector for noisy rooms.
        self._vad = webrtcvad.Vad(VAD_AGGRESSIVENESS) if _VAD_OK else None

        # Push-to-talk + recalibrate request flags (set from the hotkey thread).
        self._ptt_active = threading.Event()
        self._recalibrate_request = threading.Event()

        # ── Mic hot-swap (headset connect/disconnect while running) ──
        # device_change_callback(kind, name): kind is 'headset' | 'internal' |
        # 'manual' — used by main to announce the switch.
        self._device_change_callback = device_change_callback
        self._pending_device = None     # (index, manual) requested from another thread
        self._manual_device = False     # True after a voice-command override
        self._last_hotswap = 0.0
        # Calibrated at startup in _measure_ambient; mutable at runtime via the
        # increase/decrease sensitivity commands. Guarded by a lock for the
        # cross-thread reads/writes.
        self._vad_threshold = AMBIENT_MULTIPLIER * 0.005  # provisional until calibrated
        self._thresh_lock = threading.Lock()

        # ── Anti-self-talk: hard mute while JARVIS speaks ──
        # speaking_lock is held by the Speaker for the whole duration of TTS.
        # The listener discards ALL audio while it is locked. _hard_muted is set
        # the instant TTS starts and only cleared 2s after it finishes; while set
        # the input STREAM is physically stopped (not just flagged).
        self.speaking_lock = speaking_lock or threading.Lock()
        self._hard_muted = threading.Event()
        # Optional predicate -> True when the state machine is in SPEAKING.
        self._state_is_speaking = state_is_speaking or (lambda: False)
        self._stream_active = True  # tracks whether the PyAudio stream is running

    def _muted(self) -> bool:
        """True when the listener must do ABSOLUTELY NOTHING (JARVIS speaking)."""
        return (self._hard_muted.is_set()
                or self.speaking_lock.locked()
                or self._state_is_speaking())

    def hard_stop_mic(self):
        """Physically STOP the mic input stream the moment JARVIS starts speaking.
        Not just a flag — halts the PyAudio stream so the OS stops buffering."""
        if self._hard_muted.is_set():
            return
        self._hard_muted.set()
        # Let any in-flight read() (~64ms) finish before halting the stream.
        time.sleep(0.12)
        if self._stream is not None and self._stream_active:
            try:
                self._stream.stop_stream()
                self._stream_active = False
            except Exception:
                pass
        _log("[JARVIS] MIC HARD STOPPED — JARVIS speaking")

    def _flush_stream(self):
        """Discard ONLY the audio already buffered during TTS (JARVIS's own
        voice), capped at ~1 second. We snapshot how much is buffered RIGHT NOW
        and drain just that — we must NOT loop on get_read_available(), which
        would keep eating the user's live speech as it arrives and make JARVIS
        seem deaf."""
        if self._stream is None:
            return
        try:
            buffered = self._stream.get_read_available()
            to_drop = min(buffered // CHUNK, int(RATE / CHUNK))   # cap at ~1s
            for _ in range(to_drop):
                self._stream.read(CHUNK, exception_on_overflow=False)
        except Exception:
            pass

    def hard_restart_mic(self):
        """Restart the mic input stream — called 2s AFTER TTS fully finishes.
        Flushes the buffer first so no stale audio (JARVIS's voice) is processed."""
        if self._stream is not None and not self._stream_active:
            try:
                self._stream.start_stream()
                self._stream_active = True
            except Exception:
                # Stream couldn't be restarted — rebuild it from scratch.
                try:
                    self._close_audio()
                    self._init_audio()
                    self._stream_active = True
                except Exception:
                    pass
        self._flush_stream()        # drop everything buffered during the mute
        self._hard_muted.clear()
        self._listening.set()       # re-enable soft listening too
        _log("[JARVIS] MIC RESTARTED — 1 sec after TTS done")

    def _report_level(self, rms):
        """Push the current mic level + threshold to the UI (if wired)."""
        if self._level_callback is not None:
            try:
                self._level_callback(float(rms), self.get_threshold())
            except Exception:
                pass

    def _model_for_now(self) -> str:
        """The Whisper model appropriate to what JARVIS is listening for."""
        return WHISPER_MODEL_COMMAND if self._awake else WHISPER_MODEL_WAKE

    def set_awake(self, awake: bool):
        """Called by the state machine: STANDBY uses the fast model, ACTIVE the
        accurate one. Both stay loaded, so switching costs nothing."""
        awake = bool(awake)
        if awake != self._awake:
            self._awake = awake
            _log(f"[JARVIS] STT model -> {self._model_for_now()} "
                 f"({'command' if awake else 'wake word'} mode)")

    def get_threshold(self) -> float:
        with self._thresh_lock:
            return self._vad_threshold

    def _set_threshold(self, value: float):
        with self._thresh_lock:
            self._vad_threshold = max(float(value), _THRESHOLD_GUARD)

    def increase_sensitivity(self) -> float:
        """More sensitive = LOWER threshold (hears quieter speech). -10%."""
        new = self.get_threshold() * (1.0 - SENSITIVITY_STEP)
        self._set_threshold(new)
        thr = self.get_threshold()
        _log(f"[JARVIS] Sensitivity INCREASED -> speech threshold {thr:.4f}")
        return thr

    def decrease_sensitivity(self) -> float:
        """Less sensitive = HIGHER threshold (ignores more noise). +10%."""
        new = self.get_threshold() * (1.0 + SENSITIVITY_STEP)
        self._set_threshold(new)
        thr = self.get_threshold()
        _log(f"[JARVIS] Sensitivity DECREASED -> speech threshold {thr:.4f}")
        return thr

    def recalibrate(self):
        """Request a fresh 3s ambient-noise measurement (home <-> office).
        The actual measurement runs on the listener thread (it owns the stream)."""
        _log("[JARVIS] Recalibration requested — re-measuring ambient noise...")
        self._recalibrate_request.set()

    # ── Microphone switching (auto hot-swap + manual override) ──
    def request_device_switch(self, index, manual=True):
        """Ask the listener thread to switch input device ('use microphone N').
        Safe from any thread — the switch is applied on the listener thread."""
        _log(f"[JARVIS] Microphone switch requested -> [{index}]")
        self._pending_device = (int(index), manual)
        return True

    def _apply_device_switch(self, idx, name=None, headset=None, manual=False):
        """Close the current stream and reopen on `idx` (listener thread only).
        Reverts to the old device if the new one fails. Fires the change
        callback and re-calibrates ambient noise for the new mic."""
        old = self.device_index
        try:
            self._close_audio()
        except Exception:
            pass
        self.device_index = idx
        try:
            self._init_audio()
        except Exception as e:
            _log(f"[JARVIS] Could not switch to mic [{idx}]: {e} — reverting.")
            self.device_index = old
            try:
                self._init_audio()
            except Exception:
                pass
            return False
        self._manual_device = manual
        kind = "manual" if manual else ("headset" if headset else "internal")
        _log(f"[JARVIS] Mic switched: [{old}] -> [{idx}] {name or ''} ({kind})")
        if self._device_change_callback is not None:
            try:
                self._device_change_callback(kind, name or f"device {idx}")
            except Exception:
                pass
        self._recalibrate_request.set()   # new mic -> new noise floor
        return True

    def _hotswap_check(self):
        """Every HOTSWAP_CHECK_SEC: re-scan devices; if a headset appeared (or
        the current one vanished), switch automatically. Runs on the listener
        thread. Respects a manual override while that device still works."""
        self._last_hotswap = time.time()
        import core.mic_select as MS
        try:
            devices, default = MS.list_input_devices()
            idx, name, headset = MS.pick_best(devices, default, can_open=MS.can_open)
        except Exception:
            return
        if idx is None or idx == self.device_index:
            return
        if self.device_index is None:
            # We're on the system default: the scan just resolved which index
            # that IS. Adopt it silently — not a device change, no announcement.
            self.device_index = idx
            return
        if self._manual_device:
            # Keep the user's manual pick as long as it still opens.
            try:
                if MS.can_open(self.device_index):
                    return
            except Exception:
                pass
            self._manual_device = False
        _log(f"[JARVIS] Mic hot-swap detected: [{self.device_index}] -> [{idx}] {name}")
        self._apply_device_switch(idx, name=name, headset=headset, manual=False)

    def ptt_start(self):
        """Push-to-talk pressed (Ctrl+Space held) — capture regardless of VAD."""
        if self._muted():
            return
        if not self._ptt_active.is_set():
            self._ptt_active.set()
            _log("[JARVIS] PUSH-TO-TALK ON — listening (release Ctrl+Space to send)")

    def ptt_stop(self):
        """Push-to-talk released — stop capturing and transcribe what was said."""
        if self._ptt_active.is_set():
            self._ptt_active.clear()
            _log("[JARVIS] PUSH-TO-TALK OFF — processing...")

    def _init_audio(self):
        """Open the chosen microphone, falling back to the default / any working
        device if the saved one is unavailable (e.g. an unplugged BT headset)."""
        import pyaudio
        self._pyaudio = pyaudio.PyAudio()

        try:
            default_index = self._pyaudio.get_default_input_device_info()['index']
        except Exception:
            default_index = None

        # Try, in order: the chosen device, the system default, then let PyAudio
        # pick. Deduplicated, preserving order.
        candidates = []
        for idx in (self.device_index, default_index, None):
            if idx not in candidates:
                candidates.append(idx)

        _log(f"[JARVIS] Speech detection: {'WebRTC VAD' if self._vad else 'RMS'} "
             f"(aggressiveness {VAD_AGGRESSIVENESS})")

        last_err = None
        for idx in candidates:
            try:
                name = self._pyaudio.get_device_info_by_index(idx)['name'] \
                    if idx is not None else "default"
            except Exception:
                name = "default"
            try:
                self._stream = self._pyaudio.open(
                    format=pyaudio.paInt16,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    input_device_index=idx,
                    frames_per_buffer=CHUNK,
                )
            except Exception as e:
                last_err = e
                _log(f"[JARVIS] Microphone [{idx}] {name} unavailable: {e}")
                continue

            self._stream_active = True
            if self.device_index is not None and idx != self.device_index:
                # The saved device failed — forget it so it's re-picked next run.
                _log(f"[JARVIS] Saved mic [{self.device_index}] unavailable — "
                     f"using [{idx}] {name} instead.")
                try:
                    from core.mic_select import clear_saved_device
                    clear_saved_device()
                except Exception:
                    pass
            self.device_index = idx
            _log(f"[JARVIS] Using microphone: [{idx}] {name}")
            _log("[JARVIS] Audio stream opened successfully")
            return

        raise last_err if last_err else RuntimeError("No input device could be opened")

    # ── Speech / noise helpers ───────────────────────
    def _is_voiced(self, data: bytes) -> bool:
        """True if this 30ms frame is speech.

        Hybrid so a QUIET laptop mic is never missed AND noisy rooms still work:
          * RMS gate (PRIMARY) — frame is louder than the adaptive ambient
            threshold. Speech is louder than the room, so this reliably catches
            quiet laptop-mic voices and rejects steady room noise by amplitude.
          * WebRTC VAD on the RAW frame — an extra trigger for normal-level mics
            (headset) in noise. Run on the raw signal (NOT amplified) so quiet
            room noise isn't boosted into the speech range and falsely detected.
        A frame counts as voiced if EITHER fires. The VAD path is gated behind a
        minimum energy floor (half the threshold) so it can never fire on
        near-silence — webrtcvad otherwise false-triggers on faint broadband hiss.
        """
        thr = self.get_threshold()
        audio = np.frombuffer(data, np.int16).astype(np.float32) / 32768.0
        rms = float(np.sqrt(np.mean(audio ** 2)))
        if rms > thr:
            return True
        if self._vad is None or rms < 0.5 * thr:
            return False
        try:
            return self._vad.is_speech(data, RATE)
        except Exception:
            return False

    def _denoise(self, audio: np.ndarray) -> np.ndarray:
        """Apply spectral noise reduction before Whisper (cleans AC/fan/chatter)."""
        try:
            import noisereduce as nr
            reduced = nr.reduce_noise(y=audio, sr=RATE, stationary=True)
            return reduced.astype(np.float32)
        except Exception as e:
            _log(f"[JARVIS] Noise reduction skipped: {e}")
            return audio

    def _close_audio(self):
        """Close audio stream and PyAudio."""
        if self._stream:
            try:
                self._stream.stop_stream()
                self._stream.close()
            except Exception:
                pass
        if self._pyaudio:
            try:
                self._pyaudio.terminate()
            except Exception:
                pass

    def _measure_ambient(self, duration_sec=AMBIENT_CALIBRATION_SEC):
        """Listen to `duration_sec` of silence on startup, measure the AVERAGE
        ambient noise RMS, and set the speech threshold to AMBIENT_MULTIPLIER x
        that average. Fully adaptive — no hardcoded RMS value."""
        _log(f"[JARVIS] Calibrating ambient noise ({duration_sec}s, please stay quiet)...")
        chunks_needed = int(RATE * duration_sec / CHUNK)
        rms_values = []

        for _ in range(chunks_needed):
            # Abort mid-measurement if JARVIS starts speaking or we're stopping.
            if self._stop_event.is_set() or self._muted():
                break
            try:
                data = self._stream.read(CHUNK, exception_on_overflow=False)
                audio = np.frombuffer(data, np.int16).astype(np.float32) / 32768.0
                rms = np.sqrt(np.mean(audio ** 2))
                rms_values.append(rms)
            except Exception:
                continue

        if rms_values:
            ambient_rms = float(np.mean(rms_values))
            threshold = max(ambient_rms * AMBIENT_MULTIPLIER, _THRESHOLD_GUARD)
            _log(f"[JARVIS] Ambient noise: {ambient_rms:.4f}, "
                 f"Speech threshold set to: {threshold:.4f}")
            return threshold
        return AMBIENT_MULTIPLIER * 0.005

    _HALLUCINATIONS = {
        "", ".", "you", "thank you", "thanks for watching",
        "thank you for watching", "the end", "bye",
        "thanks for watching!", "subscribe",
    }

    def _transcribe_frames(self, frames, source, min_sec):
        """Noise-reduce + normalize + transcribe a list of raw PCM frames.
        Returns clean text, or None if rejected. `source` is 'VAD' or 'PTT'."""
        if not frames:
            return None
        raw_data = b''.join(frames)
        audio_data = np.frombuffer(raw_data, np.int16).astype(np.float32) / 32768.0
        duration_sec = len(audio_data) / RATE
        rec_rms = float(np.sqrt(np.mean(audio_data ** 2))) if len(audio_data) else 0.0
        thr = self.get_threshold()

        if duration_sec < min_sec:
            _log(f"[JARVIS] Heard audio ({source}) — RMS: {rec_rms:.4f}, "
                 f"Threshold: {thr:.4f} — REJECTED (too short)")
            return None

        # ── Noise reduction (clean AC/fan/keyboard/chatter) BEFORE Whisper ──
        audio_data = self._denoise(audio_data)

        # ── Normalize amplitude (up to 50x gain for quiet/headset mics) ──
        peak = float(np.max(np.abs(audio_data))) if len(audio_data) else 0.0
        gain_applied = 1.0
        if peak > 0.001:
            gain_applied = min(0.7 / peak, 50.0)
            audio_data = np.clip(audio_data * gain_applied, -1.0, 1.0)

        model = _load_whisper(self._model_for_now())
        # WHISPER_LANGUAGE is forced to "en" rather than auto-detected: on
        # Hinglish, auto-detect flips to Hindi and returns Devanagari, which
        # nothing downstream can parse. English decoding gives romanized
        # Hinglish, which is what JARVIS wants. See config.py. The
        # initial_prompt is deliberately bilingual and romanized: it biases the
        # decoder towards writing Hindi in Latin script (which the intent parser
        # and the offline fallback both handle) instead of Devanagari.
        segments, info = model.transcribe(
            audio_data,
            language=WHISPER_LANGUAGE,
            beam_size=1,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=300),
            no_speech_threshold=0.6,
            condition_on_previous_text=False,
            initial_prompt=(
                "Hey Jarvis, open Chrome. Jarvis, what time is it? "
                "Jarvis, Chrome khol do. Kitne baje hain? Gaana laga do. "
                "Battery kitni hai? Sab band kar de."
            ),
        )
        text = "".join(seg.text for seg in segments).strip()
        detected = getattr(info, "language", None)
        if WHISPER_LANGUAGE is None and detected:
            probability = getattr(info, "language_probability", 0.0) or 0.0
            _log(f"[JARVIS] Language detected: {detected} ({probability:.0%})")
        if not text or text.lower().strip(".!?, ") in self._HALLUCINATIONS or len(text) <= 1:
            _log(f"[JARVIS] Heard audio ({source}) — RMS: {rec_rms:.4f}, "
                 f"Threshold: {thr:.4f} — REJECTED (noise)")
            return None

        _log(f"[JARVIS] Heard audio ({source}) — RMS: {rec_rms:.4f}, "
             f"Threshold: {thr:.4f}, gain: {gain_applied:.1f}x — ACCEPTED")
        _log(f"[JARVIS] HEARD: {text}")
        return text

    def _record_push_to_talk(self):
        """Capture frames for as long as Ctrl+Space is held, then transcribe.
        VAD is bypassed entirely — background noise is irrelevant here."""
        frames = []
        max_frames = int(MAX_RECORDING_SEC * 1000 / VAD_FRAME_MS)
        while (self._ptt_active.is_set() and not self._stop_event.is_set()
               and not self._muted() and len(frames) < max_frames):
            try:
                data = self._stream.read(CHUNK, exception_on_overflow=False)
            except Exception:
                continue
            frames.append(data)
            audio = np.frombuffer(data, np.int16).astype(np.float32) / 32768.0
            self._report_level(float(np.sqrt(np.mean(audio ** 2))))
        text = self._transcribe_frames(frames, "PTT", PTT_MIN_SEC)
        if text:
            if self._ptt_result_callback is not None:
                self._ptt_result_callback(text)   # auto-wakes JARVIS
            else:
                self.result_queue.put(text)

    def run(self):
        """Main listening loop."""
        try:
            self._init_audio()
        except Exception as e:
            _log(f"[JARVIS] FATAL: Could not initialize microphone: {e}")
            import traceback
            traceback.print_exc()
            return

        _load_whisper(self.whisper_model_name)
        self._set_threshold(self._measure_ambient())
        _log("[JARVIS] Listener thread started -- actively listening for speech...")

        prebuffer = collections.deque(maxlen=VAD_START_FRAMES)
        level_tick = 0

        while not self._stop_event.is_set():
            # ── Apply a requested manual mic switch ('use microphone N') ──
            if self._pending_device is not None and not self._muted():
                idx, manual = self._pending_device
                self._pending_device = None
                self._apply_device_switch(idx, manual=manual)
                continue

            # ── Hot-swap scan: headset connected/disconnected while running ──
            if ((time.time() - self._last_hotswap) >= HOTSWAP_CHECK_SEC
                    and self._listening.is_set() and not self._muted()
                    and not self._ptt_active.is_set()):
                self._hotswap_check()

            # ── Recalibrate on request (only when active & not speaking) ──
            if self._recalibrate_request.is_set():
                if self._listening.is_set() and not self._muted():
                    self._recalibrate_request.clear()
                    self._set_threshold(self._measure_ambient())
                    _log("[JARVIS] Recalibration complete.")
                else:
                    time.sleep(0.05)
                continue

            # ── Push-to-talk takes priority: capture while held ──
            if self._ptt_active.is_set() and not self._muted():
                self._record_push_to_talk()
                continue

            # Do NOTHING while JARVIS is speaking (stream is physically stopped).
            if not self._listening.is_set() or self._muted():
                time.sleep(0.05)
                continue

            try:
                # ── Phase 1: wait for VAD-detected speech to start ──
                voiced_run = 0
                started = False
                prebuffer.clear()
                while (not self._stop_event.is_set() and self._listening.is_set()
                       and not self._muted() and not self._ptt_active.is_set()
                       and not self._recalibrate_request.is_set()
                       and self._pending_device is None):
                    # Hot-swap scan also runs inside the idle wait (this loop can
                    # spin for minutes between commands).
                    if (time.time() - self._last_hotswap) >= HOTSWAP_CHECK_SEC:
                        self._hotswap_check()
                    try:
                        data = self._stream.read(CHUNK, exception_on_overflow=False)
                    except Exception:
                        time.sleep(0.01)
                        continue
                    prebuffer.append(data)

                    audio = np.frombuffer(data, np.int16).astype(np.float32) / 32768.0
                    level_tick += 1
                    if level_tick % LEVEL_REPORT_EVERY == 0:
                        self._report_level(float(np.sqrt(np.mean(audio ** 2))))

                    if self._is_voiced(data):
                        voiced_run += 1
                        if voiced_run >= VAD_START_FRAMES:
                            started = True
                            break
                    else:
                        voiced_run = 0

                if not started:
                    continue

                # ── Phase 2: record until VAD reports sustained silence ──
                frames = list(prebuffer)   # keep the leading voiced frames
                silence_run = 0
                max_frames = int(MAX_RECORDING_SEC * 1000 / VAD_FRAME_MS)
                for _ in range(max_frames):
                    if self._stop_event.is_set() or not self._listening.is_set():
                        break
                    # Abandon this recording if JARVIS starts speaking, or the
                    # user requests push-to-talk / recalibration mid-utterance.
                    if (self._muted() or self._ptt_active.is_set()
                            or self._recalibrate_request.is_set()):
                        frames = []
                        break
                    try:
                        data = self._stream.read(CHUNK, exception_on_overflow=False)
                    except Exception:
                        continue
                    frames.append(data)
                    audio = np.frombuffer(data, np.int16).astype(np.float32) / 32768.0
                    self._report_level(float(np.sqrt(np.mean(audio ** 2))))

                    if self._is_voiced(data):
                        silence_run = 0
                    else:
                        silence_run += 1
                        if silence_run >= VAD_SILENCE_FRAMES:
                            break

                text = self._transcribe_frames(frames, "VAD", MIN_RECORDING_SEC)
                if text:
                    self.result_queue.put(text)

            except OSError as e:
                _log(f"[JARVIS] Mic OS error: {e}")
                time.sleep(2)
                try:
                    self._close_audio()
                    self._init_audio()
                except Exception:
                    pass
            except Exception as e:
                _log(f"[JARVIS] Listener error: {e}")
                import traceback
                traceback.print_exc()
                time.sleep(1)

        self._close_audio()

    def pause(self):
        """Pause listening."""
        _log("[JARVIS] Listener paused")
        self._listening.clear()

    def resume(self):
        """Resume listening."""
        _log("[JARVIS] Listener resumed")
        self._listening.set()

    def stop(self):
        """Stop the listener thread."""
        _log("[JARVIS] Listener stopping...")
        self._stop_event.set()
