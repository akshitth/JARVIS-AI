"""
J.A.R.V.I.S. — Intent Engine

EVERY command now goes through here. Nothing is matched against hardcoded
phrases first — the utterance is sent to Gemini, which returns a small JSON
object describing what the user meant:

    {"intent": "open_app", "params": {"app": "Chrome"}, "confidence": 0.95}

That means "Chrome khol do", "open Chrome", "browser open karo" and "Chrome
chala do" all arrive at the dispatcher as the same intent.

Design notes:
  * SPEED — the intent call uses the fastest Gemini tier with thinking
    disabled, JSON response mode, and a 100-token ceiling, because all it has
    to emit is ~40 tokens of JSON. Round trip is ~1.0-1.5s.
  * NEVER GO DEAF — if Gemini 429s, times out, or returns junk, we fall back
    to the offline pattern matcher in core/command_router.py. JARVIS degrades,
    it does not stop working.
  * The execution layer is entirely local. This module only decides WHAT the
    user wants; core/dispatcher.py does it.
"""

import json
import re
import threading
import time

from config import (
    GEMINI_API_KEY,
    INTENT_SYSTEM_PROMPT,
    INTENT_MODEL,
    INTENT_FALLBACK_MODELS,
    INTENT_MAX_TOKENS,
    INTENT_MIN_CONFIDENCE,
    INTENT_TIMEOUT_SECONDS,
)
from core.command_router import fallback_intent, KNOWN_INTENTS


def _log(msg):
    print(msg, flush=True)


class Intent:
    """The parsed result of one utterance."""

    __slots__ = ("intent", "params", "confidence", "source", "latency_ms", "raw_text")

    def __init__(self, intent, params=None, confidence=0.0, source="fallback",
                 latency_ms=0, raw_text=""):
        self.intent = intent
        self.params = params or {}
        self.confidence = float(confidence)
        self.source = source            # "gemini" | "fallback" | "local"
        self.latency_ms = latency_ms
        self.raw_text = raw_text

    def __repr__(self):
        return (f"Intent({self.intent}, {self.params}, "
                f"conf={self.confidence:.2f}, via={self.source})")


# ── Gemini client ────────────────────────────────────
_client = None
_client_kind = None       # "genai" (new SDK) | "legacy"
_client_lock = threading.Lock()

# After a quota/availability failure, skip Gemini entirely for a while rather
# than making the user wait through a doomed call on every single command.
_blackout_until = 0.0
_BLACKOUT_SECONDS = 45


def _init_client() -> bool:
    global _client, _client_kind
    if _client is not None:
        return True
    if not GEMINI_API_KEY:
        return False
    with _client_lock:
        if _client is not None:
            return True
        try:
            from google import genai
            _client = genai.Client(api_key=GEMINI_API_KEY)
            _client_kind = "genai"
            return True
        except ImportError:
            pass
        except Exception as e:
            _log(f"[JARVIS][INTENT] Gemini client init failed: {e}")
            return False
        try:
            import google.generativeai as genai_legacy
            genai_legacy.configure(api_key=GEMINI_API_KEY)
            _client = "legacy"
            _client_kind = "legacy"
            return True
        except Exception as e:
            _log(f"[JARVIS][INTENT] Gemini client init failed: {e}")
            return False


def is_available() -> bool:
    """True when Gemini intent parsing can currently be attempted."""
    return bool(GEMINI_API_KEY) and time.time() >= _blackout_until and _init_client()


def in_blackout() -> bool:
    """True while the API is being skipped after a recent failure.

    Other Gemini callers check this so that one outage costs one wait, not one
    per call: a question used to re-try the whole model chain seconds after
    intent parsing had just watched every model fail.
    """
    return time.time() < _blackout_until


def _models() -> list[str]:
    chain = [INTENT_MODEL] + list(INTENT_FALLBACK_MODELS)
    seen, out = set(), []
    for m in chain:
        if m and m not in seen:
            seen.add(m)
            out.append(m)
    return out


def _call_gemini(prompt: str, model: str) -> str:
    """One intent-parsing call. Returns raw response text."""
    if _client_kind == "legacy":
        import google.generativeai as genai_legacy
        gmodel = genai_legacy.GenerativeModel(
            model_name=model,
            system_instruction=INTENT_SYSTEM_PROMPT,
            generation_config={
                "max_output_tokens": INTENT_MAX_TOKENS,
                "temperature": 0.0,
                "response_mime_type": "application/json",
            },
        )
        return (gmodel.generate_content(prompt).text or "").strip()

    from google.genai import types
    config = types.GenerateContentConfig(
        system_instruction=INTENT_SYSTEM_PROMPT,
        max_output_tokens=INTENT_MAX_TOKENS,
        temperature=0.0,
        response_mime_type="application/json",
        # Thinking OFF: this is pure classification, and on a 100-token budget
        # a thinking model would spend the entire allowance reasoning and
        # return an empty body.
        thinking_config=types.ThinkingConfig(thinking_budget=0),
    )
    response = _client.models.generate_content(
        model=model, contents=prompt, config=config
    )
    return (response.text or "").strip()


def _extract_json(text: str) -> dict | None:
    """Pull a JSON object out of a model response, tolerating stray prose."""
    if not text:
        return None
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text).strip()
    try:
        data = json.loads(text)
        return data if isinstance(data, dict) else None
    except json.JSONDecodeError:
        pass
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        try:
            data = json.loads(match.group(0))
            return data if isinstance(data, dict) else None
        except json.JSONDecodeError:
            return None
    return None


def _coerce(data: dict, raw_text: str) -> Intent | None:
    """Validate a parsed JSON payload into an Intent, or None if unusable."""
    name = str(data.get("intent", "")).strip().lower()
    if not name:
        return None
    # The model occasionally emits a near-miss name; accept the obvious ones.
    aliases = {
        "easter_egg_iron_man": "easter_egg_ironman",
        "ironman": "easter_egg_ironman",
        "search": "web_search",
        "reminder": "set_reminder",
        "volume": "volume_control",
        "briefing": "morning_briefing",
        "system": "system_info",
        "question": "general_question",
        "lock": "lock_pc",
    }
    name = aliases.get(name, name)
    if name not in KNOWN_INTENTS:
        return None

    params = data.get("params") or {}
    if not isinstance(params, dict):
        params = {}

    # "band kar de" is ambiguous in Hinglish and the model splits on it: with an
    # explicit machine noun ("PC band kar do") it means SHUT DOWN, but with a
    # bare "sab" ("sab band kar de") the user means LOCK EVERYTHING. Which one
    # was meant is decided by the object, so that is what we look at.
    if name in ("close_app", "shutdown"):
        target = str(params.get("app", "")).strip().lower()
        lowered = (raw_text or "").lower()
        names_machine = bool(re.search(
            r"\b(?:pc|computer|laptop|system|desktop|machine|shut\s*down|shutdown|"
            r"power\s*off)\b", lowered))
        # Only a short, objectless "everything" phrase — never "close all Chrome
        # tabs", which names its target. The word boundaries matter:
        # without them "call karo" contains "all".
        says_everything = (
            bool(re.search(r"\b(?:sab|sabkuch|everything|all)\b", lowered))
            and len(lowered.split()) <= 6
            and target in ("", "all", "everything", "sab", "sab kuch", "sabkuch", "screen")
        )
        if says_everything and not names_machine:
            name, params = "lock_pc", {}
        elif name == "close_app" and target in {
                "pc", "computer", "laptop", "system", "desktop", "machine"}:
            name, params = "shutdown", {}
    # Normalize values to plain strings so the dispatcher never sees a dict.
    params = {str(k): (v if isinstance(v, (int, float)) else str(v))
              for k, v in params.items() if v not in (None, "", [])}

    try:
        confidence = float(data.get("confidence", 0.8))
    except (TypeError, ValueError):
        confidence = 0.8
    confidence = max(0.0, min(1.0, confidence))

    return Intent(name, params, confidence, "gemini", raw_text=raw_text)


def _build_prompt(text: str, context: str = "", memory_hint: str = "") -> str:
    """The user turn sent alongside the system prompt."""
    parts = []
    if context:
        parts.append(context)
    if memory_hint:
        parts.append(f"Known facts about the user:\n{memory_hint}")
    parts.append(f'Classify this utterance: "{text}"')
    return "\n\n".join(parts)


def parse_intent(text: str, context: str = "", memory_hint: str = "") -> Intent:
    """Parse an utterance into an Intent.

    Gemini first (that is the whole point of the rewrite); the offline pattern
    matcher only as a backup so JARVIS never becomes completely deaf.
    """
    global _blackout_until

    raw_text = (text or "").strip()
    if not raw_text:
        return Intent("unknown", {}, 0.0, "local", raw_text=raw_text)

    started = time.time()

    if not is_available():
        reason = "no API key" if not GEMINI_API_KEY else "cooling down after an API failure"
        result = _fallback(raw_text, started)
        _log(f"[JARVIS][INTENT] Gemini skipped ({reason}) -> offline parser")
        return result

    prompt = _build_prompt(raw_text, context, memory_hint)
    last_error = ""

    for i, model in enumerate(_models()):
        if time.time() - started > INTENT_TIMEOUT_SECONDS:
            _log(f"[JARVIS][INTENT] Budget of {INTENT_TIMEOUT_SECONDS}s exhausted "
                 f"-> offline parser")
            break
        try:
            response_text = _call_gemini(prompt, model)
            data = _extract_json(response_text)
            if data is None:
                last_error = f"unparseable response: {response_text[:80]!r}"
                continue
            parsed = _coerce(data, raw_text)
            if parsed is None:
                last_error = f"unknown intent in: {response_text[:80]!r}"
                continue

            parsed.latency_ms = int((time.time() - started) * 1000)
            if i > 0:
                _log(f"[JARVIS][INTENT] answered via fallback model: {model}")

            # Low confidence or an explicit 'unknown': give the offline parser a
            # second opinion — it is very good at the fixed command vocabulary.
            if parsed.intent == "unknown" or parsed.confidence < INTENT_MIN_CONFIDENCE:
                alt_intent, alt_params, alt_conf = fallback_intent(raw_text)
                if alt_intent not in ("unknown", "general_question") and alt_conf >= 0.7:
                    _log(f"[JARVIS][INTENT] Gemini said '{parsed.intent}' "
                         f"({parsed.confidence:.2f}); offline parser is more "
                         f"certain -> {alt_intent}")
                    return Intent(alt_intent, alt_params, alt_conf, "fallback",
                                  parsed.latency_ms, raw_text)
            return parsed

        except Exception as e:
            error_text = str(e).lower()
            last_error = str(e)[:140]
            transient = any(k in error_text for k in (
                "429", "quota", "rate limit", "resource_exhausted", "resource exhausted",
                "503", "unavailable", "overloaded", "high demand", "timeout",
                "deadline", "500", "internal",
            ))
            _log(f"[JARVIS][INTENT] {model} failed: {last_error}")
            if transient:
                continue
            # Auth/config errors will fail on every model — stop early.
            break

    # Every model failed: back off so the next command is not also slow.
    _blackout_until = time.time() + _BLACKOUT_SECONDS
    _log(f"[JARVIS][INTENT] Gemini unavailable ({last_error or 'all models failed'}) "
         f"-> offline parser for the next {_BLACKOUT_SECONDS}s")
    return _fallback(raw_text, started)


def _fallback(raw_text: str, started: float) -> Intent:
    intent, params, confidence = fallback_intent(raw_text)
    return Intent(intent, params, confidence, "fallback",
                  int((time.time() - started) * 1000), raw_text)


def reset_blackout():
    """Clear the API back-off (used by 'recalibrate' and by tests)."""
    global _blackout_until
    _blackout_until = 0.0
