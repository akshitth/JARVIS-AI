"""
J.A.R.V.I.S. — Memory Store

Three distinct kinds of memory, deliberately kept separate:

  MemoryStore          persistent facts the user told JARVIS to remember
                       (memory.json). Survives restarts. Searched BEFORE any
                       Gemini call, so a known answer costs zero API quota.
  Profile              who the user is (profile.json) — name, nickname,
                       language, location. Injected into Gemini prompts so
                       replies are personal without the user repeating himself.
  ConversationContext  the last N turns of THIS session, in RAM only. Lets
                       "tell me more about that" / "what did I just ask" work.

All file access is guarded by a lock and every write is atomic (temp file +
replace) so a crash mid-save can never leave a truncated memory.json.
"""

import json
import os
import re
import tempfile
import threading
from datetime import datetime

from config import MEMORY_FILE, PROFILE_FILE, CONTEXT_TURNS, DEFAULT_PROFILE


def _log(msg):
    print(msg, flush=True)


def _atomic_write(path: str, data: dict):
    """Write JSON without ever leaving a half-written file behind."""
    directory = os.path.dirname(os.path.abspath(path))
    fd, tmp = tempfile.mkstemp(dir=directory, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


# ── Stop words ───────────────────────────────────────
# Dropped before matching so "meri meeting kab hai" still finds the memory
# "meeting at 5pm". Covers English + romanized Hindi filler.
_STOPWORDS = {
    "a", "an", "the", "is", "are", "was", "were", "do", "does", "did", "you",
    "your", "my", "me", "i", "of", "for", "to", "in", "on", "at", "about",
    "what", "when", "where", "who", "which", "how", "remember", "recall",
    "forget", "tell", "know", "jarvis", "sir", "please", "and", "that", "this",
    # Romanized Hindi filler
    "mera", "meri", "mere", "kya", "kab", "kaha", "kahan", "kaun", "kaise",
    "hai", "hain", "tha", "thi", "ko", "ka", "ki", "ke", "se", "par",
    "yaad", "rakh", "rakho", "bhool", "bhul", "ja", "jao", "bata", "batao",
    "de", "do", "kar", "karo", "hu", "hoon", "ho", "bhai", "wala", "wali",
    "mujhe", "tumhe", "aap", "tum", "koi", "kuch", "ek",
}


def _tokens(text: str) -> list[str]:
    """Lowercase content words, stop words removed."""
    words = re.findall(r"[a-z0-9ऀ-ॿ]+", (text or "").lower())
    return [w for w in words if w not in _STOPWORDS and len(w) > 1]


class MemoryStore:
    """Persistent 'remember this' facts, stored in memory.json."""

    def __init__(self, path: str = MEMORY_FILE):
        self.path = path
        self._lock = threading.RLock()
        self._data = {"memories": []}
        self._load()

    # ── persistence ──────────────────────────────────
    def _load(self):
        with self._lock:
            if not os.path.exists(self.path):
                self._save()
                _log(f"[JARVIS][MEMORY] Created {os.path.basename(self.path)}")
                return
            try:
                with open(self.path, encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict) and isinstance(data.get("memories"), list):
                    self._data = data
                else:
                    _log("[JARVIS][MEMORY] memory.json malformed — starting fresh")
            except Exception as e:
                _log(f"[JARVIS][MEMORY] Could not read memory.json ({e}) — starting fresh")
            _log(f"[JARVIS][MEMORY] Loaded {len(self._data['memories'])} memories")

    def _save(self):
        with self._lock:
            try:
                _atomic_write(self.path, self._data)
            except Exception as e:
                _log(f"[JARVIS][MEMORY] Save failed: {e}")

    # ── API ──────────────────────────────────────────
    def remember(self, what: str) -> str:
        """Store a fact. Returns the cleaned text actually stored."""
        what = (what or "").strip().rstrip(".")
        if not what:
            return ""
        with self._lock:
            now = datetime.now()
            # Refresh a near-identical existing memory instead of duplicating.
            for entry in self._data["memories"]:
                if entry["text"].lower() == what.lower():
                    entry["updated"] = now.isoformat(timespec="seconds")
                    self._save()
                    return what
            next_id = max((m.get("id", 0) for m in self._data["memories"]), default=0) + 1
            self._data["memories"].append({
                "id": next_id,
                "text": what,
                "created": now.isoformat(timespec="seconds"),
                "created_human": now.strftime("%A, %d %B %Y at %I:%M %p"),
            })
            self._save()
        _log(f"[JARVIS][MEMORY] Saved: {what}")
        return what

    def search(self, query: str, limit: int = 3) -> list[dict]:
        """Keyword-overlap search. Best matches first, empty list if nothing."""
        q = _tokens(query)
        if not q:
            return []
        scored = []
        for entry in self.all():
            words = set(_tokens(entry["text"]))
            if not words:
                continue
            hits = sum(1 for t in q if t in words)
            # Substring credit catches "meeting" inside "team-meeting".
            hits += sum(0.5 for t in q if t not in words and t in entry["text"].lower())
            if hits:
                scored.append((hits / len(q), entry))
        scored.sort(key=lambda pair: (-pair[0], -pair[1].get("id", 0)))
        return [entry for score, entry in scored[:limit] if score >= 0.34]

    def recall(self, query: str) -> str | None:
        """Return the best matching memory's text, or None."""
        matches = self.search(query, limit=1)
        return matches[0]["text"] if matches else None

    def forget(self, what: str) -> str | None:
        """Delete the best matching memory. Returns its text, or None."""
        matches = self.search(what, limit=1)
        if not matches:
            return None
        target = matches[0]
        with self._lock:
            self._data["memories"] = [
                m for m in self._data["memories"] if m.get("id") != target.get("id")
            ]
            self._save()
        _log(f"[JARVIS][MEMORY] Forgot: {target['text']}")
        return target["text"]

    def all(self) -> list[dict]:
        with self._lock:
            return list(self._data["memories"])

    def count(self) -> int:
        with self._lock:
            return len(self._data["memories"])


class Profile:
    """User profile (profile.json) — seeded from DEFAULT_PROFILE on first run."""

    def __init__(self, path: str = PROFILE_FILE, defaults: dict | None = None):
        self.path = path
        self._lock = threading.RLock()
        self._data = dict(defaults if defaults is not None else DEFAULT_PROFILE)
        self._load()

    def _load(self):
        with self._lock:
            if not os.path.exists(self.path):
                self._save()
                _log(f"[JARVIS][PROFILE] Created {os.path.basename(self.path)} "
                     f"for {self._data.get('name')}")
                return
            try:
                with open(self.path, encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    # Keys added to DEFAULT_PROFILE later still appear for
                    # users whose profile.json predates them.
                    merged = dict(self._data)
                    merged.update(data)
                    self._data = merged
            except Exception as e:
                _log(f"[JARVIS][PROFILE] Could not read profile.json ({e}) — using defaults")
            _log(f"[JARVIS][PROFILE] {self._data.get('name')} "
                 f"({self._data.get('language')}, {self._data.get('location')})")

    def _save(self):
        with self._lock:
            try:
                _atomic_write(self.path, self._data)
            except Exception as e:
                _log(f"[JARVIS][PROFILE] Save failed: {e}")

    def get(self, key: str, default=None):
        with self._lock:
            return self._data.get(key, default)

    def set(self, key: str, value):
        with self._lock:
            self._data[key] = value
            self._save()

    @property
    def name(self) -> str:
        return self.get("name", "Sir")

    @property
    def nickname(self) -> str:
        return self.get("nickname", "Sir")

    @property
    def location(self) -> str:
        return self.get("location", "Noida")

    @property
    def language(self) -> str:
        return self.get("language", "Hinglish")

    def as_prompt(self) -> str:
        """One line of user context to prepend to Gemini prompts."""
        return (f"User profile - name: {self.name}; address them as "
                f"'{self.nickname}'; preferred language: {self.language}; "
                f"location: {self.location}.")

    def as_dict(self) -> dict:
        with self._lock:
            return dict(self._data)


class ConversationContext:
    """Rolling window of the last N turns of the CURRENT session (RAM only)."""

    def __init__(self, max_turns: int = CONTEXT_TURNS):
        self.max_turns = max_turns
        self._turns: list[dict] = []
        self._lock = threading.RLock()

    def add(self, user_text: str, jarvis_text: str, intent: str = ""):
        with self._lock:
            self._turns.append({
                "user": user_text,
                "jarvis": jarvis_text,
                "intent": intent,
                "at": datetime.now().strftime("%I:%M %p"),
            })
            del self._turns[:-self.max_turns]

    def turns(self) -> list[dict]:
        with self._lock:
            return list(self._turns)

    def last_user_text(self) -> str | None:
        turns = self.turns()
        return turns[-1]["user"] if turns else None

    def last_jarvis_text(self) -> str | None:
        turns = self.turns()
        return turns[-1]["jarvis"] if turns else None

    def as_prompt(self) -> str:
        """Recent turns formatted for a Gemini prompt ('' when empty)."""
        turns = self.turns()
        if not turns:
            return ""
        lines = [f"User: {t['user']}\nJARVIS: {t['jarvis']}" for t in turns]
        return "Recent conversation (most recent last):\n" + "\n".join(lines)

    def clear(self):
        with self._lock:
            self._turns.clear()
