"""
J.A.R.V.I.S. — Intent Pipeline Test Suite

Runs the REAL pipeline (offline fast path -> Gemini intent parsing -> local
dispatch) over a wide spread of phrasings and prints a pass/fail line for each.

Side effects are disabled via Services(dry_run=True): no app is launched, no
screenshot is taken, and the PC is never actually locked. Everything up to the
final system call is genuinely exercised.

    python test_intents.py            # full suite (uses the Gemini API)
    python test_intents.py --offline  # skip Gemini, test the fallback parser
"""

import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.command_router import fallback_intent
from core.dispatcher import Dispatcher, Services
from core.language import pick_voice, is_hindi
from core.memory_store import MemoryStore, Profile, ConversationContext
from core.pipeline import Pipeline
from skills.reminders import ReminderManager

OFFLINE = "--offline" in sys.argv
PASS, FAIL = "PASS", "FAIL"

try:
    "✅".encode(sys.stdout.encoding or "utf-8")
    TICK, CROSS = "✅", "❌"
except (UnicodeEncodeError, LookupError, TypeError):
    TICK, CROSS = "[PASS]", "[FAIL]"

_results = []


def _mark(ok: bool, label: str, detail: str = ""):
    _results.append(bool(ok))
    print(f"{TICK if ok else CROSS}  {label}" + (f"   {detail}" if detail else ""))
    return ok


def header(title: str):
    print(f"\n{'=' * 78}\n  {title}\n{'=' * 78}")


# ── Test fixtures ────────────────────────────────────
TEST_MEMORY = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "memory.test.json")
TEST_PROFILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "profile.test.json")


def build_pipeline():
    """A pipeline wired to throwaway files with every side effect disabled."""
    for path in (TEST_MEMORY, TEST_PROFILE):
        if os.path.exists(path):
            os.remove(path)
    memory = MemoryStore(TEST_MEMORY)
    profile = Profile(TEST_PROFILE)
    context = ConversationContext()
    services = Services(memory=memory, profile=profile, context=context,
                        reminders=ReminderManager(), dry_run=True)
    dispatcher = Dispatcher(services)
    pipeline = Pipeline(dispatcher, memory=memory, profile=profile,
                        context=context, log_fn=lambda _m: None)
    return pipeline, dispatcher, memory, profile, context


def cleanup():
    for path in (TEST_MEMORY, TEST_PROFILE):
        if os.path.exists(path):
            os.remove(path)


def parse(pipeline, text, awake=True):
    """Run one utterance through the real pipeline and return its Outcome."""
    return pipeline.handle(text, awake=awake)


def force_offline():
    """Make the intent engine behave exactly as it does when Gemini is down.

    Rather than bypassing the pipeline, this trips the same back-off the engine
    sets after an API failure, so --offline exercises the REAL fallback path.
    """
    import core.intent_engine as engine
    engine._blackout_until = time.time() + 86400


# ── 1. The strict rule list ──────────────────────────
STRICT_GROUPS = [
    ("all should OPEN CHROME", "open_app", [
        "Chrome khol do", "open Chrome", "browser open karo", "Chrome chala do",
    ]),
    ("all should TELL THE TIME", "time", [
        "time kya hua", "kitne baje hain", "what time is it", "bhai time bata",
    ]),
    ("all should LOCK THE PC", "lock_pc", [
        "PC lock kar", "lock it down", "sab band kar de", "lock karo",
    ]),
    ("all should PLAY MUSIC", "play_music", [
        "gaana laga do", "music play kar", "kuch suna do", "play some music",
    ]),
    ("all should SHOW BATTERY", "system_info", [
        "battery kitni hai", "charge kitna hai", "battery level",
    ]),
]


def test_strict_rules(pipeline, dispatcher):
    header("1. NATURAL LANGUAGE VARIATIONS (the strict rule list)")
    for title, expected, phrases in STRICT_GROUPS:
        print(f"\n  -- {title} --")
        for phrase in phrases:
            outcome = parse(pipeline, phrase)
            intent = outcome.intent
            # lock/shutdown/restart correctly stop to ask for confirmation, so
            # the intent under test is the one now pending, not one executed.
            if outcome.awaiting == "confirmation":
                intent = dispatcher._pending_action[0]
                dispatcher.clear_pending()
            ok = intent == expected
            extra = ""
            if expected == "system_info" and ok:
                ok = "battery" in outcome.action.lower()
                extra = "" if ok else "(did not report battery)"
            if expected == "open_app" and ok:
                ok = "chrome" in outcome.action.lower()
                extra = "" if ok else f"(opened '{outcome.action}', not Chrome)"
            _mark(ok, f"{phrase!r:32} -> {intent:16} [{outcome.source}]",
                  f"ACTION: {outcome.action} {extra}")


# ── 2. Memory ────────────────────────────────────────
def test_memory(pipeline, memory):
    header("2. MEMORY (remember / recall / forget, memory.json)")

    outcome = parse(pipeline, "JARVIS yaad rakh kal meeting hai")
    _mark(outcome.intent == "remember" and memory.count() == 1,
          "'JARVIS yaad rakh kal meeting hai' saved to memory.json",
          f"stored: {[m['text'] for m in memory.all()]}")

    outcome = parse(pipeline, "JARVIS meri meeting kab hai")
    answered = "meeting" in outcome.speech.lower()
    from_memory = "memory" in outcome.action.lower()
    _mark(answered and from_memory,
          "'JARVIS meri meeting kab hai' recalled from memory",
          f"-> {outcome.speech}")

    _mark(from_memory, "recall answered WITHOUT a Gemini call",
          f"ACTION: {outcome.action}")

    parse(pipeline, "JARVIS remember my wifi password is starkindustries")
    outcome = parse(pipeline, "do you remember my wifi password")
    _mark("starkindustries" in outcome.speech.lower(),
          "second memory stored and recalled", f"-> {outcome.speech}")

    before = memory.count()
    outcome = parse(pipeline, "JARVIS forget my wifi password")
    _mark(memory.count() == before - 1,
          "'JARVIS forget my wifi password' deleted it",
          f"{before} -> {memory.count()} memories")

    _mark(memory.recall("wifi password") is None,
          "forgotten memory is really gone")


# ── 3. Briefing ──────────────────────────────────────
def test_briefing(pipeline):
    header("3. DAILY BRIEFING")
    outcome = parse(pipeline, "good morning JARVIS")
    speech = outcome.speech.lower()
    _mark(outcome.intent == "morning_briefing",
          "'good morning JARVIS' triggers the briefing",
          f"[{outcome.source}]")
    checks = [
        ("time", any(x in speech for x in ("am", "pm", "baj"))),
        ("date + day", any(day in speech for day in
                           ("monday", "tuesday", "wednesday", "thursday",
                            "friday", "saturday", "sunday"))),
        ("weather (Noida)", "noida" in speech or "degrees" in speech
         or "weather" in speech),
        ("reminders", "reminder" in speech),
        ("motivational quote", len(outcome.speech.split(".")) >= 5),
    ]
    for label, ok in checks:
        _mark(ok, f"briefing includes {label}")
    print(f"\n     Briefing text:\n     {outcome.speech}\n")


# ── 4. Follow-up conversation + session context ──────
def test_follow_up(pipeline, context):
    header("4. FOLLOW-UP CONVERSATION (no wake word) + SESSION CONTEXT")

    # In STANDBY a normal command is ignored...
    outcome = parse(pipeline, "kitne baje hain", awake=False)
    _mark(outcome.kind == "ignored",
          "in STANDBY, a command without the wake word is ignored")

    # ...the wake word wakes JARVIS...
    outcome = parse(pipeline, "hey jarvis", awake=False)
    _mark(outcome.kind == "wake", "'hey jarvis' wakes JARVIS (offline fast path)",
          f"-> {outcome.speech}")

    # ...and once awake, follow-ups need no wake word at all.
    first = parse(pipeline, "kitne baje hain")
    second = parse(pipeline, "aur aaj date kya hai")
    _mark(first.intent == "time" and second.intent == "date",
          "two back-to-back commands, neither repeating the wake word",
          f"{first.intent} then {second.intent}")

    outcome = parse(pipeline, "what did I just ask")
    _mark("date" in outcome.speech.lower() or "aaj" in outcome.speech.lower(),
          "'what did I just ask' answered from session context",
          f"-> {outcome.speech}")

    _mark(len(context.turns()) <= 5,
          f"session context holds at most 5 turns (has {len(context.turns())})")


# ── 5. Confirmation for risky actions ────────────────
def test_confirmation(pipeline, dispatcher, services):
    header("5. CONFIRMATION BEFORE RISKY ACTIONS")

    services.performed.clear()
    outcome = parse(pipeline, "lock the pc")
    _mark(outcome.awaiting == "confirmation" and "confirm" in outcome.speech.lower(),
          "'lock the pc' asks before doing anything", f"-> {outcome.speech}")
    _mark("lock_pc" not in services.performed,
          "nothing was locked while waiting for confirmation")

    outcome = parse(pipeline, "haan")
    if outcome.after_speaking:
        outcome.after_speaking()
    _mark("lock_pc" in services.performed,
          "'haan' confirms and the lock then executes")

    services.performed.clear()
    parse(pipeline, "PC shut down kar do")
    outcome = parse(pipeline, "nahi")
    _mark(not services.performed and "cancel" in outcome.speech.lower(),
          "'nahi' cancels a pending shutdown", f"-> {outcome.speech}")

    services.performed.clear()
    parse(pipeline, "restart the computer")
    outcome = parse(pipeline, "kitne baje hain")
    _mark(not services.performed and outcome.intent == "time",
          "an unrelated command drops the pending action instead of restarting")
    dispatcher.clear_pending()


# ── 6. Smart understanding ───────────────────────────
def test_smart_understanding(pipeline, dispatcher):
    header("6. SMART UNDERSTANDING (vague references + missing details)")

    outcome = parse(pipeline, "open that music app")
    _mark("spotify" in outcome.action.lower(),
          "'open that music app' resolves to Spotify", f"ACTION: {outcome.action}")

    outcome = parse(pipeline, "call karo")
    _mark(outcome.awaiting == "clarification" and "kise" in outcome.speech.lower(),
          "'call karo' asks who to call instead of doing nothing",
          f"-> {outcome.speech}")
    dispatcher.clear_pending()

    outcome = parse(pipeline, "koi browser khol do")
    _mark("chrome" in outcome.action.lower(),
          "'koi browser khol do' resolves to Chrome", f"ACTION: {outcome.action}")


# ── 7. Offline fast path speed ───────────────────────
def test_fast_path():
    header("7. OFFLINE FAST PATH (must resolve in under 0.1s)")
    from core import fast_path

    cases = [("hey jarvis", False, fast_path.WAKE),
             ("daddy's home", False, fast_path.WAKE),
             ("jarvis standby", True, fast_path.SLEEP),
             ("that'll be all", True, fast_path.SLEEP),
             ("I am Iron Man", True, fast_path.EASTER_EGG)]
    for text, awake, expected in cases:
        started = time.perf_counter()
        hit = fast_path.check(text, awake=awake)
        elapsed_ms = (time.perf_counter() - started) * 1000
        ok = hit is not None and hit.kind == expected and elapsed_ms < 100
        _mark(ok, f"{text!r:22} -> {hit.kind if hit else 'MISS':12}",
              f"{elapsed_ms:.3f}ms (offline, no API)")

    started = time.perf_counter()
    miss = fast_path.check("kitne baje hain", awake=True)
    elapsed_ms = (time.perf_counter() - started) * 1000
    _mark(miss is None and elapsed_ms < 100,
          "a normal command falls through to intent parsing",
          f"{elapsed_ms:.3f}ms")


# ── 8. Gemini failure fallback ───────────────────────
def test_fallback_parser():
    header("8. FALLBACK WHEN GEMINI IS UNAVAILABLE (offline pattern matcher)")
    cases = [
        ("Chrome khol do", "open_app"), ("open Chrome", "open_app"),
        ("browser open karo", "open_app"), ("Chrome chala do", "open_app"),
        ("time kya hua", "time"), ("kitne baje hain", "time"),
        ("what time is it", "time"), ("bhai time bata", "time"),
        ("PC lock kar", "lock_pc"), ("lock it down", "lock_pc"),
        ("sab band kar de", "lock_pc"), ("lock karo", "lock_pc"),
        ("gaana laga do", "play_music"), ("music play kar", "play_music"),
        ("kuch suna do", "play_music"), ("play some music", "play_music"),
        ("battery kitni hai", "system_info"), ("charge kitna hai", "system_info"),
        ("battery level", "system_info"),
        ("good morning JARVIS", "morning_briefing"),
        ("JARVIS yaad rakh kal meeting hai", "remember"),
    ]
    for text, expected in cases:
        intent, params, confidence = fallback_intent(text)
        _mark(intent == expected, f"{text!r:34} -> {intent}",
              f"(confidence {confidence:.2f}, no API needed)")


# ── 9. TTS voice routing ─────────────────────────────
def test_tts_voice():
    from config import EDGE_TTS_VOICE_EN, EDGE_TTS_VOICE_HI, TTS_AUTO_SWITCH_VOICE

    header("9. TTS VOICE ROUTING  ("
           + (f"English -> {EDGE_TTS_VOICE_EN}, Hinglish -> {EDGE_TTS_VOICE_HI}"
              if TTS_AUTO_SWITCH_VOICE else
              f"one voice throughout: {EDGE_TTS_VOICE_EN}") + ")")

    same_voice = [
        "Abhi 6:33 PM ho rahe hain, Sir.",
        "Chrome khol raha hoon, Sir.",
        "Battery 47 percent hai, Sir.",
        "Yaad rakh liya, Sir: kal meeting hai.",
        "Systems lock kar raha hoon, Sir. Take care.",
        "And I am the voice behind the suit, sir.",
        "All systems nominal.",
    ]
    for text in same_voice:
        voice = pick_voice(text)
        expected = EDGE_TTS_VOICE_HI if (TTS_AUTO_SWITCH_VOICE and is_hindi(text)) \
            else EDGE_TTS_VOICE_EN
        _mark(voice == expected, f"{repr(text)[:46]:48} -> {voice}")

    if not TTS_AUTO_SWITCH_VOICE:
        voices = {pick_voice(t) for t in same_voice}
        _mark(voices == {EDGE_TTS_VOICE_EN},
              "the voice never changes between Hinglish and English",
              f"always {EDGE_TTS_VOICE_EN}")
        # An English voice cannot pronounce Devanagari, so that alone falls back.
        _mark(pick_voice("आज मौसम अच्छा है") == EDGE_TTS_VOICE_HI,
              "Devanagari script still falls back to the Hindi voice",
              "(JARVIS writes Hinglish in Latin script, so this is rare)")



# ── 11. Regressions from live use ────────────────────
def test_reported_bugs(pipeline, dispatcher):
    """Bugs seen in an actual session — each must stay fixed."""
    header("11. REGRESSIONS (bugs reported from live use)")

    # BUG: "How are you?" was parsed as small_talk with confidence 0.95 and then
    # answered with "Samajh nahi aaya" -- Gemini returns NO params for small
    # talk, and the dispatcher had no access to what was actually said.
    for intent in ("small_talk", "general_question"):
        result = dispatcher.execute(intent, {}, raw="How are you?")
        ok = "samajh nahi aaya" not in result.speech.lower()
        _mark(ok, f"{intent} with empty params still answers",
              f"-> {result.action}")

    # ...but genuine noise must NOT be answered. `unknown` is where a garbled
    # transcription lands, and JARVIS should admit it rather than reply to it.
    result = dispatcher.execute("unknown", {}, raw="E acerro.")
    # Checked by action, not wording: the reply language now follows the input,
    # and garbled noise carries no Hindi words, so the line comes back in English.
    _mark(result.action == "did not understand",
          "unknown intent still says it did not understand",
          f"noise is never sent to Gemini -> {result.speech}")

    # BUG: after a voice-triggered lock, JARVIS stayed ACTIVE and kept the mic
    # open behind the lock screen instead of dropping to standby.
    for intent in ("lock_pc", "shutdown", "restart"):
        result = dispatcher.execute(intent, {})
        _mark(result.sleep_after is True,
              f"{intent} asks the app to go to standby",
              "no live mic behind a lock screen")

    # A normal command must NOT end the conversation.
    result = dispatcher.execute("time", {})
    _mark(result.sleep_after is False,
          "an ordinary command keeps the follow-up window open")

    # The flag has to survive the confirmation round trip, which is the path
    # the live bug actually took ("sab band kar de" -> "okay").
    dispatcher.clear_pending()
    outcome = parse(pipeline, "sab band kar de")
    if outcome.awaiting == "confirmation":
        confirmed = parse(pipeline, "haan")
        _mark(confirmed.sleep_after is True,
              "confirmed lock still reaches the app as sleep_after",
              "survives the confirmation round trip")
    else:
        _mark(False, "confirmed lock still reaches the app as sleep_after",
              f"expected a confirmation, got {outcome.awaiting!r}")
    dispatcher.clear_pending()

    # BUG: "Daddy's home" rarely worked. Whisper (both base AND small) returns
    # "that is home" / "that day is home" for a clean recording of it, and the
    # matcher only knew the literal spelling.
    from core import fast_path
    must_wake = [
        "Hey Jarvis.", "Jarvis.", "Jarvis, are you there?", "Daddy's home",
        "That is home.", "That day is home.", "Daddy is home.",
        "Hey Travis.", "Hey Jervis.", "Javis", "Jervis", "Jarvas",
    ]
    missed = [t for t in must_wake if fast_path.check(t, awake=False) is None]
    _mark(not missed, "every wake word and known mishearing wakes JARVIS",
          f"missed: {missed}" if missed else f"{len(must_wake)} phrases")

    # Those extra spellings must not turn ordinary speech into a wake word.
    must_not_wake = [
        "Travis", "that home", "I am going home", "is that your home",
        "my home is there", "that is home sweet home", "my name is Travis",
        "home", "that day",
    ]
    woke = [t for t in must_not_wake if fast_path.check(t, awake=False) is not None]
    _mark(not woke, "ordinary speech still does NOT wake JARVIS",
          f"false wake: {woke}" if woke else f"{len(must_not_wake)} phrases")


    # BUG: "Camera open kar do" fell through to general_question and "Open
    # camera." launched the Windows Camera app. "open" was missing from the
    # offline vision rules, and camera must mean JARVIS's own vision.
    camera_cases = [
        ("Camera open kar do", "vision_on"), ("Open camera", "vision_on"),
        ("camera kholo", "vision_on"), ("camera chalu karo", "vision_on"),
        ("camera start karo", "vision_on"), ("turn on the camera", "vision_on"),
        ("webcam on kar do", "vision_on"), ("kholo camera", "vision_on"),
        ("camera band karo", "vision_off"), ("close camera", "vision_off"),
        ("turn off the camera", "vision_off"),
        ("Chrome khol do", "open_app"), ("close Notepad", "close_app"),
        ("open camscanner", "open_app"),
    ]
    wrong = [(t, fallback_intent(t)[0]) for t, want in camera_cases
             if fallback_intent(t)[0] != want]
    _mark(not wrong, "every camera phrasing reaches vision, apps still reach apps",
          f"wrong: {wrong}" if wrong else f"{len(camera_cases)} phrases, offline parser")

    # Gemini itself can also say open_app {"app": "camera"}.
    before = len(dispatcher.services.performed)
    dispatcher.execute("open_app", {"app": "camera"})
    dispatcher.execute("close_app", {"app": "webcam"})
    done = dispatcher.services.performed[before:]
    _mark(done == ["vision_on", "vision_off"],
          "open_app/close_app for 'camera' is routed to vision, not the Windows app",
          f"performed: {done}")

    # BUG: once intent parsing had watched every Gemini model fail, a question
    # tried the whole chain AGAIN and the user waited ~5s for the same failure.
    import core.intent_engine as engine
    from skills.persona import answer_question
    saved = engine._blackout_until
    engine._blackout_until = time.time() + 60
    started = time.time()
    _answer, source = answer_question("India ki capital kya hai")
    elapsed_ms = (time.time() - started) * 1000
    engine._blackout_until = saved
    _mark(source == "offline" and elapsed_ms < 100,
          "a question during a Gemini outage is answered immediately",
          f"{elapsed_ms:.1f}ms, no retry of the model chain")


# ── 12. Reply language follows the user ──────────────
def test_language_mirror(pipeline, dispatcher):
    """English in -> English reply (English voice). Hindi in -> Hinglish reply.

    BUG: after speaking Hindi, switching back to English still got the Hindi
    voice. Every reply was written in Hinglish, so the voice picker was right to
    choose the Hindi voice -- the reply simply never followed the user.
    """
    header("12. REPLY LANGUAGE FOLLOWS THE USER (and so does the voice)")
    from config import EDGE_TTS_VOICE_EN, EDGE_TTS_VOICE_HI
    from core.language import reply_language

    cases = [("open Chrome", "en"), ("what time is it", "en"), ("battery level", "en"),
             ("Chrome khol do", "hi"), ("kitne baje hain", "hi"), ("yes", "en"),
             ("haan", "hi"), ("that'll be all", "en")]
    wrong = [(t, reply_language(t)) for t, want in cases if reply_language(t) != want]
    _mark(not wrong, "the reply language is read from what the user said",
          f"wrong: {wrong}" if wrong else f"{len(cases)} utterances")
    _mark(reply_language("okay", fallback="hi") == "hi",
          "a bare 'okay' keeps the language of the conversation")

    # The exact live sequence: English, then Hindi, then back to English.
    dispatcher.clear_pending()
    sequence = [
        ("what time is it", EDGE_TTS_VOICE_EN),
        ("kitne baje hain", EDGE_TTS_VOICE_HI),
        ("Chrome khol do", EDGE_TTS_VOICE_HI),
        ("what time is it", EDGE_TTS_VOICE_EN),
        ("open Chrome", EDGE_TTS_VOICE_EN),
        ("battery level", EDGE_TTS_VOICE_EN),
        ("aaj date kya hai", EDGE_TTS_VOICE_HI),
        ("what's today's date", EDGE_TTS_VOICE_EN),
        ("take a screenshot", EDGE_TTS_VOICE_EN),
        ("screenshot le lo", EDGE_TTS_VOICE_HI),
    ]
    for text, voice in sequence:
        outcome = parse(pipeline, text)
        got = pick_voice(outcome.speech)
        _mark(got == voice, f"{text!r:24} -> {got}", f"-> {outcome.speech[:60]}")

    # A confirmation answers in the language of the answer...
    parse(pipeline, "sab band kar de")
    outcome = parse(pipeline, "yes")
    _mark(pick_voice(outcome.speech) == EDGE_TTS_VOICE_EN,
          "Hindi command confirmed with 'yes' replies in English", f"-> {outcome.speech}")
    # ...and a bare "okay" keeps the language of the command it confirms.
    parse(pipeline, "lock the pc")
    outcome = parse(pipeline, "okay")
    _mark(pick_voice(outcome.speech) == EDGE_TTS_VOICE_EN,
          "English command confirmed with 'okay' stays English", f"-> {outcome.speech}")
    parse(pipeline, "sab band kar de")
    outcome = parse(pipeline, "okay")
    _mark(pick_voice(outcome.speech) == EDGE_TTS_VOICE_HI,
          "Hindi command confirmed with 'okay' stays Hinglish", f"-> {outcome.speech}")
    dispatcher.clear_pending()

    # The briefing and the standby farewell follow the user too.
    outcome = parse(pipeline, "good morning JARVIS")
    _mark(pick_voice(outcome.speech) == EDGE_TTS_VOICE_EN,
          "'good morning JARVIS' briefing is in English", f"-> {outcome.speech[:60]}")
    outcome = parse(pipeline, "that'll be all")
    _mark(outcome.kind == "sleep" and pick_voice(outcome.speech) == EDGE_TTS_VOICE_EN,
          "'that'll be all' farewell is in English", f"-> {outcome.speech}")
    dispatcher.clear_pending()



# ── 10. One real end-to-end Gemini answer ────────────
def test_live_answer():
    header("10. LIVE GEMINI ANSWER (general_question, real API call)")
    if OFFLINE:
        _mark(True, "skipped in --offline mode")
        return
    memory = MemoryStore(TEST_MEMORY)
    profile = Profile(TEST_PROFILE)
    context = ConversationContext()
    services = Services(memory=memory, profile=profile, context=context,
                        dry_run=False)
    dispatcher = Dispatcher(services)
    pipeline = Pipeline(dispatcher, memory=memory, profile=profile,
                        context=context, log_fn=lambda _m: None)
    outcome = pipeline.handle("India ki capital kya hai", awake=True)
    ok = "delhi" in outcome.speech.lower()
    _mark(ok, "'India ki capital kya hai' answered by Gemini",
          f"-> {outcome.speech}")
    _mark(is_hindi(outcome.speech) or "sir" in outcome.speech.lower(),
          "the answer is in JARVIS's Hinglish persona")


# ── Runner ───────────────────────────────────────────
def main():
    print("=" * 78)
    print("  J.A.R.V.I.S. — INTENT PIPELINE TEST SUITE")
    print(f"  Mode: {'OFFLINE (fallback parser only)' if OFFLINE else 'FULL (Gemini intent parsing)'}")
    print("  Side effects disabled: no app launches, no locking, no shutdown.")
    print("=" * 78)

    if OFFLINE:
        force_offline()

    pipeline, dispatcher, memory, profile, context = build_pipeline()
    try:
        test_strict_rules(pipeline, dispatcher)
        test_memory(pipeline, memory)
        test_briefing(pipeline)
        test_follow_up(pipeline, context)
        test_confirmation(pipeline, dispatcher, dispatcher.services)
        test_smart_understanding(pipeline, dispatcher)
        test_fast_path()
        test_fallback_parser()
        test_tts_voice()
        test_reported_bugs(pipeline, dispatcher)
        test_language_mirror(pipeline, dispatcher)
        test_live_answer()
    finally:
        cleanup()

    passed = sum(_results)
    total = len(_results)
    header("RESULTS")
    print(f"  {TICK} passed: {passed}/{total}")
    if passed != total:
        print(f"  {CROSS} failed: {total - passed}/{total}")
    print()
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
