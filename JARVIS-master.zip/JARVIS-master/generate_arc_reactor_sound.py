"""
Generate an arc reactor power-up sound effect for JARVIS.
Run this once to create the arc_reactor_powerup.wav file.

Usage:
    python generate_arc_reactor_sound.py
"""

import os
import struct
import math
import wave
import random


def generate_arc_reactor_powerup(output_path: str):
    """Generate a dramatic arc reactor power-up sound effect.
    
    Layers:
      - Deep bass hum (60Hz + harmonics)
      - Rising frequency sweep (150Hz → 1200Hz, exponential)
      - High-frequency electrical crackle
      - Resonant charging tones
      - Sharp attack, sustained power, slight tail-off
    """
    sample_rate = 44100
    duration = 2.0
    num_samples = int(sample_rate * duration)

    # Seed for reproducible "crackle" randomness
    rng = random.Random(42)

    samples = []
    for i in range(num_samples):
        t = i / sample_rate
        progress = t / duration  # 0.0 → 1.0

        # ── 1. Deep bass hum (60Hz + 120Hz harmonic) ──
        bass = 0.20 * math.sin(2 * math.pi * 60 * t)
        bass += 0.10 * math.sin(2 * math.pi * 120 * t)

        # ── 2. Rising frequency sweep (exponential 150 → 1200 Hz) ──
        sweep_freq = 150 * (1200 / 150) ** progress
        sweep = 0.25 * math.sin(2 * math.pi * sweep_freq * t)

        # ── 3. Electrical crackle (modulated high-freq tones) ──
        crackle = 0.0
        if rng.random() < 0.3 + 0.5 * progress:
            crackle_freq = 3000 + 2000 * math.sin(2 * math.pi * 7.3 * t)
            crackle = 0.08 * math.sin(2 * math.pi * crackle_freq * t)
            crackle *= (0.5 + 0.5 * rng.random())

        # ── 4. Resonant charging tone (rising harmonics) ──
        charge_freq = 400 + 800 * progress ** 1.5
        charge = 0.12 * math.sin(2 * math.pi * charge_freq * t)
        charge += 0.06 * math.sin(2 * math.pi * charge_freq * 2 * t)

        # ── 5. Power surge pulse (intensifies toward the end) ──
        surge = 0.10 * progress ** 2 * math.sin(2 * math.pi * 800 * t * (1 + progress))

        # ── Envelope: sharp attack, sustain, slight tail ──
        if t < 0.05:
            # Sharp 50ms attack
            envelope = t / 0.05
        elif t > duration - 0.3:
            # Gentle 300ms tail (doesn't fully fade — it's a power-up, not shutdown)
            envelope = 0.6 + 0.4 * ((duration - t) / 0.3)
        else:
            envelope = 1.0

        # ── Mix all layers ──
        sample = (bass + sweep + crackle + charge + surge) * envelope * 0.65

        # Soft clip to avoid harsh digital clipping
        if sample > 0.95:
            sample = 0.95 + 0.05 * math.tanh((sample - 0.95) * 10)
        elif sample < -0.95:
            sample = -0.95 - 0.05 * math.tanh((-sample - 0.95) * 10)

        sample = max(-1.0, min(1.0, sample))
        samples.append(int(sample * 32767))

    # Write WAV
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with wave.open(output_path, "w") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        for s in samples:
            wav.writeframes(struct.pack("<h", s))

    print(f"[JARVIS] Arc reactor power-up sound saved to: {output_path}")
    print(f"[JARVIS] Duration: {duration}s, Samples: {num_samples}, Size: {os.path.getsize(output_path)} bytes")


if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.abspath(__file__))
    output = os.path.join(base_dir, "assets", "sounds", "arc_reactor_powerup.wav")
    generate_arc_reactor_powerup(output)
    print("Done!")
