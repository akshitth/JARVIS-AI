"""
J.A.R.V.I.S. — Persona / Response Generation

The intent parser decides WHAT the user wants. This module produces WHAT JARVIS
says back, in character, and in the language the user spoke (lang="en" for
English, "hi" for Hinglish).

Two rules keep it cheap and fast:
  1. Local actions (time, open app, lock, battery...) never come through here.
     The dispatcher already has an exact line for those, so those commands cost
     zero API quota and answer instantly.
  2. Only `general_question` and open-ended `small_talk` reach Gemini — and
     even then memory.json is consulted first, so a fact the user already told
     JARVIS is answered offline.

The response call may use a larger model than the intent call: it is generating
prose, not a 40-token classification.
"""

import re

from config import RESPONSE_SYSTEM_PROMPT
from skills.gemini_ai import ask_gemini


def _log(msg):
    print(msg, flush=True)


def _clean(text: str) -> str:
    """Strip markdown and stray formatting — this text goes to a TTS engine."""
    text = re.sub(r"[*_`#]+", "", text or "")
    text = re.sub(r"\s+", " ", text).strip()
    return text


# Stated per call, not just in the system prompt. One-line questions give the
# model little to go on, and the session context can be full of Hindi turns --
# without an explicit instruction it kept answering an English question in
# Hinglish because the conversation so far had been Hinglish.
_LANGUAGE_RULE = {
    "en": "Reply in plain English only, even if earlier turns were in Hindi.",
    "hi": ("Reply in Hinglish (Hindi-English mix written in English script), "
           "even if earlier turns were in English."),
}


def answer_question(question: str, profile=None, context=None,
                    memory_store=None, lang: str = "hi") -> tuple[str, str]:
    """Answer a general question.

    Returns (answer_text, source) where source is "memory", "offline" or
    "gemini" — the caller logs which one paid for the answer.
    """
    en = lang == "en"

    # ── Memory first: no API call if JARVIS was already told this ──
    if memory_store is not None:
        remembered = memory_store.recall(question)
        if remembered:
            _log(f"[JARVIS][MEMORY] Answered from memory (no API call): {remembered}")
            return (f"You told me: {remembered}, Sir." if en
                    else f"Aapne bataya tha — {remembered}, Sir."), "memory"

    # Intent parsing has only just watched every model fail. Trying the whole
    # chain again made the user wait ~5s for the same failure, so say it now.
    from core.intent_engine import in_blackout
    if in_blackout():
        _log("[JARVIS][PERSONA] Gemini is cooling down -> skipping the answer call")
        if en:
            return ("Sir, I can't reach the AI server right now. Please ask that again "
                    "in a little while; everything else still works."), "offline"
        return ("Sir, abhi AI server se connect nahi ho pa raha, ye sawaal thodi der "
                "baad poochiye. Baaki commands chal rahi hain."), "offline"

    prompt_parts = [RESPONSE_SYSTEM_PROMPT]
    if profile is not None:
        prompt_parts.append(profile.as_prompt())
    if memory_store is not None and memory_store.count():
        facts = "; ".join(entry["text"] for entry in memory_store.all()[-8:])
        prompt_parts.append(f"Things the user asked you to remember: {facts}")
    if context is not None:
        recent = context.as_prompt()
        if recent:
            prompt_parts.append(recent)
    prompt_parts.append(_LANGUAGE_RULE["en" if en else "hi"])
    prompt_parts.append(f"User: {question}\nJARVIS:")

    answer = ask_gemini("\n\n".join(prompt_parts), system_prompt=RESPONSE_SYSTEM_PROMPT,
                        lang=lang)
    return _clean(answer), "gemini"


def small_talk(text: str, profile=None, context=None, memory_store=None,
               lang: str = "hi") -> tuple[str, str]:
    """Casual conversation — same path as a question, different framing."""
    return answer_question(text, profile=profile, context=context,
                           memory_store=memory_store, lang=lang)
