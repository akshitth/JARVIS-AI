"""
J.A.R.V.I.S. — Easter Eggs Skill
Hidden responses and cinematic sequences for special trigger phrases.
"""

import os
import re
import time

import pygame

from config import SOUNDS_DIR


# ── Easter Egg Detection ─────────────────────────────

def check_easter_egg(text: str) -> str | None:
    """
    Check if text matches any Easter egg trigger phrase.
    
    Returns:
        Skill name string if matched, None otherwise.
    """
    text_lower = text.lower().strip()

    # Matches "I am Iron Man", "I'm Iron Man", "im ironman", with or without
    # trailing punctuation — Whisper often transcribes the contraction.
    if re.search(r"i\s*(?:am|'?m)\s+iron\s*man", text_lower):
        return "easter_egg_iron_man"

    return None


# ── Iron Man Easter Egg ──────────────────────────────

_IRON_MAN_RESPONSE = (
    "And I am the voice behind the suit, sir. "
    "The world is in good hands. As always."
)

_ARC_REACTOR_SOUND = os.path.join(SOUNDS_DIR, "arc_reactor_powerup.wav")


def _log(msg):
    """Print with flush for Windows."""
    print(msg, flush=True)


def play_arc_reactor_sound():
    """
    Play the arc reactor power-up sound effect on a separate channel.
    Non-blocking — returns immediately after starting playback.
    Uses pygame.mixer.Sound (not music) to avoid conflicting with TTS.
    """
    try:
        if not os.path.exists(_ARC_REACTOR_SOUND):
            _log(f"[JARVIS] Arc reactor sound not found: {_ARC_REACTOR_SOUND}")
            return

        sound = pygame.mixer.Sound(_ARC_REACTOR_SOUND)
        # Use channel 1 (channel 0 is often used by mixer.music internally)
        channel = pygame.mixer.Channel(1)
        channel.play(sound)
        _log("[JARVIS] Arc reactor power-up sound playing...")
    except Exception as e:
        _log(f"[JARVIS] Arc reactor sound error: {e}")


def execute_iron_man_easter_egg() -> str:
    """
    Execute the full 'I am Iron Man' Easter egg sequence.

    The sound and HUD visual effects are triggered by the caller (main.py)
    before this runs; this function handles the dramatic pause and returns
    the epic response line for TTS.

    Returns:
        The epic response text for TTS.
    """
    _log("[JARVIS] ★ EASTER EGG ACTIVATED: I Am Iron Man ★")

    # Step 1: Sound + HUD effects are triggered by the caller (main.py) before
    # this runs, so we don't replay the sound here (avoids a double overlap).

    # Step 2: Dramatic pause (1 second)
    _log("[JARVIS] Dramatic pause...")
    time.sleep(1.0)

    # Step 4: Return the epic response for TTS
    _log(f"[JARVIS] Response: {_IRON_MAN_RESPONSE}")
    return _IRON_MAN_RESPONSE
