"""
J.A.R.V.I.S. — System Info Skill
Uses psutil to report system statistics, in the language the user asked in
(lang="en" for English, "hi" for Hinglish).
"""

import psutil
import platform


def get_cpu_info(lang: str = "hi") -> str:
    """Get CPU usage."""
    usage = psutil.cpu_percent(interval=1)
    count = psutil.cpu_count()
    freq = psutil.cpu_freq()
    if lang == "en":
        freq_str = f", at {freq.current:.0f} megahertz" if freq else ""
        return f"The CPU is at {usage} percent across {count} cores{freq_str}, Sir."
    freq_str = f", {freq.current:.0f} megahertz par" if freq else ""
    return f"CPU {usage} percent par chal raha hai, {count} cores{freq_str}, Sir."


def get_ram_info(lang: str = "hi") -> str:
    """Get RAM usage."""
    mem = psutil.virtual_memory()
    used_gb = mem.used / (1024 ** 3)
    total_gb = mem.total / (1024 ** 3)
    percent = mem.percent
    if lang == "en":
        return (f"RAM usage is at {percent} percent, Sir. "
                f"{used_gb:.1f} GB of {total_gb:.1f} GB is in use.")
    return f"RAM {percent} percent use ho rahi hai, Sir. {total_gb:.1f} GB mein se {used_gb:.1f} GB bhari hui hai."


def get_battery_info(lang: str = "hi") -> str:
    """Get battery status."""
    battery = psutil.sensors_battery()
    en = lang == "en"
    if battery is None:
        return ("I can't detect a battery, Sir. You appear to be on a desktop." if en
                else "Koi battery detect nahi hui, Sir. Lagta hai aap desktop par hain.")
    percent = battery.percent
    if en:
        plugged = "charging" if battery.power_plugged else "running on battery power"
    else:
        plugged = "charging par lagi hui hai" if battery.power_plugged else "battery power par chal rahi hai"
    # secsleft is POWER_TIME_UNKNOWN/UNLIMITED (negative) or, on some Windows
    # drivers, an unsigned sentinel in the billions. Only quote a figure that
    # could plausibly be a real runtime.
    secs_left = battery.secsleft
    if not battery.power_plugged and 0 < secs_left < 48 * 3600:
        hours = secs_left // 3600
        minutes = (secs_left % 3600) // 60
        if en:
            return (f"Battery is at {percent} percent and {plugged}. "
                    f"About {hours} hours {minutes} minutes remaining, Sir.")
        return f"Battery {percent} percent hai aur {plugged}. Lagbhag {hours} ghante {minutes} minute aur chalegi, Sir."
    if en:
        return f"Battery is at {percent} percent, Sir, and {plugged}."
    return f"Battery {percent} percent hai, Sir, aur {plugged}."


def get_disk_info(lang: str = "hi") -> str:
    """Get disk usage."""
    disk = psutil.disk_usage("/")
    used_gb = disk.used / (1024 ** 3)
    total_gb = disk.total / (1024 ** 3)
    free_gb = disk.free / (1024 ** 3)
    if lang == "en":
        return (f"{used_gb:.1f} GB of {total_gb:.1f} GB on the disk is used, "
                f"with {free_gb:.1f} GB free, Sir.")
    return f"Disk par {total_gb:.1f} GB mein se {used_gb:.1f} GB use ho chuki hai, {free_gb:.1f} GB free hai, Sir."


def get_all_info(lang: str = "hi") -> str:
    """Get a comprehensive system overview."""
    parts = []
    parts.append(f"System: {platform.system()} {platform.release()}")

    cpu = psutil.cpu_percent(interval=1)
    parts.append(f"CPU: {cpu}%")

    mem = psutil.virtual_memory()
    parts.append(f"RAM: {mem.percent}% ({mem.used / (1024**3):.1f}/{mem.total / (1024**3):.1f} GB)")

    disk = psutil.disk_usage("/")
    parts.append(f"Disk: {disk.percent}% used")

    battery = psutil.sensors_battery()
    if battery:
        parts.append(f"Battery: {battery.percent}%")

    overview = ", ".join(parts)
    if lang == "en":
        return f"System status, Sir: {overview}. All systems nominal."
    return f"System status, Sir: {overview}. Sab systems nominal hain."


def get_system_info(info_type: str = "all", lang: str = "hi") -> str:
    """Route system info requests."""
    handlers = {
        "cpu": get_cpu_info,
        "ram": get_ram_info,
        "memory": get_ram_info,
        "battery": get_battery_info,
        "disk": get_disk_info,
        "storage": get_disk_info,
        "all": get_all_info,
    }
    handler = handlers.get(info_type, get_all_info)
    return handler(lang)
