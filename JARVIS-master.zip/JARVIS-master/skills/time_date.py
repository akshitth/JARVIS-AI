"""
J.A.R.V.I.S. — Time & Date Skill

Answers in the language the user asked in: lang="en" for English, "hi" for
Hinglish.
"""

from datetime import datetime

_DAYS_HI = {
    "Monday": "Somvaar", "Tuesday": "Mangalvaar", "Wednesday": "Budhvaar",
    "Thursday": "Guruvaar", "Friday": "Shukravaar", "Saturday": "Shanivaar",
    "Sunday": "Ravivaar",
}


def get_time(lang: str = "hi") -> str:
    """Current time."""
    now = datetime.now()
    hour = now.strftime("%I").lstrip("0")
    minute = now.strftime("%M")
    period = now.strftime("%p")

    if lang == "en":
        if minute == "00":
            return f"It's exactly {hour} {period}, Sir."
        return f"It's {hour}:{minute} {period}, Sir."
    if minute == "00":
        return f"Abhi theek {hour} {period} baje hain, Sir."
    return f"Abhi {hour}:{minute} {period} ho rahe hain, Sir."


def get_date(lang: str = "hi") -> str:
    """Today's date."""
    now = datetime.now()
    day_en = now.strftime("%A")
    date_str = now.strftime("%d %B %Y").lstrip("0")
    if lang == "en":
        return f"Today is {day_en}, {date_str}, Sir."
    day_hi = _DAYS_HI.get(day_en, day_en)
    return f"Aaj {day_en} hai, yaani {day_hi}, {date_str}, Sir."
