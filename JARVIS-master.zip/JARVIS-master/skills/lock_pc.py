"""
J.A.R.V.I.S. — Lock PC Skill
Lock the Windows workstation.
"""

import ctypes


def lock_pc() -> str:
    """Return the response to speak before locking the PC."""
    return "Locking down the systems, sir. Stay safe out there."


def execute_lock():
    """Lock the Windows workstation."""
    ctypes.windll.user32.LockWorkStation()
