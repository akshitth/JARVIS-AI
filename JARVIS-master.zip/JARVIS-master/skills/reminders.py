"""
J.A.R.V.I.S. — Reminders Skill
Set timed reminders that fire after a delay.

Reminders also feed the morning briefing, so each one records what it is and
when it fires, and cleans itself out of the pending list once delivered.
"""

import threading
from datetime import datetime, timedelta


class ReminderManager:
    """Manages timed reminders."""

    def __init__(self, speak_callback=None):
        self.speak_callback = speak_callback
        self._lock = threading.RLock()
        self._reminders = []          # [{id, timer, message, due}]
        self._next_id = 1

    def set_reminder(self, seconds: int, message: str,
                     amount: int = None, unit: str = None, lang: str = "hi") -> str:
        """Set a reminder that fires after the given number of seconds."""
        seconds = max(1, int(seconds))
        with self._lock:
            reminder_id = self._next_id
            self._next_id += 1
            timer = threading.Timer(seconds, self._fire_reminder, args=[reminder_id, message])
            timer.daemon = True
            timer.start()
            self._reminders.append({
                "id": reminder_id,
                "timer": timer,
                "message": message,
                "due": datetime.now() + timedelta(seconds=seconds),
            })

        if amount is None or unit is None:
            amount, unit = seconds, "seconds"
        unit_label = str(unit).rstrip("s") + ("s" if amount != 1 else "")
        if lang == "en":
            return f"Reminder set, Sir. I'll remind you in {amount} {unit_label}."
        return f"Reminder set ho gaya, Sir. {amount} {unit_label} mein yaad dila dunga."

    def _fire_reminder(self, reminder_id: int, message: str):
        """Called when a reminder fires."""
        with self._lock:
            self._reminders = [r for r in self._reminders if r["id"] != reminder_id]
        text = f"Sir, reminder: {message}"
        if self.speak_callback:
            self.speak_callback(text)
        else:
            print(f"[JARVIS REMINDER] {text}", flush=True)

    def pending(self) -> list[dict]:
        """Reminders that have not fired yet, soonest first."""
        with self._lock:
            live = [r for r in self._reminders if r["timer"].is_alive()]
        return sorted(
            ({"message": r["message"], "due": r["due"]} for r in live),
            key=lambda r: r["due"],
        )

    def describe_pending(self, lang: str = "hi") -> str | None:
        """One line listing pending reminders, or None if there are none."""
        pending = self.pending()
        if not pending:
            return None
        parts = [f"{r['message']} at {r['due'].strftime('%I:%M %p').lstrip('0')}"
                 for r in pending[:3]]
        count = len(pending)
        label = "reminder" if count == 1 else "reminders"
        if lang == "en":
            return f"You have {count} pending {label}: " + ", ".join(parts) + "."
        return f"Aapke paas {count} pending {label} hai: " + ", ".join(parts) + "."

    def cancel_all(self):
        """Cancel all active reminders."""
        with self._lock:
            for reminder in self._reminders:
                reminder["timer"].cancel()
            self._reminders.clear()
