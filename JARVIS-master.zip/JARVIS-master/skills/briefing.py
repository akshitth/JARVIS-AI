"""
J.A.R.V.I.S. — Daily Briefing Skill

"JARVIS good morning" / "morning briefing" produces one spoken rundown:
current time, today's date and day, weather for the user's location, any
pending reminders, and a motivational line to start on. It is delivered in the
language the briefing was asked for in.

Every section is optional in the sense that a failure (no network for weather,
no reminders set) degrades that line away instead of breaking the briefing.
"""

import random
from datetime import datetime

from skills.weather import get_weather

_QUOTES_HI = [
    "Sometimes you gotta run before you can walk, Sir.",
    "Genius is one percent inspiration, ninety-nine percent perspiration. Aaj wala one percent aapka hai.",
    "The best way to predict the future is to build it, Sir.",
    "Har expert kabhi beginner tha. Aaj ek step aur aage.",
    "Discipline motivation se zyada reliable hai, Sir. Bas shuru kar dijiye.",
    "Aaj ka din wahi banega jo aap pehle ghante mein decide karenge.",
    "Small progress bhi progress hai, Sir. Momentum matters.",
    "Pressure makes diamonds, Sir. Aur aap kaafi pressure handle kar chuke hain.",
    "You are not the suit, Sir. You are the man who built it.",
    "Kaam aisa kijiye ki result khud bol de.",
]

_QUOTES_EN = [
    "Sometimes you gotta run before you can walk, Sir.",
    "Genius is one percent inspiration, ninety-nine percent perspiration. Today's one percent is yours.",
    "The best way to predict the future is to build it, Sir.",
    "Every expert was once a beginner. One more step today.",
    "Discipline is more reliable than motivation, Sir. Just begin.",
    "The day becomes whatever you decide in its first hour.",
    "Small progress is still progress, Sir. Momentum matters.",
    "Pressure makes diamonds, Sir, and you have handled plenty of it.",
    "You are not the suit, Sir. You are the man who built it.",
    "Do the work so well that the results speak for themselves.",
]


def _greeting_for_hour(hour: int, lang: str) -> str:
    if hour < 5:
        return "Burning the midnight oil, Sir" if lang == "en" else "Late night hai, Sir"
    if hour < 12:
        return "Good morning, Sir"
    if hour < 17:
        return "Good afternoon, Sir"
    return "Good evening, Sir"


def build_briefing(profile=None, reminder_manager=None, memory_store=None,
                   lang: str = "hi") -> str:
    """Assemble the full daily briefing as one spoken paragraph."""
    en = lang == "en"
    now = datetime.now()
    name = getattr(profile, "name", None) or "Sir"
    location = getattr(profile, "location", None) or "Noida"

    lines = [f"{_greeting_for_hour(now.hour, lang)}, {name}."]

    # Time + date
    clock = now.strftime("%I:%M %p").lstrip("0")
    weekday, date = now.strftime("%A"), now.strftime("%d %B %Y")
    lines.append(f"It's {clock}, and today is {weekday}, {date}." if en
                 else f"Abhi {clock} baj rahe hain, aur aaj {weekday}, {date} hai.")

    # Weather
    weather = get_weather(location, lang=lang)
    if weather:
        lines.append(weather)
    elif en:
        lines.append(f"I can't fetch the weather for {location} right now, Sir. "
                     f"Please check the network.")
    else:
        lines.append(f"{location} ka weather abhi fetch nahi ho pa raha, Sir — "
                     f"network check kar lijiye.")

    # Reminders
    if reminder_manager is not None:
        reminders = reminder_manager.describe_pending(lang=lang)
        if reminders:
            lines.append(reminders)
        else:
            lines.append("You have no pending reminders, Sir." if en
                         else "Koi pending reminder nahi hai, Sir.")

    # Anything the user asked JARVIS to remember
    if memory_store is not None and memory_store.count():
        recent = memory_store.all()[-2:]
        facts = "; ".join(entry["text"] for entry in recent)
        lines.append(f"And a reminder of what you told me: {facts}." if en
                     else f"Yaad dilana chahunga: {facts}.")

    lines.append(random.choice(_QUOTES_EN if en else _QUOTES_HI))
    return " ".join(lines)
