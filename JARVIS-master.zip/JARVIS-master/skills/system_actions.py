"""
J.A.R.V.I.S. — System Actions Skill

Windows actions that don't belong to any of the older skill modules:
screenshots, volume control, shutdown and restart.

Shutdown and restart are scheduled with a short delay (not fired instantly) so
the confirmation line finishes speaking and the user still has a window to
abort with `abort_power_action()`.
"""

import ctypes
import os
import subprocess
import time
from datetime import datetime

_SHOTS_DIR = os.path.join(os.path.expanduser("~"), "Pictures", "JARVIS")


def _log(msg):
    print(msg, flush=True)


# ── Screenshot ───────────────────────────────────────

def take_screenshot() -> tuple[bool, str]:
    """Capture the screen to ~/Pictures/JARVIS. Returns (ok, path_or_error)."""
    try:
        os.makedirs(_SHOTS_DIR, exist_ok=True)
        path = os.path.join(
            _SHOTS_DIR, f"jarvis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        )
        # PIL ships with the project (pillow is a vision dependency), and
        # ImageGrab is the least intrusive way to do this on Windows.
        from PIL import ImageGrab
        image = ImageGrab.grab(all_screens=True)
        image.save(path, "PNG")
        _log(f"[JARVIS][SCREENSHOT] Saved {path}")
        return True, path
    except Exception as e:
        _log(f"[JARVIS][SCREENSHOT] Failed: {e}")
        return False, str(e)


# ── Volume ───────────────────────────────────────────
# Sent as virtual key events so no extra dependency (pycaw) is needed.
_VK_VOLUME_MUTE = 0xAD
_VK_VOLUME_DOWN = 0xAE
_VK_VOLUME_UP = 0xAF
_KEYEVENTF_KEYUP = 0x0002


def _tap_key(vk: int, times: int = 1):
    user32 = ctypes.windll.user32
    for _ in range(times):
        user32.keybd_event(vk, 0, 0, 0)
        user32.keybd_event(vk, 0, _KEYEVENTF_KEYUP, 0)
        time.sleep(0.01)


def set_volume(action: str) -> tuple[bool, str]:
    """action: up | down | mute | unmute. Returns (ok, action_taken)."""
    action = (action or "").strip().lower()
    # Each tap moves Windows volume by 2%, so 5 taps is a noticeable 10% step.
    try:
        if action in ("up", "increase", "raise", "louder", "badhao"):
            _tap_key(_VK_VOLUME_UP, 5)
            return True, "up"
        if action in ("down", "decrease", "lower", "quieter", "kam"):
            _tap_key(_VK_VOLUME_DOWN, 5)
            return True, "down"
        if action in ("mute", "silence", "chup", "unmute", "toggle"):
            # Windows exposes a single mute TOGGLE, not separate mute/unmute.
            _tap_key(_VK_VOLUME_MUTE)
            return True, "mute" if action != "unmute" else "unmute"
        if action in ("max", "full"):
            _tap_key(_VK_VOLUME_UP, 50)
            return True, "max"
        if action in ("min", "zero"):
            _tap_key(_VK_VOLUME_DOWN, 50)
            return True, "min"
    except Exception as e:
        _log(f"[JARVIS][VOLUME] Failed: {e}")
        return False, str(e)
    return False, "unknown"


# ── Power ────────────────────────────────────────────

def shutdown_pc(delay_seconds: int = 10) -> bool:
    """Schedule a shutdown. abort_power_action() cancels it within the delay."""
    try:
        subprocess.run(["shutdown", "/s", "/t", str(delay_seconds)],
                       capture_output=True, check=True)
        _log(f"[JARVIS][POWER] Shutdown scheduled in {delay_seconds}s")
        return True
    except Exception as e:
        _log(f"[JARVIS][POWER] Shutdown failed: {e}")
        return False


def restart_pc(delay_seconds: int = 10) -> bool:
    """Schedule a restart. abort_power_action() cancels it within the delay."""
    try:
        subprocess.run(["shutdown", "/r", "/t", str(delay_seconds)],
                       capture_output=True, check=True)
        _log(f"[JARVIS][POWER] Restart scheduled in {delay_seconds}s")
        return True
    except Exception as e:
        _log(f"[JARVIS][POWER] Restart failed: {e}")
        return False


def abort_power_action() -> bool:
    """Cancel a pending shutdown/restart."""
    try:
        subprocess.run(["shutdown", "/a"], capture_output=True)
        _log("[JARVIS][POWER] Pending power action aborted")
        return True
    except Exception as e:
        _log(f"[JARVIS][POWER] Abort failed: {e}")
        return False
