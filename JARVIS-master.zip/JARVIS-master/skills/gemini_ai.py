"""
J.A.R.V.I.S. — Gemini AI Skill
Routes unrecognized queries to Google's Gemini API.
Uses the new google-genai SDK with retry, quota handling,
response caching, and call cooldown to stay within free-tier limits.
"""

import re
import time
from collections import OrderedDict
from config import GEMINI_API_KEY, GEMINI_MODEL, RESPONSE_SYSTEM_PROMPT

_client = None
_last_error_time = 0
_error_cooldown = 60  # Don't retry for 60 seconds after a quota error
_last_call_time = 0
_call_cooldown = 5    # Minimum 5 seconds between API calls

# ── Model fallback chain ─────────────────────────────
# Each Gemini model has its OWN free-tier quota bucket. When the primary model
# returns 429 (quota exhausted), we fall through to the next model that still
# has quota instead of giving up — so JARVIS keeps answering. Order: configured
# model first, then progressively lighter models with separate/higher free limits.
_FALLBACK_MODELS = []
for _m in (GEMINI_MODEL, "gemini-2.5-flash-lite", "gemini-flash-latest"):
    if _m and _m not in _FALLBACK_MODELS:
        _FALLBACK_MODELS.append(_m)

# ── Response Cache ────────────────────────────────────
_cache = OrderedDict()
_CACHE_MAX_SIZE = 50


def _normalize_for_cache(text: str) -> str:
    """Normalize text for cache key comparison."""
    return re.sub(r'[^\w\s]', '', text.lower()).strip()


def _cache_get(text: str) -> str | None:
    """Look up a cached response."""
    key = _normalize_for_cache(text)
    if key in _cache:
        # Move to end (most recently used)
        _cache.move_to_end(key)
        return _cache[key]
    return None


def _cache_put(text: str, response: str):
    """Store a response in the cache."""
    key = _normalize_for_cache(text)
    _cache[key] = response
    # Evict oldest if over limit
    while len(_cache) > _CACHE_MAX_SIZE:
        _cache.popitem(last=False)


# ── Junk Input Filter ────────────────────────────────
# Short, meaningless fragments that Whisper hallucinates or the user
# says as filler — these should NOT be sent to Gemini.
_JUNK_PATTERNS = {
    "jarvis", "hey", "yeah", "yes", "no", "nope", "okay", "ok",
    "um", "uh", "hmm", "huh", "ah", "oh", "ooh", "wow",
    "i'm not", "i'm here", "i'm not sure", "i'm sorry",
    "sorry", "what", "hm", "right", "sure", "fine", "cool",
    # Common Whisper hallucinations on silence/background noise
    "you", "thank you", "thanks", "thanks for watching", "bye",
    "the end", "subscribe", "please subscribe", "you you", "yeah yeah",
    "mm", "mhm", "mm hmm", "uh huh", "so", "and", "the",
}


def _is_junk_input(text: str) -> bool:
    """Return True if input is too short/meaningless to spend an API call on.

    This is the last line of defence so random noise transcribed while JARVIS
    is awake never reaches Gemini and never burns free-tier quota.
    """
    cleaned = re.sub(r'[^\w\s]', '', text.lower()).strip()

    # Empty after cleaning
    if not cleaned:
        return True

    # Too short to be a real question (<= 2 words and < 12 chars)
    words = cleaned.split()
    if len(words) <= 2 and len(cleaned) < 12:
        return True

    # Known junk / hallucination phrases
    if cleaned in _JUNK_PATTERNS:
        return True

    return False


def _init_gemini():
    """Initialize Gemini client using the new google-genai SDK."""
    global _client
    if _client is not None:
        return True

    if not GEMINI_API_KEY:
        return False

    try:
        from google import genai
        _client = genai.Client(api_key=GEMINI_API_KEY)
        return True
    except ImportError:
        # Fall back to old SDK if new one not available
        try:
            import google.generativeai as genai
            genai.configure(api_key=GEMINI_API_KEY)
            _client = "legacy"
            return True
        except Exception as e:
            print(f"[JARVIS] Gemini init error: {e}", flush=True)
            return False
    except Exception as e:
        print(f"[JARVIS] Gemini init error: {e}", flush=True)
        return False


def _query_new_sdk(text: str, model: str = GEMINI_MODEL,
                   system_prompt: str = RESPONSE_SYSTEM_PROMPT) -> str:
    """Query using the new google-genai SDK."""
    from google import genai

    response = _client.models.generate_content(
        model=model,
        contents=text,
        config=genai.types.GenerateContentConfig(
            system_instruction=system_prompt,
            max_output_tokens=200,
        ),
    )
    return (response.text or "").strip()


def _query_legacy_sdk(text: str, model: str = GEMINI_MODEL,
                      system_prompt: str = RESPONSE_SYSTEM_PROMPT) -> str:
    """Query using the legacy google.generativeai SDK."""
    import google.generativeai as genai

    gmodel = genai.GenerativeModel(
        model_name=model,
        system_instruction=system_prompt,
    )
    response = gmodel.generate_content(text)
    return (response.text or "").strip()


def is_gemini_available() -> bool:
    """Check if Gemini API is configured and not rate-limited."""
    if not GEMINI_API_KEY:
        return False
    if not _init_gemini():
        return False
    # If we're in cooldown, still report as available (just throttled)
    return True


def ask_gemini(text: str, system_prompt: str = RESPONSE_SYSTEM_PROMPT,
               lang: str = "hi") -> str:
    """Send a query to Gemini and return the response.

    Includes protections against rate-limiting:
    - Rejects junk/fragment inputs
    - Enforces minimum cooldown between calls
    - Checks response cache before calling API
    - Caches successful responses
    """
    global _last_error_time, _last_call_time

    # ── Step 1: Reject junk inputs ───────────────────
    if _is_junk_input(text):
        print(f"[JARVIS] Gemini skipped (junk input): '{text}'", flush=True)
        if lang == "en":
            return "I didn't catch the whole command, Sir. Could you say that again?"
        return "Poori command samajh nahi aayi, Sir. Ek baar phir boliye?"

    # ── Step 2: Check cache ──────────────────────────
    cached = _cache_get(text)
    if cached:
        print(f"[JARVIS] Gemini cache hit: '{text}'", flush=True)
        return cached

    # ── Step 3: Check API availability ───────────────
    if not _init_gemini():
        if lang != "en":
            return ("Sir, AI module abhi configure nahi hai. "
                    "GEMINI_API_KEY set kijiye, tab main aise sawaalon ke jawab de paunga.")
        return (
            "I'm sorry sir, but my advanced reasoning module isn't configured yet. "
            "Please set the GEMINI_API_KEY environment variable to enable AI-powered responses."
        )

    # ── Step 4: Check error cooldown ─────────────────
    if _last_error_time > 0:
        elapsed = time.time() - _last_error_time
        if elapsed < _error_cooldown:
            remaining = int(_error_cooldown - elapsed)
            if lang != "en":
                return (f"Systems thode overloaded hain, Sir. Lagbhag {remaining} second "
                        f"mein wapas aata hoon. Tab tak time, apps ya system info pooch sakte hain.")
            return (
                f"My systems are momentarily overloaded, sir. Give me a moment to recalibrate — "
                f"I'll be back to full capacity in about {remaining} seconds. "
                f"In the meantime, try asking me the time, to open an app, or for system info."
            )
        else:
            _last_error_time = 0  # Reset cooldown

    # ── Step 5: Enforce call cooldown ────────────────
    now = time.time()
    since_last = now - _last_call_time
    if since_last < _call_cooldown:
        wait_time = _call_cooldown - since_last
        print(f"[JARVIS] Gemini cooldown: waiting {wait_time:.1f}s", flush=True)
        time.sleep(wait_time)

    # ── Step 6: Call API, falling through the model chain on 429 ─────
    # Each model has its own free-tier quota bucket, so when the primary is
    # exhausted (429) we immediately try the next model instead of failing.
    _last_call_time = time.time()

    def _run(model: str) -> str:
        if _client == "legacy":
            return _query_legacy_sdk(text, model, system_prompt)
        return _query_new_sdk(text, model, system_prompt)

    last_transient = False
    for i, model in enumerate(_FALLBACK_MODELS):
        is_last = i == len(_FALLBACK_MODELS) - 1
        try:
            response = _run(model)
            if i > 0:
                print(f"[JARVIS] Gemini answered via fallback model: {model}", flush=True)
            _cache_put(text, response)
            return response

        except Exception as e:
            error_str = str(e).lower()
            is_rate_limit = any(
                kw in error_str
                for kw in ("429", "quota", "rate limit", "rate_limit",
                           "resource_exhausted", "resource exhausted")
            )
            # 503 / overloaded / high demand are TRANSIENT — another model may
            # serve the request, so treat them like rate-limits and fall through.
            is_transient = is_rate_limit or any(
                kw in error_str
                for kw in ("503", "unavailable", "overloaded", "high demand", "try again")
            )
            last_transient = is_transient
            print(f"[JARVIS] Gemini error ({model}): {str(e)[:160]}", flush=True)

            if is_transient and not is_last:
                # Quota/overload on this model — try the next model in the chain.
                print(f"[JARVIS] {model} unavailable — falling through to next model...", flush=True)
                continue

            if not is_transient and not is_last:
                # Hard error (auth/network) on this model — one quick retry here,
                # then fall through to the next model rather than giving up.
                try:
                    time.sleep(1)
                    response = _run(model)
                    _cache_put(text, response)
                    return response
                except Exception:
                    continue

    # Every model failed. Distinguish quota/overload from a hard fault.
    if last_transient:
        _last_error_time = time.time()
        if lang == "en":
            return "Systems are recalibrating, Sir. Please try again in a moment."
        return "Systems recalibrate ho rahe hain, Sir. Ek moment mein phir try kijiye."
    if lang != "en":
        return "Sir, network se connect nahi ho pa raha. Internet check kar lijiye."
    return (
        "I'm having trouble reaching my neural network at the moment, sir. "
        "Please check your internet connection."
    )
