"""
J.A.R.V.I.S. — Vision Skill (camera, face recognition, gestures, visual query)

Design rules:
  * The camera is OFF by default and only ever runs when explicitly asked
    (voice command). It is NEVER kept running in the background.
  * All heavy libraries (OpenCV, MediaPipe, face_recognition, google-genai)
    are imported defensively so a missing/broken library degrades the feature
    gracefully instead of crashing the whole assistant.

Capabilities:
  * start()/stop()            -> turn the webcam on/off
  * face recognition          -> owner vs unknown vs multiple people
  * hand gestures (MediaPipe) -> thumbs up / open palm / peace / fist
  * describe_scene()          -> capture a frame and ask Gemini Vision

Events are reported through an event_callback(event_type, payload) supplied by
the caller. The callback may be invoked from the internal camera thread, so the
caller must marshal back to its UI thread (e.g. via a Qt signal).
"""

import os
import time
import base64
import threading

import numpy as np

# Quieten MediaPipe / glog chatter before it is imported.
os.environ.setdefault("GLOG_minloglevel", "2")
os.environ.setdefault("MEDIAPIPE_DISABLE_GPU", "1")

from config import ASSETS_DIR, GEMINI_API_KEY, GEMINI_MODEL


def _log(msg):
    print(msg, flush=True)


# ── Defensive imports ────────────────────────────────
try:
    import cv2
    _CV2_OK = True
except Exception as e:  # pragma: no cover
    _CV2_OK = False
    _log(f"[JARVIS][VISION] OpenCV (cv2) unavailable: {e}")

try:
    import mediapipe as mp
    _MP_OK = True
except Exception as e:  # pragma: no cover
    _MP_OK = False
    _log(f"[JARVIS][VISION] MediaPipe unavailable: {e}")

try:
    import face_recognition
    _FR_OK = True
except Exception as e:  # pragma: no cover
    _FR_OK = False
    _log(f"[JARVIS][VISION] face_recognition unavailable: {e}")


# ── Tunables ─────────────────────────────────────────
OWNER_FACE_FILE = os.path.join(ASSETS_DIR, "owner_face.npy")
CAMERA_INDEX = 0
FACE_TOLERANCE = 0.6           # more lenient so the owner is recognised reliably
FACE_CHECK_INTERVAL = 1.0      # seconds between face-recognition passes
FACE_RESET_SEC = 5.0           # face must be absent this long to re-greet
DETECT_SCALE = 0.5             # downscale factor for face detection (speed)

# Owner enrollment: capture several photos from slightly different angles.
ENROLL_PHOTOS = 5
ENROLL_MIN_INTERVAL = 0.5      # seconds between enrollment captures

# Gesture confirmation: the gesture must be held CONTINUOUSLY for GESTURE_HOLD_SEC.
# Stability is judged over a short rolling confidence window. After ANY gesture
# fires, all gestures are ignored for GESTURE_GLOBAL_COOLDOWN seconds.
GESTURE_HOLD_SEC = 1.5          # must hold the gesture continuously this long
GESTURE_CONF_WINDOW = 0.5       # short window for "is it stable right now"
GESTURE_CONFIDENCE_MIN = 0.75   # >=75% agreement within the confidence window
GESTURE_GLOBAL_COOLDOWN = 5.0   # ignore all gestures this long after one fires
DEBUG_LOG_INTERVAL = 0.4        # throttle the continuous debug logging

# Thumb extension ratio = distance(thumb tip, index MCP) / palm width.
# Below this the thumb is "curled" (FIST); above it the thumb is "extended"
# (THUMBS UP). Tunable — watch the d=… value in the debug log to calibrate.
THUMB_EXTEND_RATIO = 0.7


# ── Gesture classification (pure, unit-testable) ─────
# MediaPipe hand landmark indices:
#   thumb:  CMC1 MCP2 IP3 TIP4
#   index:  MCP5 PIP6 DIP7 TIP8
#   middle: 9 10 11 12 ; ring: 13 14 15 16 ; pinky: 17 18 19 20
def _dist(a, b):
    return ((a.x - b.x) ** 2 + (a.y - b.y) ** 2) ** 0.5


def _main_fingers_up(lm):
    """Return [index, middle, ring, pinky] booleans: tip ABOVE its PIP joint.

    `lm` is a sequence of 21 landmarks, each with `.x`/`.y` in normalised image
    coords where y grows downward (so 'up' = a smaller y than the PIP joint).
    """
    return [
        lm[8].y < lm[6].y,    # index  tip(8)  vs PIP(6)
        lm[12].y < lm[10].y,  # middle tip(12) vs PIP(10)
        lm[16].y < lm[14].y,  # ring   tip(16) vs PIP(14)
        lm[20].y < lm[18].y,  # pinky  tip(20) vs PIP(18)
    ]


def _thumb_ratio(lm):
    """distance(thumb tip 4, index MCP 5) / palm width (index MCP 5 -> pinky MCP 17).

    Scale-invariant. Small => thumb curled against the hand (fist); large =>
    thumb extended away from the hand (thumbs up).
    """
    palm = _dist(lm[5], lm[17])
    if palm < 1e-6:
        palm = 1e-6
    return _dist(lm[4], lm[5]) / palm


def classify_gesture(lm, handedness=None):
    """Classify one hand. Returns (gesture_or_None, n_main_fingers, thumb_state, ratio).

    Fist vs thumbs-up is decided ONLY by how far the thumb is from the hand, so
    a natural fist (thumb resting on top, sometimes read as 'up') is still a FIST:
      * open_palm : all 4 fingers up
      * peace     : ONLY index + middle up
      * thumbs_up : all 4 fingers down AND thumb extended away from the hand
      * fist      : all 4 fingers down AND thumb curled close to the hand
    """
    index_up, middle_up, ring_up, pinky_up = _main_fingers_up(lm)
    n = sum([index_up, middle_up, ring_up, pinky_up])
    ratio = _thumb_ratio(lm)
    thumb_extended = ratio > THUMB_EXTEND_RATIO
    thumb_state = "extended" if thumb_extended else "curled"

    gesture = None
    if index_up and middle_up and ring_up and pinky_up:
        gesture = "open_palm"
    elif index_up and middle_up and not ring_up and not pinky_up:
        gesture = "peace"
    elif n == 0 and thumb_extended:
        gesture = "thumbs_up"
    elif n == 0:                       # 4 fingers closed, thumb curled -> fist
        gesture = "fist"
    return gesture, n, thumb_state, ratio


class VisionSystem:
    """Manages the webcam and all vision processing on a background thread."""

    def __init__(self, event_callback=None):
        self.event_callback = event_callback
        self._cap = None
        self._hands = None
        self._thread = None
        self._running = threading.Event()
        self._lock = threading.Lock()
        self._latest_frame = None
        self._owner_encodings = self._load_owner()

        # Face announce-once tracking
        self._announced = set()          # scene types already announced this presence
        self._no_face_since = None       # when the frame first went empty
        self._last_scene = None

        # Owner enrollment (multi-photo) state
        self._enrolling = False
        self._enroll_encodings = []
        self._enroll_last_capture = 0.0

        # Gesture confirmation tracking
        from collections import deque
        self._gesture_history = deque()  # (timestamp, gesture-or-None)
        self._last_gesture_action_time = 0.0
        self._gesture_dominant = None
        self._gesture_confidence = 0.0
        # Continuous-hold timer (unbounded, unlike the confidence window)
        self._hold_gesture = None
        self._hold_start = 0.0
        self._gesture_held = 0.0

        # Live debug / preview state
        self._last_gesture = None
        self._last_fingers = 0
        self._last_thumb_state = "-"
        self._last_thumb_ratio = 0.0
        self._last_face_label = "NONE"
        self._last_face_conf = 0.0
        self._last_face_boxes = []        # [(top,right,bottom,left,label,conf)] full-res
        self._preview_frame = None
        self._last_debug_log = 0.0

    # ── Availability / status ────────────────────────
    @staticmethod
    def is_available() -> bool:
        return _CV2_OK

    def is_running(self) -> bool:
        return self._running.is_set()

    def is_owner_enrolled(self) -> bool:
        return self._owner_encodings is not None and len(self._owner_encodings) > 0

    def capabilities(self) -> dict:
        return {"camera": _CV2_OK, "faces": _FR_OK, "gestures": _MP_OK}

    # ── Owner face persistence ───────────────────────
    def _load_owner(self):
        try:
            if os.path.exists(OWNER_FACE_FILE):
                arr = np.load(OWNER_FACE_FILE)
                if arr.ndim == 2 and arr.shape[1] == 128 and len(arr) > 0:
                    _log(f"[JARVIS][VISION] Loaded owner face ({len(arr)} encoding(s))")
                    return arr
        except Exception as e:
            _log(f"[JARVIS][VISION] Could not load owner face: {e}")
        return None

    def _save_owner(self, encodings):
        try:
            os.makedirs(os.path.dirname(OWNER_FACE_FILE), exist_ok=True)
            np.save(OWNER_FACE_FILE, encodings)
            self._owner_encodings = encodings
            return True
        except Exception as e:
            _log(f"[JARVIS][VISION] Could not save owner face: {e}")
            return False

    def _enroll_from_rgb(self, rgb):
        """Enroll the single face in `rgb` as the owner. Returns (ok, message)."""
        if not _FR_OK:
            return False, "Face recognition isn't available, sir."
        locs = face_recognition.face_locations(rgb)
        if len(locs) == 0:
            return False, "I can't see a face to register, sir."
        if len(locs) > 1:
            return False, "I see more than one face; please be alone to register, sir."
        enc = face_recognition.face_encodings(rgb, locs)[0]
        if self._save_owner(np.array([enc])):
            return True, "I've registered your face, sir. I'll recognise you from now on."
        return False, "I had trouble saving your face, sir."

    # ── Camera lifecycle ─────────────────────────────
    def start(self):
        """Turn the camera ON. Returns (ok, message)."""
        if not _CV2_OK:
            return False, "Camera support isn't installed, sir."
        if self.is_running():
            return True, "Vision is already active, sir."

        cap = cv2.VideoCapture(CAMERA_INDEX, cv2.CAP_DSHOW)
        if not cap.isOpened():
            try:
                cap.release()
            except Exception:
                pass
            return False, "I couldn't access the camera, sir."
        self._cap = cap

        if _MP_OK:
            try:
                self._hands = mp.solutions.hands.Hands(
                    static_image_mode=False,
                    max_num_hands=2,
                    min_detection_confidence=0.6,
                    min_tracking_confidence=0.5,
                )
            except Exception as e:
                _log(f"[JARVIS][VISION] Hands init failed: {e}")
                self._hands = None

        # Fresh tracking state for this session.
        self._last_scene = None
        self._announced = set()
        self._no_face_since = None
        self._gesture_history.clear()
        self._last_gesture_action_time = 0.0
        self._hold_gesture = None
        self._hold_start = 0.0
        self._gesture_held = 0.0
        self._last_face_boxes = []
        self._preview_frame = None
        self._running.set()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        _log("[JARVIS][VISION] Camera ON")

        if not self.is_owner_enrolled():
            # Kick off multi-photo owner enrollment.
            self._enrolling = True
            self._enroll_encodings = []
            self._enroll_last_capture = 0.0
            return True, "Registering owner face, sir. Please look at the camera."
        return True, "Vision online, sir. I'm watching."

    def stop(self):
        """Turn the camera OFF and release all resources."""
        was_running = self.is_running()
        self._running.clear()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None
        if self._hands is not None:
            try:
                self._hands.close()
            except Exception:
                pass
            self._hands = None
        if self._cap is not None:
            try:
                self._cap.release()
            except Exception:
                pass
            self._cap = None
        with self._lock:
            self._latest_frame = None
        if was_running:
            _log("[JARVIS][VISION] Camera OFF")

    # ── Main processing loop (background thread) ─────
    def _loop(self):
        last_face_check = 0.0
        while self._running.is_set():
            try:
                ok, frame = self._cap.read()
            except Exception as e:
                _log(f"[JARVIS][VISION] Camera read error: {e}")
                time.sleep(0.1)
                continue
            if not ok or frame is None:
                time.sleep(0.05)
                continue

            with self._lock:
                self._latest_frame = frame

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            now = time.time()

            # Gestures — cheap, run every frame. Register EVERY frame (incl.
            # no-hand frames as None) so flicker lowers the confidence.
            g, n_fingers, thumb_state, thumb_ratio = None, 0, "-", 0.0
            if self._hands is not None:
                try:
                    res = self._hands.process(rgb)
                    if res.multi_hand_landmarks:
                        handed = None
                        if res.multi_handedness:
                            handed = res.multi_handedness[0].classification[0].label
                        g, n_fingers, thumb_state, thumb_ratio = classify_gesture(
                            res.multi_hand_landmarks[0].landmark, handed)
                    confirmed = self._register_gesture_frame(g, now)
                    if confirmed:
                        self._emit("gesture_" + confirmed, confirmed)
                except Exception as e:
                    _log(f"[JARVIS][VISION] Gesture error: {e}")
            self._last_gesture = g
            self._last_fingers = n_fingers
            self._last_thumb_state = thumb_state
            self._last_thumb_ratio = thumb_ratio

            # Faces — expensive, throttle.
            if _FR_OK and (now - last_face_check) >= FACE_CHECK_INTERVAL:
                last_face_check = now
                try:
                    small = cv2.resize(rgb, (0, 0), fx=DETECT_SCALE, fy=DETECT_SCALE)
                    self._process_faces(small, 1.0 / DETECT_SCALE)
                except Exception as e:
                    _log(f"[JARVIS][VISION] Face error: {e}")

            # Build the annotated preview frame.
            try:
                with self._lock:
                    self._preview_frame = self._annotate_preview(
                        frame.copy(), n_fingers, thumb_state, g)
            except Exception as e:
                _log(f"[JARVIS][VISION] Preview error: {e}")

            self._debug_log(now, n_fingers, thumb_state, thumb_ratio, g)
            time.sleep(0.03)

    def _set_face_boxes(self, locs, scale, labels):
        """Store face boxes (scaled to full-res) with labels for the preview."""
        boxes = []
        for (top, right, bottom, left), (label, conf) in zip(locs, labels):
            boxes.append((int(top * scale), int(right * scale),
                          int(bottom * scale), int(left * scale), label, conf))
        self._last_face_boxes = boxes

    def _process_faces(self, rgb, scale):
        locs = face_recognition.face_locations(rgb)
        n = len(locs)
        now = time.time()

        # ── Owner enrollment: capture ENROLL_PHOTOS of a lone face ──
        if self._enrolling:
            if n == 1:
                self._set_face_boxes(locs, scale, [("OWNER", 100.0)])
                if (now - self._enroll_last_capture) >= ENROLL_MIN_INTERVAL:
                    enc = face_recognition.face_encodings(rgb, locs)[0]
                    self._enroll_encodings.append(enc)
                    self._enroll_last_capture = now
                    _log(f"[JARVIS][VISION] Enrollment photo "
                         f"{len(self._enroll_encodings)}/{ENROLL_PHOTOS}")
                    if len(self._enroll_encodings) >= ENROLL_PHOTOS:
                        self._save_owner(np.array(self._enroll_encodings))
                        self._enrolling = False
                        self._announced.clear()
                        self._emit("enrolled",
                                   "I've registered your face, sir. I'll recognise you from now on.")
            else:
                self._last_face_boxes = []
            return

        # No face: after FACE_RESET_SEC of absence, allow greetings again.
        if n == 0:
            self._last_face_label, self._last_face_conf = "NONE", 0.0
            self._last_face_boxes = []
            if self._no_face_since is None:
                self._no_face_since = now
            elif (now - self._no_face_since) >= FACE_RESET_SEC and self._announced:
                _log("[JARVIS][VISION] Face absent >= 5s — greeting re-armed")
                self._announced.clear()
            self._last_scene = "none"
            return

        # A face is present again — cancel the absence timer.
        self._no_face_since = None
        encs = face_recognition.face_encodings(rgb, locs)
        labels = []
        for enc in encs:
            d = float(np.min(face_recognition.face_distance(self._owner_encodings, enc)))
            is_owner = d <= FACE_TOLERANCE
            conf = max(0.0, min(1.0, 1.0 - d)) * 100.0
            labels.append(("OWNER" if is_owner else "UNKNOWN", conf))
        self._set_face_boxes(locs, scale, labels)

        if n >= 2:
            scene = "multiple"
            self._last_face_label, self._last_face_conf = "MULTI", 0.0
        else:
            label, conf = labels[0]
            scene = "owner" if label == "OWNER" else "unknown"
            self._last_face_label, self._last_face_conf = label, conf

        self._last_scene = scene
        # Announce each scene type at most ONCE per presence (until a >=5s gap).
        if scene not in self._announced:
            self._announced.add(scene)
            self._emit({
                "owner": "face_owner",
                "unknown": "face_unknown",
                "multiple": "face_multiple",
            }[scene])

    def _register_gesture_frame(self, gesture, now):
        """Record one frame's gesture and decide whether to fire an action.

        Returns the confirmed gesture name (and starts the global cooldown), or
        None. A gesture fires only when it is held for >= GESTURE_HOLD_SEC with
        >= GESTURE_CONFIDENCE_MIN agreement across the window.
        """
        # Short rolling window just to judge current stability (confidence).
        h = self._gesture_history
        h.append((now, gesture))
        while h and (now - h[0][0]) > GESTURE_CONF_WINDOW:
            h.popleft()

        counts = {}
        for _, g in h:
            if g:
                counts[g] = counts.get(g, 0) + 1
        dominant, dcount = None, 0
        for g, c in counts.items():
            if c > dcount:
                dominant, dcount = g, c
        total = len(h)
        confidence = (dcount / total) if (dominant and total) else 0.0
        self._gesture_dominant = dominant
        self._gesture_confidence = confidence

        # ── Continuous-hold timer (this is what actually gates the trigger) ──
        # If the same stable gesture persists, the held time GROWS unbounded.
        # If it changes or destabilises, the timer restarts. (The old code
        # compared a span that was capped by the trim window, so with jittery
        # real-camera timing it never reached the threshold -> never fired.)
        if dominant is not None and confidence >= GESTURE_CONFIDENCE_MIN:
            if dominant != self._hold_gesture:
                self._hold_gesture = dominant
                self._hold_start = now
            self._gesture_held = now - self._hold_start
        else:
            self._hold_gesture = None
            self._hold_start = now
            self._gesture_held = 0.0

        # Global cooldown: ignore ALL gestures for 5s after one fires.
        if (now - self._last_gesture_action_time) < GESTURE_GLOBAL_COOLDOWN:
            return None

        if self._hold_gesture is not None and self._gesture_held >= GESTURE_HOLD_SEC:
            confirmed = self._hold_gesture
            self._last_gesture_action_time = now
            _log(f"[JARVIS][VISION] {confirmed.upper()} held for "
                 f"{self._gesture_held:.1f}s ... TRIGGERED")
            _log(f"[JARVIS][VISION] >>> CONFIRMED gesture: {confirmed} "
                 f"(held {self._gesture_held:.1f}s, confidence {confidence * 100:.0f}%)")
            self._hold_gesture = None
            self._hold_start = now
            self._gesture_held = 0.0
            h.clear()
            return confirmed
        return None

    def _debug_log(self, now, n_fingers, thumb_state, thumb_ratio, gesture):
        """Continuously print finger count, thumb position, gesture + confidences."""
        if (now - self._last_debug_log) < DEBUG_LOG_INTERVAL:
            return
        self._last_debug_log = now
        gname = (gesture or "NONE").upper()
        gconf = self._gesture_confidence * 100.0
        cooldown = GESTURE_GLOBAL_COOLDOWN - (now - self._last_gesture_action_time)
        cd = f" cooldown={cooldown:.1f}s" if cooldown > 0 else ""
        # Live hold countdown so you can see the 1.5s timer progressing.
        if self._hold_gesture is not None:
            hold = f" HOLD={self._hold_gesture.upper()} {self._gesture_held:.1f}s/{GESTURE_HOLD_SEC:.1f}s"
        else:
            hold = " HOLD=-"
        _log(f"[JARVIS][VISION] Fingers: {n_fingers}, "
             f"Thumb position: {thumb_state} (d={thumb_ratio:.2f}), Gesture: {gname} | "
             f"g_conf={gconf:3.0f}% face={self._last_face_label:7s} "
             f"f_conf={self._last_face_conf:3.0f}%{hold}{cd}")

    def _annotate_preview(self, frame, n_fingers, thumb_state, gesture):
        """Draw face boxes + gesture/finger overlay onto a preview frame (BGR)."""
        if not _CV2_OK:
            return frame
        h = frame.shape[0]
        for (top, right, bottom, left, label, conf) in self._last_face_boxes:
            color = (0, 255, 0) if label == "OWNER" else (0, 0, 255)
            cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
            cv2.putText(frame, f"{label} {conf:.0f}%", (left, max(18, top - 8)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)
        cv2.putText(frame, f"Fingers: {n_fingers}  Thumb: {thumb_state}", (8, 24),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 2)
        banner = (gesture.upper().replace("_", " ") + " DETECTED") if gesture else "NO GESTURE"
        cv2.putText(frame, banner, (8, h - 12),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
        return frame

    def get_preview_frame(self):
        """Return a copy of the latest annotated preview frame, or None."""
        with self._lock:
            return None if self._preview_frame is None else self._preview_frame.copy()

    def _emit(self, event_type, payload=""):
        _log(f"[JARVIS][VISION] event -> {event_type}")
        if self.event_callback:
            try:
                self.event_callback(event_type, str(payload))
            except Exception as e:
                _log(f"[JARVIS][VISION] event callback error: {e}")

    # ── Frame capture + visual query ─────────────────
    def capture_frame(self):
        """Return a single BGR frame. Uses the live feed if running, otherwise
        briefly opens the camera, grabs a frame, and closes it again."""
        if self.is_running():
            with self._lock:
                if self._latest_frame is not None:
                    return self._latest_frame.copy()
        if not _CV2_OK:
            return None
        cap = cv2.VideoCapture(CAMERA_INDEX, cv2.CAP_DSHOW)
        frame = None
        try:
            if cap.isOpened():
                for _ in range(6):  # let exposure settle
                    ok, f = cap.read()
                    if ok and f is not None:
                        frame = f
                    time.sleep(0.05)
        finally:
            cap.release()
        return frame

    def describe_scene(self):
        """Capture a frame and ask Gemini Vision to describe it."""
        frame = self.capture_frame()
        if frame is None:
            return "I couldn't capture anything from the camera, sir."
        return self._gemini_vision(frame)

    # Exact line JARVIS speaks when vision analysis fails even after a retry.
    _VISION_FALLBACK = ("My visual processors are temporarily offline sir. "
                        "I can see you but I cannot analyse the scene right now.")

    def _gemini_vision(self, frame):
        if not GEMINI_API_KEY:
            return ("My vision analysis needs the Gemini API configured, sir. "
                    "Please set the GEMINI_API_KEY.")

        # ── Encode the OpenCV BGR frame -> JPEG bytes -> base64 ──
        ok, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
        if not ok:
            _log("[JARVIS][VISION] VISION ERROR: failed to JPEG-encode the frame")
            return self._VISION_FALLBACK
        image_bytes = buf.tobytes()
        b64 = base64.b64encode(image_bytes).decode("ascii")
        _log(f"[JARVIS][VISION] Frame {frame.shape} -> JPEG {len(image_bytes)} bytes "
             f"-> base64 {len(b64)} chars")

        prompt = (
            "You are JARVIS, Tony Stark's AI. Describe what you see in this "
            "webcam image in 1-3 concise sentences, addressing the user as 'sir'. "
            "Do not use markdown."
        )
        # Both are multimodal (image-capable) and available on the free tier.
        # Attempt 1 uses the configured model; the retry falls back to
        # gemini-flash-latest in case the first model is unavailable/limited.
        models_to_try = [GEMINI_MODEL, "gemini-flash-latest"]
        last_err = None

        for attempt in range(2):
            model = models_to_try[min(attempt, len(models_to_try) - 1)]
            try:
                from google import genai
                from google.genai import types
                client = genai.Client(api_key=GEMINI_API_KEY)
                resp = client.models.generate_content(
                    model=model,
                    contents=[
                        # from_bytes sends the JPEG as an inline base64 image part.
                        types.Part.from_bytes(data=image_bytes, mime_type="image/jpeg"),
                        prompt,
                    ],
                )
                _log(f"[JARVIS][VISION] Full API response (model={model}): {resp}")
                text = (resp.text or "").strip()
                if text:
                    _log(f"[JARVIS][VISION] Scene description: {text}")
                    return text
                last_err = "API returned an empty response (possibly safety-blocked)"
                _log(f"[JARVIS][VISION] VISION ERROR: {last_err}")
            except Exception as e:
                last_err = e
                _log(f"[JARVIS][VISION] VISION ERROR: {e}")
                import traceback
                traceback.print_exc()

            if attempt == 0:
                _log("[JARVIS][VISION] Retrying vision analysis in 5s...")
                time.sleep(5)

        _log(f"[JARVIS][VISION] Vision analysis failed after retry. Last error: {last_err}")
        return self._VISION_FALLBACK
