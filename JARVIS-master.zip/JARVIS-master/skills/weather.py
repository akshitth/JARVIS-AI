"""
J.A.R.V.I.S. — Weather Skill

Uses Open-Meteo, which needs no API key and no account, so the daily briefing
works out of the box. Results are cached for 15 minutes — the briefing is
usually asked for once a morning, and there is no reason to hit the network
twice for the same number.

Every failure path returns None rather than raising, so a dead network can
never break the briefing.
"""

import json
import threading
import time
import urllib.parse
import urllib.request

from config import WEATHER_LAT, WEATHER_LON, WEATHER_TIMEOUT

_CACHE = {"at": 0.0, "data": None}
_CACHE_TTL = 900          # 15 minutes
_lock = threading.Lock()

# Open-Meteo WMO weather codes, condensed to what a voice assistant should say.
_CONDITIONS = {
    0: "saaf aasman", 1: "mostly clear", 2: "thoda cloudy", 3: "cloudy",
    45: "dhundh", 48: "dhundh", 51: "halki boondabandi", 53: "boondabandi",
    55: "tez boondabandi", 61: "halki baarish", 63: "baarish", 65: "tez baarish",
    66: "thandi baarish", 67: "tez thandi baarish", 71: "halki barfbari",
    73: "barfbari", 75: "tez barfbari", 80: "halki baarish",
    81: "baarish", 82: "moosladhar baarish", 95: "toofan",
    96: "toofan with olay", 99: "tez toofan",
}

_CONDITIONS_EN = {
    0: "clear skies", 1: "mostly clear", 2: "partly cloudy", 3: "cloudy",
    45: "foggy", 48: "foggy", 51: "light drizzle", 53: "drizzle",
    55: "heavy drizzle", 61: "light rain", 63: "rain", 65: "heavy rain",
    66: "freezing rain", 67: "heavy freezing rain", 71: "light snow",
    73: "snow", 75: "heavy snow", 80: "light showers",
    81: "showers", 82: "violent showers", 95: "thunderstorms",
    96: "thunderstorms with hail", 99: "severe thunderstorms",
}


def _fetch() -> dict | None:
    params = {
        "latitude": WEATHER_LAT,
        "longitude": WEATHER_LON,
        "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code",
        "daily": "temperature_2m_max,temperature_2m_min",
        "timezone": "Asia/Kolkata",
        "forecast_days": 1,
    }
    url = "https://api.open-meteo.com/v1/forecast?" + urllib.parse.urlencode(params)
    try:
        with urllib.request.urlopen(url, timeout=WEATHER_TIMEOUT) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception as e:
        print(f"[JARVIS][WEATHER] Fetch failed: {e}", flush=True)
        return None


def get_weather(location: str = "Noida", lang: str = "hi") -> str | None:
    """One sentence of current weather (English or Hinglish), or None."""
    with _lock:
        fresh = _CACHE["data"] and (time.time() - _CACHE["at"] < _CACHE_TTL)
        data = _CACHE["data"] if fresh else _fetch()
        if data:
            _CACHE["data"], _CACHE["at"] = data, time.time()

    if not data:
        return None

    try:
        current = data["current"]
        temp = round(current["temperature_2m"])
        feels = round(current.get("apparent_temperature", temp))
        humidity = current.get("relative_humidity_2m")
        conditions = _CONDITIONS_EN if lang == "en" else _CONDITIONS
        condition = conditions.get(current.get("weather_code"), "normal weather")
        daily = data.get("daily", {})
        high = round(daily["temperature_2m_max"][0]) if daily.get("temperature_2m_max") else None
        low = round(daily["temperature_2m_min"][0]) if daily.get("temperature_2m_min") else None
    except (KeyError, IndexError, TypeError) as e:
        print(f"[JARVIS][WEATHER] Unexpected response shape: {e}", flush=True)
        return None

    if lang == "en":
        line = f"It's {temp} degrees in {location} right now, {condition}"
        if abs(feels - temp) >= 2:
            line += f", feeling like {feels}"
        if high is not None and low is not None:
            line += f". Today's high is {high} and the low is {low} degrees"
        if humidity is not None:
            line += f", with humidity at {humidity} percent"
        return line + "."

    line = f"{location} mein abhi {temp} degrees hai, {condition}"
    if abs(feels - temp) >= 2:
        line += f", mehsoos {feels} jaisa ho raha hai"
    if high is not None and low is not None:
        line += f". Aaj ka high {high} aur low {low} degrees rahega"
    if humidity is not None:
        line += f", humidity {humidity} percent"
    return line + "."
