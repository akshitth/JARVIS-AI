"""
J.A.R.V.I.S. — App Control Skill
Open and close applications on Windows.

The intent parser hands over whatever the user actually said — "Chrome",
"browser", "that music app", "gaane wala app" — so resolution happens here in
three passes: exact alias, descriptive hint, then fuzzy token overlap.
"""

import os
import re
import shutil
import subprocess
import webbrowser

from config import APP_ALIASES, VAGUE_APP_HINTS


def _log(msg):
    print(msg, flush=True)


_FILLER = re.compile(
    r"\b(?:app|application|program|software|please|plz|jarvis|sir|now|abhi|"
    r"karo|kar|do|de|dena|zara|jara|the|a|an|my|mera|meri|that|this|wo|woh|"
    r"ye|yeh|koi|kuch|wala|wali)\b"
)


def _squash(name: str) -> str:
    """Reduce a spoken app reference to its content words."""
    name = _FILLER.sub(" ", (name or "").lower())
    return re.sub(r"[^a-z0-9\s]", " ", name).strip()


def resolve_app(app_name: str) -> tuple[str, str]:
    """Map a spoken app reference to (launch_target, display_label).

    "that music app" -> ("spotify", "Spotify"); "browser" -> ("chrome", "Chrome").
    """
    spoken = (app_name or "").lower().strip()

    # 1. Exact alias / hint hit on the raw phrase.
    if spoken in APP_ALIASES:
        target = APP_ALIASES[spoken]
        # "browser" -> "chrome": name the app we actually launch, not the noun.
        label = target.title() if target in APP_ALIASES else spoken.title()
        return target, label
    if spoken in VAGUE_APP_HINTS:
        canonical = VAGUE_APP_HINTS[spoken]
        return APP_ALIASES.get(canonical, canonical), canonical.title()

    # 2. Same, after stripping filler words ("open that music app please").
    squashed = _squash(spoken)
    if squashed in APP_ALIASES:
        return APP_ALIASES[squashed], squashed.title()
    if squashed in VAGUE_APP_HINTS:
        canonical = VAGUE_APP_HINTS[squashed]
        return APP_ALIASES.get(canonical, canonical), canonical.title()

    # 3. Descriptive phrases that merely CONTAIN a known hint or alias, longest
    #    key first so "youtube music" beats "music".
    haystack = squashed or spoken
    for table in (VAGUE_APP_HINTS, APP_ALIASES):
        for key in sorted(table, key=len, reverse=True):
            if len(key) < 3:
                continue
            if re.search(rf"\b{re.escape(key)}\b", haystack):
                canonical = table[key] if table is VAGUE_APP_HINTS else key
                target = APP_ALIASES.get(canonical, canonical)
                return target, canonical.title()

    # 4. Nothing known — try it verbatim as an executable name.
    fallback = squashed or spoken
    return fallback, (app_name or fallback).strip().title()


def open_app(app_name: str) -> tuple[bool, str]:
    """Open an application. Returns (succeeded, display_label)."""
    target, label = resolve_app(app_name)
    if not target:
        return False, (app_name or "that app")

    try:
        if target.startswith(("http://", "https://")):
            webbrowser.open(target)
            _log(f"[JARVIS][APP] Opened URL for {label}: {target}")
            return True, label

        if target.startswith("ms-settings:"):
            os.startfile(target)
            return True, "Settings"

        if "shell:" in target:
            subprocess.Popen(target, shell=True)
            _log(f"[JARVIS][APP] Launched shell target for {label}")
            return True, label

        # `shell=True` swallows a missing binary silently, so check first —
        # otherwise JARVIS cheerfully claims to have opened nothing.
        exe = target.split()[0]
        known = target in APP_ALIASES.values()
        if not known and shutil.which(exe) is None:
            _log(f"[JARVIS][APP] '{exe}' not found on PATH")
            return False, label

        subprocess.Popen(
            target, shell=True,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        _log(f"[JARVIS][APP] Launched {label} ({target})")
        return True, label

    except Exception as e:
        _log(f"[JARVIS][APP] Failed to open {label}: {e}")
        return False, label


# Process names for apps whose executable is not simply "<name>.exe".
_PROCESS_MAP = {
    "chrome": "chrome.exe",
    "google chrome": "chrome.exe",
    "browser": "chrome.exe",
    "firefox": "firefox.exe",
    "edge": "msedge.exe",
    "notepad": "notepad.exe",
    "spotify": "Spotify.exe",
    "word": "WINWORD.EXE",
    "excel": "EXCEL.EXE",
    "powerpoint": "POWERPNT.EXE",
    "discord": "Discord.exe",
    "telegram": "Telegram.exe",
    "whatsapp": "WhatsApp.exe",
    "vs code": "Code.exe",
    "vscode": "Code.exe",
    "visual studio code": "Code.exe",
    "code": "Code.exe",
    "calculator": "CalculatorApp.exe",
    "calc": "CalculatorApp.exe",
    "paint": "mspaint.exe",
    "mspaint": "mspaint.exe",
    "file explorer": "explorer.exe",
    "explorer": "explorer.exe",
    "task manager": "Taskmgr.exe",
    "taskmgr": "Taskmgr.exe",
    "terminal": "WindowsTerminal.exe",
    "cmd": "cmd.exe",
}


def close_app(app_name: str) -> tuple[bool, str]:
    """Close an application. Returns (was_running_and_killed, display_label)."""
    _target, label = resolve_app(app_name)
    key = label.lower()
    process_name = (
        _PROCESS_MAP.get(key)
        or _PROCESS_MAP.get((app_name or "").lower().strip())
        or f"{key.replace(' ', '')}.exe"
    )

    try:
        result = subprocess.run(
            ["taskkill", "/F", "/IM", process_name],
            capture_output=True, text=True,
        )
        # taskkill exits non-zero when nothing matched, which is exactly how we
        # tell "closed it" apart from "it wasn't running".
        killed = result.returncode == 0
        _log(f"[JARVIS][APP] taskkill {process_name} -> "
             f"{'closed' if killed else 'not running'}")
        return killed, label
    except Exception as e:
        _log(f"[JARVIS][APP] Failed to close {label}: {e}")
        return False, label
