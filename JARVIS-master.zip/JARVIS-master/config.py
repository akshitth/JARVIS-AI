"""
J.A.R.V.I.S. Configuration
Just A Rather Very Intelligent System
"""

import os
from dotenv import load_dotenv

# ─── Load .env file ──────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# override=True so a freshly edited .env key always wins over any stale value
# left in the system environment — drop a new GEMINI_API_KEY in .env, relaunch.
load_dotenv(os.path.join(BASE_DIR, ".env"), override=True)
ASSETS_DIR = os.path.join(BASE_DIR, "assets")
SOUNDS_DIR = os.path.join(ASSETS_DIR, "sounds")
ICONS_DIR = os.path.join(ASSETS_DIR, "icons")

# ─── Wake Words ──────────────────────────────────────
WAKE_WORDS = {
    "jarvis are you there": "Online and ready, sir. How can I assist?",
    "hey jarvis": "Yes sir, I'm listening.",
    "daddy's home": "Welcome back, sir. I've been keeping things warm. All systems nominal.",
    "daddys home": "Welcome back, sir. I've been keeping things warm. All systems nominal.",
    "daddy is home": "Welcome back, sir. I've been keeping things warm. All systems nominal.",
}

# ─── Sleep Commands ──────────────────────────────────
SLEEP_COMMANDS = [
    "jarvis standby",
    "jarvis stand by",
    "that'll be all jarvis",
    "that will be all jarvis",
    "that'll be all",
    "go to sleep",
    "standby",
]

# ─── Inactivity Timeout ─────────────────────────────
# ACTIVE -> STANDBY after this many seconds with no command.
# Minimum 30s so JARVIS doesn't drop to standby while you're thinking/talking.
INACTIVITY_TIMEOUT_SECONDS = 30

# ─── Vision Auto-Off ────────────────────────────────
# Camera turns off automatically after this many seconds with no gesture/command.
VISION_AUTO_OFF_SECONDS = 30

# ─── TTS Configuration ──────────────────────────────
# Coqui TTS - Primary (offline)
COQUI_MODEL = "tts_models/en/vctk/vits"
COQUI_SPEAKER = "p267"  # British male speaker

# Edge TTS - Fallback
EDGE_TTS_VOICE = "en-GB-RyanNeural"

# ─── TTS Voice ──────────────────────────────────────
# English keeps the British voice — that one was already right and is left
# untouched.
EDGE_TTS_VOICE_EN = "en-GB-RyanNeural"

# Hinglish lines get an Indian-accented voice, because Ryan mispronounces Hindi
# words badly enough to be hard to follow. Prabhat is deliberately chosen over
# hi-IN-MadhurNeural: it is an ENGLISH-engine voice with an Indian accent, so it
# says "kitne baje hain" naturally while staying close enough to Ryan in timbre
# that the switch is not jarring. Madhur is more natural on pure Hindi but
# sounds like a completely different person.
#   Alternatives to try:  hi-IN-MadhurNeural (most natural Hindi, biggest jump)
#                         en-US-BrianMultilingualNeural (smooth, American accent)
# Run `python preview_voices.py` to hear them side by side.
EDGE_TTS_VOICE_HI = "en-IN-PrabhatNeural"

# True  = pick the voice per response (English -> Ryan, Hinglish -> Prabhat).
# False = one voice throughout; EDGE_TTS_VOICE_HI is then used ONLY for text in
#         Devanagari script, which an English voice cannot pronounce at all.
TTS_AUTO_SWITCH_VOICE = True

# ─── Whisper Configuration (faster-whisper / CTranslate2) ────
# TWO models, picked by what JARVIS is listening FOR rather than by the audio.
#
# In STANDBY the only question is "was that a wake word?", which fuzzy matching
# already forgives -- so the fast model keeps waking instant (measured 679ms vs
# 2865ms per clip; "small" made every "Hey JARVIS" feel sluggish).
#
# Once ACTIVE, the exact Hindi words matter, and "small" scored 21/21 correct
# intents on synthesized Hinglish commands against "base"'s 17/21 ("PC lock kar
# do" came out of base as "Shilok kar go"). Accuracy wins there; the extra ~2s
# is cheaper than a command that simply does not work.
WHISPER_MODEL_WAKE = "base"       # listening for a wake word — speed wins
WHISPER_MODEL_COMMAND = "small"   # listening to a command — accuracy wins
WHISPER_MODEL = WHISPER_MODEL_COMMAND
WHISPER_DEVICE = "cpu"          # "cpu" or "cuda" if a GPU is available
WHISPER_COMPUTE_TYPE = "int8"   # int8 = fastest on CPU; "float16" for GPU
# 0 = use every logical core. Measured 2698ms vs 3279ms per command on 8 cores.
WHISPER_CPU_THREADS = 0
# Forced to English rather than auto-detect, which is counter-intuitive but
# measured: auto-detect flips to Hindi on Hinglish and returns DEVANAGARI
# ("time kya hua" -> "अई क्या हूँ?"), which no downstream parser can read.
# Decoding as English yields romanized Hinglish -- exactly what JARVIS wants.
WHISPER_LANGUAGE = "en"

# ─── Gemini API ──────────────────────────────────────
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
# gemini-2.5-flash: multimodal (text + vision) and available on the free tier.
# NOTE: gemini-2.0-flash has a free-tier quota of 0 on this key (always 429),
# so we use 2.5-flash for both chat and vision. See skills/vision.py fallback.
GEMINI_MODEL = "gemini-2.5-flash"

# ─── Intent Parsing Model ───────────────────────────
# The intent parser only has to emit ~40 tokens of JSON, so it runs on the
# FASTEST available model with thinking disabled (~1.3s round trip).
# NOTE: gemini-2.0-flash (the originally specified model) has been RETIRED by
# Google and now returns 404 on this key, so flash-lite is the fast tier.
INTENT_MODEL = "gemini-2.5-flash-lite"
INTENT_FALLBACK_MODELS = ["gemini-2.5-flash", "gemini-flash-latest"]
INTENT_MAX_TOKENS = 100
# Below this confidence the local pattern matcher gets a second opinion.
INTENT_MIN_CONFIDENCE = 0.4
# Hard ceiling on the intent call; past this we use the offline parser instead
# of leaving the user waiting.
INTENT_TIMEOUT_SECONDS = 6.0

# ─── Follow-up Conversation Window ──────────────────
# After JARVIS answers, it keeps listening for this long so you can ask a
# follow-up WITHOUT repeating the wake word (Google-Assistant style).
FOLLOW_UP_WINDOW_SECONDS = 15

# ─── Memory / Profile files ─────────────────────────
MEMORY_FILE = os.path.join(BASE_DIR, "memory.json")
PROFILE_FILE = os.path.join(BASE_DIR, "profile.json")
# How many past turns of the current session JARVIS keeps for context
# ("tell me more about that", "what did I just ask").
CONTEXT_TURNS = 5

# ─── Default User Profile ───────────────────────────
# Written to profile.json on first run; edit that file, not this.
DEFAULT_PROFILE = {
    "name": "Yatharth",
    "nickname": "Sir",
    "language": "Hinglish",
    "location": "Noida",
    "timezone": "Asia/Kolkata",
}

# ─── Risky actions that need spoken confirmation ────
CONFIRM_INTENTS = {"lock_pc", "shutdown", "restart", "delete"}

# ─── Intent parser system prompt (Gemini) ───────────
INTENT_SYSTEM_PROMPT = """You are the intent parser for JARVIS AI assistant. Your job is to understand what the user wants and return ONLY a JSON response. Never return anything else.

Available intents:

open_app: user wants to open an application. Extract app name.
close_app: user wants to close an application. Extract app name.
time: user wants to know the current time.
date: user wants to know today's date.
system_info: user wants CPU, RAM, battery, disk info. Extract info type.
lock_pc: user wants to lock the computer.
shutdown: user wants to shut down the PC.
restart: user wants to restart the PC.
play_music: user wants to play music.
web_search: user wants to search something. Extract query.
set_reminder: user wants a reminder. Extract time and message.
volume_control: user wants volume up/down/mute. Extract action.
screenshot: user wants a screenshot.
remember: user wants JARVIS to remember something. Extract what.
recall: user wants JARVIS to recall a memory. Extract what.
forget: user wants JARVIS to forget something. Extract what.
vision_on: user wants to activate camera/vision.
vision_off: user wants to deactivate camera/vision.
vision_describe: user wants JARVIS to describe what it sees.
easter_egg_ironman: user says anything related to 'I am Iron Man'.
morning_briefing: user wants a daily briefing or says good morning.
change_mic: user wants to change microphone.
recalibrate: user wants to recalibrate mic sensitivity.
general_question: user is asking a general knowledge question. Extract the full question.
small_talk: user is making casual conversation or joke request.
unknown: cannot determine intent.

User speaks in English, Hindi, or Hinglish (Hindi written in English script).

RESPOND ONLY IN THIS JSON FORMAT:
{"intent": "intent_name", "params": {"key": "value"}, "confidence": 0.95}

Examples:
"Chrome khol do" -> {"intent": "open_app", "params": {"app": "Chrome"}, "confidence": 0.95}
"bhai kitne baje hain" -> {"intent": "time", "params": {}, "confidence": 0.9}
"PC band kar do" -> {"intent": "shutdown", "params": {}, "confidence": 0.9}
"kuch music laga do" -> {"intent": "play_music", "params": {}, "confidence": 0.85}
"system kaisa chal raha hai" -> {"intent": "system_info", "params": {"type": "all"}, "confidence": 0.85}
"yaad rakh mera meeting 5 baje hai" -> {"intent": "remember", "params": {"what": "meeting at 5pm"}, "confidence": 0.9}
"mujhe dekh" -> {"intent": "vision_on", "params": {}, "confidence": 0.9}
"lock kar de sab" -> {"intent": "lock_pc", "params": {}, "confidence": 0.9}"""

# ─── Response personality system prompt (Gemini) ────
# Reply in the language the user just spoke: English stays English (and gets
# the English voice), Hindi or Hinglish gets Hinglish. A fixed "speak Hinglish"
# rule made every English question come back in Hinglish, in the Hindi voice.
RESPONSE_SYSTEM_PROMPT = """You are JARVIS, Tony Stark's AI assistant. Reply in the SAME language the user just used: plain English if they spoke English, Hinglish (Hindi-English mix written in English script) if they spoke Hindi or Hinglish. You are formal, respectful, slightly witty. Always address the user as 'Sir'. Keep responses short and crisp (1-2 sentences max). Never break character."""

# ─── App Aliases (for opening apps) ─────────────────
APP_ALIASES = {
    "chrome": "chrome",
    "google chrome": "chrome",
    "browser": "chrome",
    "notepad": "notepad",
    "calculator": "calc",
    "calc": "calc",
    "file explorer": "explorer",
    "explorer": "explorer",
    "spotify": "spotify",
    "word": "winword",
    "excel": "excel",
    "powerpoint": "powerpnt",
    "task manager": "taskmgr",
    "command prompt": "cmd",
    "cmd": "cmd",
    "terminal": "wt",
    "settings": "ms-settings:",
    "paint": "mspaint",
    "vs code": "code",
    "vscode": "code",
    "visual studio code": "code",
    "discord": "discord",
    "telegram": "telegram",
    "whatsapp": r"explorer shell:AppsFolder\5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App",
    "youtube": "https://youtube.com",
    "youtube music": "https://music.youtube.com",
    "gmail": "https://mail.google.com",
    "github": "https://github.com",
}

# ─── Vague / descriptive app references ─────────────
# "open that music app", "koi browser khol do", "wo editing wala app" — the user
# rarely names the exact binary, so descriptions resolve to a sensible default.
VAGUE_APP_HINTS = {
    "music app": "spotify",
    "music player": "spotify",
    "that music app": "spotify",
    "wo music app": "spotify",
    "gaane wala app": "spotify",
    "gana app": "spotify",
    "song app": "spotify",
    "browser": "chrome",
    "web browser": "chrome",
    "internet": "chrome",
    "net": "chrome",
    "code editor": "vs code",
    "editor": "vs code",
    "coding app": "vs code",
    "text editor": "notepad",
    "notes": "notepad",
    "notes app": "notepad",
    "files": "file explorer",
    "folder": "file explorer",
    "my files": "file explorer",
    "chat app": "whatsapp",
    "messaging app": "whatsapp",
    "video app": "youtube",
    "video wala app": "youtube",
    "mail": "gmail",
    "email": "gmail",
    "calculator app": "calculator",
    "terminal app": "terminal",
}

# ─── Weather (Open-Meteo — free, keyless) ───────────
WEATHER_LAT = 28.5355     # Noida
WEATHER_LON = 77.3910
WEATHER_TIMEOUT = 5

# ─── UI Configuration ───────────────────────────────
HUD_WIDTH = 420
HUD_HEIGHT = 320
HUD_OPACITY = 0.92

# ─── Compact / Standby Mode ─────────────────────
COMPACT_WIDTH = 140
COMPACT_HEIGHT = 140
AUTO_COMPACT_SECONDS = 10  # Shrink UI after 10s inactivity (stays listening)
