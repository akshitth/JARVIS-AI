"""
J.A.R.V.I.S. — Just A Rather Very Intelligent System
Main entry point. Orchestrates all subsystems.

Usage:
    python -u main.py
"""

import sys
import os
import queue
import time
import threading

# Force unbuffered output on Windows
os.environ["PYTHONUNBUFFERED"] = "1"

# Add project root to path
_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _PROJECT_ROOT)

# Load .env file BEFORE any config imports
from dotenv import load_dotenv
# override=True so an edited .env key is picked up on next launch even if a
# stale GEMINI_API_KEY lingers in the system environment.
load_dotenv(os.path.join(_PROJECT_ROOT, ".env"), override=True)


def log(msg):
    """Print with flush for Windows console."""
    print(msg, flush=True)


from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QTimer, Qt, QThread, pyqtSignal, QObject

from config import (
    WHISPER_MODEL, INACTIVITY_TIMEOUT_SECONDS, AUTO_COMPACT_SECONDS,
    VISION_AUTO_OFF_SECONDS, FOLLOW_UP_WINDOW_SECONDS,
)
from core.listener import Listener, preload_whisper
from core.state_machine import StateMachine, State
from core.speaker import Speaker, speak
from core import fast_path
from core.dispatcher import Dispatcher, Services
from core.memory_store import MemoryStore, Profile, ConversationContext
from core.pipeline import Pipeline
from skills.reminders import ReminderManager
from skills.gemini_ai import is_gemini_available
from skills.lock_pc import execute_lock
from skills.small_talk import handle_small_talk
from skills.vision import VisionSystem
from ui.hud_widget import HudWidget
from ui.system_tray import JarvisTray
from ui.camera_preview import CameraPreview


class JarvisBridge(QObject):
    """
    Bridge between background threads and the Qt UI.
    Emits signals to safely update the UI from worker threads.
    """
    # Signals for UI updates
    wake_up_signal = pyqtSignal(str, bool)  # response_text, is_daddy_home
    sleep_signal = pyqtSignal()
    command_signal = pyqtSignal(str)        # user command text
    response_signal = pyqtSignal(str)       # JARVIS response text
    state_signal = pyqtSignal(str)          # transient HUD visual: "processing"
    state_machine_signal = pyqtSignal(str)  # authoritative state: STANDBY/ACTIVE/SPEAKING
    online_signal = pyqtSignal(bool)        # Gemini API availability
    iron_man_signal = pyqtSignal()          # Easter egg: I Am Iron Man HUD effect
    vision_event_signal = pyqtSignal(str, str)  # vision events: (event_type, payload)
    mic_level_signal = pyqtSignal(float, float)  # live mic level: (rms, threshold)
    ptt_signal = pyqtSignal(str)            # push-to-talk transcribed command
    mic_change_signal = pyqtSignal(str, str)  # mic hot-swap: (kind, device name)


class JarvisAssistant:
    """Main JARVIS orchestrator."""

    def __init__(self):
        self.last_activity_time = 0

        # Communication queue from listener
        self.text_queue = queue.Queue()

        # Bridge for thread-safe UI updates
        self.bridge = JarvisBridge()

        # ── State machine (authoritative): STANDBY / ACTIVE / SPEAKING ──
        self.state_machine = StateMachine(on_change=self._on_state_transition)
        # Whether JARVIS should return to ACTIVE (vs STANDBY) once it stops
        # speaking. Set True on wake, False on sleep/inactivity.
        self._wake_intent = False

        # ── Vision system (camera OFF by default, only on by command) ──
        self.vision = VisionSystem(event_callback=self._on_vision_event)
        # Last gesture/command while vision is on — drives the 30s auto-off.
        self._vision_last_activity = 0.0

        # Shared lock held while JARVIS speaks — the listener discards ALL audio
        # whenever it is locked, preventing the self-talk feedback loop.
        self.speaking_lock = threading.Lock()

        # Automatic mic selection: headset (BT/wired/USB) if connected and
        # openable, else the laptop mic. No prompt — one log line says which.
        try:
            from core.mic_select import auto_select_microphone
            self._mic_index, _, _ = auto_select_microphone()
        except Exception as e:
            log(f"[JARVIS] Mic auto-select failed ({e}); using default.")
            self._mic_index = None

        # Listener (STT) — level_callback feeds the live HUD mic indicator.
        # speaking_lock + state_is_speaking let it go fully silent during TTS.
        # ptt_result_callback delivers push-to-talk commands (auto-wake).
        # device_change_callback announces automatic headset hot-swaps.
        self.listener = Listener(
            whisper_model_name=WHISPER_MODEL,
            result_queue=self.text_queue,
            level_callback=self._on_mic_level,
            speaking_lock=self.speaking_lock,
            state_is_speaking=lambda: self.state_machine.is_speaking(),
            device_index=self._mic_index,
            ptt_result_callback=self._on_ptt_text,
            device_change_callback=self._on_mic_device_change,
        )

        # Speaker (TTS) — shares the same speaking_lock as the listener.
        self.speaker = Speaker()
        self.speaker.speaking_lock = self.speaking_lock
        self.speaker.on_start = self._on_speaker_start
        self.speaker.on_done = self._on_speaker_done

        # Reminder manager
        self.reminder_manager = ReminderManager(speak_callback=self._reminder_speak)

        # ── Memory: persistent facts, user profile, session context ──
        self.memory = MemoryStore()
        self.profile = Profile()
        self.context = ConversationContext()

        # ── Command processing: intent parsing -> local execution ──
        # Everything the dispatcher is allowed to touch is declared here, so
        # what a command can and cannot do is visible in one place.
        self.services = Services(
            memory=self.memory,
            profile=self.profile,
            context=self.context,
            vision=self.vision,
            listener=self.listener,
            reminders=self.reminder_manager,
            progress=lambda text: self.bridge.response_signal.emit(text),
            iron_man_effect=lambda: self.bridge.iron_man_signal.emit(),
        )
        self.dispatcher = Dispatcher(self.services)
        self.pipeline = Pipeline(
            self.dispatcher,
            memory=self.memory,
            profile=self.profile,
            context=self.context,
            log_fn=log,
        )

        # Follow-up window: for this many seconds after JARVIS answers, a new
        # command is accepted WITHOUT the wake word (Google-Assistant style).
        self._follow_up_until = 0.0

        # UI
        self.app = None
        self.hud = None
        self.tray = None

        # Auto-compact timer (separate from inactivity standby)
        self._auto_compact_timer = None

        # Anti-feedback loop protection
        self._command_cooldown_until = 0
        self._last_command_text = ""
        self._last_command_time = 0

    @property
    def is_awake(self) -> bool:
        """JARVIS is 'awake' in any non-standby state (ACTIVE or SPEAKING)."""
        return not self.state_machine.is_standby()

    def _in_user_language(self, hinglish: str, english: str) -> str:
        """Lines JARVIS says on its own (standby, errors) follow the language
        the user was last speaking, the same way command replies do."""
        return english if self.dispatcher.language == "en" else hinglish

    def _on_state_transition(self, old_state, new_state):
        """State machine callback (may run on any thread) — notify the UI safely."""
        # STANDBY only needs to spot a wake word, so it transcribes with the fast
        # model; ACTIVE needs the exact Hindi words and uses the accurate one.
        # Both stay loaded, so this is just a pointer swap.
        try:
            self.listener.set_awake(new_state.value != "STANDBY")
        except Exception:
            pass
        self.bridge.state_machine_signal.emit(new_state.value)

    def _apply_state_visuals(self, state_name: str):
        """Update HUD visuals for the authoritative state (runs on main thread)."""
        if state_name == "STANDBY":
            self.hud.set_state_standby()
        elif state_name == "ACTIVE":
            self.hud.set_state_listening()
        elif state_name == "SPEAKING":
            self.hud.set_state_speaking()

    def _on_vision_event(self, event_type: str, payload: str):
        """Vision callback (runs on the camera thread) — hop to the UI thread."""
        self.bridge.vision_event_signal.emit(event_type, payload)

    def _on_mic_level(self, rms: float, threshold: float):
        """Listener callback (runs on the mic thread) — hop to the UI thread to
        update the live mic-level indicator on the HUD."""
        self.bridge.mic_level_signal.emit(rms, threshold)

    def _on_ptt_text(self, text: str):
        """Push-to-talk result (runs on the mic thread) — hop to the UI thread."""
        self.bridge.ptt_signal.emit(text)

    def _on_mic_device_change(self, kind: str, name: str):
        """Mic hot-swap (runs on the mic thread) — hop to the UI thread."""
        self.bridge.mic_change_signal.emit(kind, name)

    def _handle_mic_change(self, kind: str, name: str):
        """Announce an automatic (or manual) microphone switch. UI thread."""
        if kind == "headset":
            msg = "Aapke headset par switch kar raha hoon, Sir."
        elif kind == "internal":
            msg = "Headset disconnect ho gaya, internal microphone par switch kar raha hoon, Sir."
        else:
            msg = "Microphone switch kar diya, Sir."
        log(f"[JARVIS] MIC CHANGE ({kind}): {name}")
        self.bridge.response_signal.emit(msg)
        self.speaker.say(msg)

    def _handle_ptt_command(self, text: str):
        """A push-to-talk command — runs on the UI thread. Auto-wakes JARVIS so
        you don't need the wake word when you deliberately hold Ctrl+Space."""
        log(f"[JARVIS] PUSH-TO-TALK command: '{text}'")
        if not self.is_awake:
            self._wake_intent = True
            self.last_activity_time = time.time()
            self.state_machine.to(State.ACTIVE, "push-to-talk")
            if self.hud.is_compact():
                self.hud.expand_to_full()
        self._process_text(text)

    def _start_hotkeys(self):
        """Global keyboard shortcuts (run on pynput's own thread):
          * Ctrl+Space held  -> push-to-talk (listen only while held)
          * F5               -> recalibrate ambient noise
        Callbacks only set thread-safe flags on the listener, so they're safe."""
        try:
            from pynput import keyboard
        except Exception as e:
            log(f"[JARVIS] Hotkeys unavailable ({e}); push-to-talk disabled.")
            return

        self._keys_down = set()
        _CTRLS = {keyboard.Key.ctrl_l, keyboard.Key.ctrl_r}

        def on_press(key):
            self._keys_down.add(key)
            if key == keyboard.Key.f5:
                self.listener.recalibrate()
            if keyboard.Key.space in self._keys_down and (self._keys_down & _CTRLS):
                self.listener.ptt_start()

        def on_release(key):
            self._keys_down.discard(key)
            if key == keyboard.Key.space or key in _CTRLS:
                self.listener.ptt_stop()

        try:
            self._hotkey_listener = keyboard.Listener(on_press=on_press, on_release=on_release)
            self._hotkey_listener.daemon = True
            self._hotkey_listener.start()
            log("[JARVIS] Hotkeys ready: Ctrl+Space = push-to-talk, F5 = recalibrate")
        except Exception as e:
            log(f"[JARVIS] Could not start hotkey listener: {e}")

    def _update_preview(self):
        """Show/update the camera preview while vision is on; hide it when off."""
        if self.vision.is_running():
            # Open the window the INSTANT vision is running — don't wait for the
            # first annotated frame (if that were ever None, the window would
            # never appear). It shows a 'Vision starting…' placeholder until the
            # first frame arrives a fraction of a second later.
            if not self.preview.isVisible():
                self.preview.show_preview()
                log("[JARVIS] Camera preview window OPENED (320x240, top-most)")
            frame = self.vision.get_preview_frame()
            if frame is not None:
                self.preview.update_frame(frame)
        elif self.preview.isVisible():
            self.preview.hide()
            log("[JARVIS] Camera preview window CLOSED")

    # Spoken responses for face events.
    _VISION_SPEECH = {
        "enrolled": None,  # uses the payload message verbatim
        "face_owner": "I see you sir. Good to see you.",
        "face_unknown": "Sir, there's someone here I don't recognize. Should I be concerned?",
        "face_multiple": "Sir, I'm detecting multiple individuals in the room.",
    }

    def _handle_vision_event(self, event_type: str, payload: str):
        """Act on a vision event. ALWAYS runs on the main (UI) thread because it
        is invoked via the queued vision_event_signal, so it can safely touch
        the speaker/HUD even though the gesture was detected on the camera thread.
        """
        now = time.time()
        self.last_activity_time = now
        # Gestures (and commands) keep the camera alive; face sightings do not.
        if event_type.startswith("gesture_"):
            self._vision_last_activity = now

        # Gesture: open palm -> deactivate vision (camera off, keep listening)
        if event_type == "gesture_open_palm":
            log("[JARVIS] GESTURE ACTION: open_palm -> vision_off EXECUTING")
            msg = "Vision deactivate kar raha hoon, Sir."
            self.bridge.response_signal.emit(msg)
            self.speaker.say(msg)
            self.vision.stop()          # preview auto-hides via _update_preview
            log("[JARVIS] VISION OFF ACTION EXECUTED")
            return

        # Gesture: fist -> lock the PC, then go to standby + camera off.
        if event_type == "gesture_fist":
            log("[JARVIS] GESTURE ACTION: fist -> lock_pc EXECUTING")
            msg = "Workstation secure kar raha hoon, Sir. Lock kar deta hoon."
            self.bridge.response_signal.emit(msg)
            self.speaker.say(msg)
            self._wake_intent = False
            self.bridge.sleep_signal.emit()     # _on_sleep stops vision + standby

            def _do_lock():
                log("[JARVIS] LOCK ACTION EXECUTED")
                execute_lock()
            QTimer.singleShot(2500, _do_lock)
            return

        # Gesture: peace -> tell a joke
        if event_type == "gesture_peace":
            log("[JARVIS] GESTURE ACTION: peace -> joke EXECUTING")
            joke = handle_small_talk("tell me a joke")
            self.bridge.response_signal.emit(joke)
            self.speaker.say(joke)
            log("[JARVIS] JOKE ACTION EXECUTED")
            return

        # Gesture: thumbs up -> acknowledge
        if event_type == "gesture_thumbs_up":
            log("[JARVIS] GESTURE ACTION: thumbs_up -> understood EXECUTING")
            self.bridge.response_signal.emit("Understood sir.")
            self.speaker.say("Understood sir.")
            log("[JARVIS] UNDERSTOOD ACTION EXECUTED")
            return

        # Face events: a simple spoken line.
        if event_type == "enrolled":
            text = payload or "I've registered your face, sir."
        else:
            text = self._VISION_SPEECH.get(event_type)
        if text:
            self.bridge.response_signal.emit(text)
            self.speaker.say(text)

    def _reminder_speak(self, text: str):
        """Called when a reminder fires."""
        self.bridge.response_signal.emit(text)
        self.speaker.say(text)
        self.last_activity_time = time.time()

    def _on_speaker_start(self):
        """SPEAKING: physically STOP the mic stream the instant JARVIS talks."""
        self.listener.hard_stop_mic()   # logs 'MIC HARD STOPPED — JARVIS speaking'
        self.state_machine.to(State.SPEAKING, "TTS started")

    def _on_speaker_done(self):
        """TTS finished: return to ACTIVE (if awake) or STANDBY, then restart the
        mic stream 2s AFTER speech fully ends (with a buffer flush)."""
        target = State.ACTIVE if self._wake_intent else State.STANDBY
        self.state_machine.to(target, "TTS finished")

        def _delayed_restart():
            time.sleep(1.0)                  # 1 second AFTER TTS done (snappier)
            if not self.speaker.is_speaking:
                self.listener.hard_restart_mic()  # flush + restart + log
        threading.Thread(target=_delayed_restart, daemon=True).start()

    def start(self):
        """Start all JARVIS subsystems."""
        log("[JARVIS] Initializing Qt application...")

        # Preload BOTH speech models in the background NOW, in parallel with UI
        # setup, so neither the first wake word nor the first command pays a load
        # stall. They are cached by name and reused for every transcription.
        log("[JARVIS] Preloading speech models in background...")
        threading.Thread(target=preload_whisper, daemon=True).start()

        # Start Qt app
        self.app = QApplication(sys.argv)
        self.app.setQuitOnLastWindowClosed(False)

        # Global exception hook for Qt threads
        def _exception_hook(exc_type, exc_value, exc_tb):
            import traceback
            log("[JARVIS] UNCAUGHT EXCEPTION:")
            traceback.print_exception(exc_type, exc_value, exc_tb)
        sys.excepthook = _exception_hook

        log("[JARVIS] Creating HUD widget...")

        # Create HUD
        self.hud = HudWidget()
        self.hud.close_requested.connect(self._quit)
        self.hud.minimize_requested.connect(self._on_minimize_clicked)
        self.hud.compact_clicked.connect(self._on_compact_clicked)

        # Connect bridge signals to UI
        self.bridge.wake_up_signal.connect(self._on_wake_up)
        self.bridge.sleep_signal.connect(self._on_sleep)
        self.bridge.command_signal.connect(self._on_command)
        self.bridge.response_signal.connect(self._on_response)
        self.bridge.state_signal.connect(self._on_state_change)
        self.bridge.state_machine_signal.connect(self._apply_state_visuals)
        self.bridge.online_signal.connect(self._on_online_status)
        self.bridge.iron_man_signal.connect(self._on_iron_man_effect)
        self.bridge.vision_event_signal.connect(self._handle_vision_event)
        self.bridge.mic_level_signal.connect(self.hud.set_mic_level)
        self.bridge.ptt_signal.connect(self._handle_ptt_command)
        self.bridge.mic_change_signal.connect(self._handle_mic_change)

        log("[JARVIS] Setting up system tray...")

        # System tray
        self.tray = JarvisTray(
            self.hud,
            on_show=self._on_compact_clicked,
            on_quit=self._quit,
        )
        self.tray.show()

        # Camera preview window (hidden until vision is active)
        self.preview = CameraPreview()

        # Show HUD in compact standby mode
        self.hud.set_state_standby()
        self.hud.animate_in()

        log("[JARVIS] Starting listener thread...")

        # Start background threads
        self.listener.start()
        self.speaker.start()

        # ── TTS self-test: report engine health and SPEAK a boot line so the
        # user can immediately confirm voice output is working (req: audible
        # 'All systems online, sir'). If they hear it, TTS + audio are good.
        from core.speaker import report_tts_status
        status = report_tts_status()
        if status != "OK":
            log("[JARVIS] WARNING: TTS reported FAILED — responses may be text-only")
        self.speaker.boot_test()   # says "All systems online, sir."

        # Global hotkeys: Ctrl+Space (push-to-talk), F5 (recalibrate)
        self._start_hotkeys()

        log("[JARVIS] Starting speaker thread...")

        # Poll for transcribed text
        self._poll_timer = QTimer()
        self._poll_timer.timeout.connect(self._poll_text_queue)
        self._poll_timer.start(100)  # Check every 100ms

        # Inactivity check: ACTIVE -> STANDBY after INACTIVITY_TIMEOUT_SECONDS
        self._inactivity_timer = QTimer()
        self._inactivity_timer.timeout.connect(self._check_inactivity)
        self._inactivity_timer.start(1000)  # Check every second

        # Auto-compact timer kept for HUD bookkeeping; no longer shrinks while
        # ACTIVE (standby at 10s supersedes it — see _start_auto_compact).
        self._auto_compact_timer = QTimer()
        self._auto_compact_timer.setSingleShot(True)
        self._auto_compact_timer.timeout.connect(self._auto_compact)

        # Heartbeat: print the current state every 3s so it is always visible.
        # Quiet "still alive" tick. State CHANGES print immediately on their own,
        # so this is infrequent to keep the important lines easy to read.
        self._state_heartbeat_timer = QTimer()
        self._state_heartbeat_timer.timeout.connect(self.state_machine.heartbeat)
        self._state_heartbeat_timer.start(15000)

        # Camera preview pump: shows/updates the preview while vision is on,
        # hides it when vision turns off. Decoupled from the camera thread.
        self._preview_timer = QTimer()
        self._preview_timer.timeout.connect(self._update_preview)
        self._preview_timer.start(60)  # ~16 fps

        # Gemini API status check
        self._api_check_timer = QTimer()
        self._api_check_timer.timeout.connect(self._check_api_status)
        self._api_check_timer.start(30000)  # Check every 30 seconds
        # Initial check
        self._check_api_status()

        log("[JARVIS] ========================================")
        log("[JARVIS] All systems online!")
        log("[JARVIS] Waiting for wake word...")
        log("[JARVIS] Say 'Hey JARVIS' to activate")
        log("[JARVIS] ========================================")

        # Run event loop
        sys.exit(self.app.exec())

    def _poll_text_queue(self):
        """Check for new transcribed text from the listener."""
        while not self.text_queue.empty():
            try:
                text = self.text_queue.get_nowait()
                self._process_text(text)
            except queue.Empty:
                break

    def _process_text(self, text: str):
        """Process a piece of transcribed text (runs on the UI thread).

        Only the OFFLINE fast path runs here — wake words and standby commands
        are time-sensitive and must never wait on the network. Everything else
        is handed to the pipeline on a background thread.
        """
        log(f"[JARVIS][HEARD] >>> '{text}'   (state={self.state_machine.state.value})")

        # Anti-feedback: cooldown lock — ignore all input for 2s after a command
        if time.time() < self._command_cooldown_until:
            log(f"[JARVIS] Ignoring input (cooldown active): '{text}'")
            return

        # ── Offline fast path (< 0.1s, no API call) ──
        hit = fast_path.check(text, awake=self.is_awake)

        if hit is not None and hit.kind == fast_path.WAKE:
            log(f"[JARVIS] Wake word detected in {hit.elapsed_ms:.2f}ms (offline)")
            self.bridge.wake_up_signal.emit(hit.response, hit.daddy_home)
            return

        if hit is not None and hit.kind == fast_path.SLEEP and self.is_awake:
            log(f"[JARVIS] Standby command detected in {hit.elapsed_ms:.2f}ms (offline)")
            self._follow_up_until = 0.0
            self.dispatcher.clear_pending()
            self.speaker.say(hit.response)
            self.bridge.response_signal.emit(hit.response)
            self.bridge.sleep_signal.emit()
            return

        # ── Standby: only a follow-up or an easter egg gets through ──
        if not self.is_awake:
            following_up = time.time() < self._follow_up_until
            if following_up:
                remaining = self._follow_up_until - time.time()
                log(f"[JARVIS] Follow-up window open ({remaining:.0f}s left) "
                    f"-> accepting without the wake word")
            elif hit is not None and hit.kind == fast_path.EASTER_EGG:
                log("[JARVIS] Easter egg heard while in standby -> waking up")
            else:
                log("[JARVIS] (standby - not a wake word)")
                return
            self._wake_intent = True
            self.state_machine.to(State.ACTIVE, "follow-up conversation")

        # Anti-feedback: duplicate filter — ignore same command within 5s.
        # "yes"/"haan" is exempt: confirming two risky actions in a row is a
        # legitimate repeat, not the microphone hearing itself.
        text_normalized = text.strip().lower()
        if (text_normalized == self._last_command_text
                and time.time() - self._last_command_time < 5.0
                and not self.dispatcher.awaiting_confirmation):
            log(f"[JARVIS] Ignoring duplicate command: '{text}'")
            return
        self._last_command_text = text_normalized
        self._last_command_time = time.time()

        # Update activity
        self.last_activity_time = time.time()

        # Cancel auto-compact timer — user is active
        self._auto_compact_timer.stop()

        # If HUD is compact, expand it (user gave a command while listening)
        if self.hud.is_compact():
            self.hud.expand_to_full()

        # Show the command
        self.bridge.command_signal.emit(text)
        self.bridge.state_signal.emit("processing")

        # Pause listener while processing to avoid feedback
        self.listener.pause()

        # Intent parsing may take ~1s over the network — never on the UI thread.
        threading.Thread(
            target=self._execute_command,
            args=(text,),
            daemon=True,
        ).start()

    def _execute_command(self, text: str):
        """Run one utterance through the pipeline (background thread).

        Intent parsing (Gemini) -> local execution -> speak. The pipeline logs
        the HEARD/INTENT/ACTION line itself.
        """
        try:
            # Any spoken command counts as activity for the vision auto-off timer.
            if self.vision.is_running():
                self._vision_last_activity = time.time()

            outcome = self.pipeline.handle(text, awake=True)

            if outcome.kind == "ignored" or not outcome.speech:
                log("[JARVIS] Nothing to say for that input.")
                return

            self.bridge.response_signal.emit(outcome.speech)
            self.speaker.say(outcome.speech)

            # Lock/shutdown/restart leave nobody at the keyboard, so there is no
            # follow-up to wait for -- holding the mic open would mean listening
            # from behind a lock screen. Land in STANDBY instead.
            if outcome.sleep_after:
                self._follow_up_until = 0.0
                self._wake_intent = False
                log("[JARVIS] Terminal action -> standby once the reply is done.")
            else:
                # Keep the conversation open so a follow-up needs no wake word.
                self._follow_up_until = time.time() + FOLLOW_UP_WINDOW_SECONDS
                if outcome.awaiting:
                    log(f"[JARVIS] Awaiting {outcome.awaiting} from you, sir.")
                else:
                    log(f"[JARVIS] Follow-up window open for "
                        f"{FOLLOW_UP_WINDOW_SECONDS}s — no wake word needed.")

            # Locking or shutting down mid-sentence would cut JARVIS off, so the
            # action waits until the response has actually been spoken.
            if outcome.after_speaking is not None:
                while self.speaker.is_speaking:
                    time.sleep(0.1)
                time.sleep(2)
                log(f"[JARVIS] Executing deferred action: {outcome.action}")
                outcome.after_speaking()

            # Vision must not keep running behind a lock screen either.
            if outcome.sleep_after:
                self.bridge.sleep_signal.emit()

        except Exception as e:
            log(f"[JARVIS] Pipeline error: {e}")
            import traceback
            traceback.print_exc()
            message = self._in_user_language(
                "Command process karte waqt error aa gaya, Sir.",
                "Something went wrong while processing that command, Sir.")
            self.bridge.response_signal.emit(message)
            self.speaker.say(message)
        finally:
            # The mic is hard-stopped during TTS and restarted 2s after speech
            # ends (see _on_speaker_start / _on_speaker_done). No manual resume
            # here — that previously raced the restart and reopened the mic while
            # JARVIS was still talking. Keep a short cooldown as a belt-and-braces
            # guard against any stray transcription slipping through.
            self._command_cooldown_until = time.time() + 2.0
            self._start_auto_compact()

    def _start_auto_compact(self):
        """No-op: JARVIS now drops straight to STANDBY after inactivity (which
        shrinks the HUD), so the separate 'shrink but stay awake' step is gone."""
        return

    def _auto_compact(self):
        """Shrink HUD to compact pill after inactivity, but keep listening."""
        if not self.is_awake:
            return
        if self.speaker.is_speaking:
            # Restart timer — speaker still going
            self._auto_compact_timer.start(AUTO_COMPACT_SECONDS * 1000)
            return
        if not self.hud.is_compact():
            log("[JARVIS] Auto-compacting HUD (still listening)...")
            self.hud.shrink_to_compact()

    def _check_inactivity(self):
        """Put JARVIS to sleep after inactivity timeout (full standby)."""
        if not self.is_awake:
            return

        if self.speaker.is_speaking:
            self.last_activity_time = time.time()
            return

        # While the camera is intentionally ON, JARVIS stays ACTIVE so it never
        # auto-standbys and kills the vision. BUT if there's been no gesture or
        # command for VISION_AUTO_OFF_SECONDS, power the camera down on its own.
        if self.vision.is_running():
            if (time.time() - self._vision_last_activity) >= VISION_AUTO_OFF_SECONDS:
                self._auto_off_vision()
            else:
                self.last_activity_time = time.time()
            return

        # An open follow-up window is an explicit promise that JARVIS is still
        # listening, so it always outranks the inactivity countdown.
        if time.time() < self._follow_up_until:
            return

        elapsed = time.time() - self.last_activity_time
        if elapsed >= INACTIVITY_TIMEOUT_SECONDS:
            log(f"[JARVIS] Inactivity {elapsed:.0f}s >= {INACTIVITY_TIMEOUT_SECONDS}s -> to STANDBY")
            self._wake_intent = False  # after the spoken line, land in STANDBY
            self.bridge.response_signal.emit("Going to standby due to inactivity.")
            self.speaker.say(self._in_user_language("Standby mein ja raha hoon, Sir.",
                                                    "Going to standby, Sir."))
            self.bridge.sleep_signal.emit()

    def _auto_off_vision(self):
        """Power the camera down after inactivity, staying in normal listening."""
        log(f"[JARVIS] Vision idle {VISION_AUTO_OFF_SECONDS}s (no gesture/command) -> camera OFF")
        self.vision.stop()
        msg = self._in_user_language("Visual systems band kar raha hoon, Sir.",
                                     "Powering down visual systems, Sir.")
        self.bridge.response_signal.emit(msg)
        self.speaker.say(msg)
        # Stay ACTIVE and listening; resume the normal inactivity countdown.
        self.last_activity_time = time.time()
        self._vision_last_activity = time.time()

    # ── UI Callbacks ─────────────────────────────────

    def _on_wake_up(self, response_text: str, daddy: bool):
        """Handle wake up event: STANDBY -> ACTIVE (then a spoken greeting)."""
        self._wake_intent = True
        self.last_activity_time = time.time()
        self._auto_compact_timer.stop()
        self.state_machine.to(State.ACTIVE, "wake word detected")

        if daddy:
            # Dramatic bootup
            self.listener.pause()
            self.hud.play_bootup(callback=lambda: self._finish_wakeup(response_text))
        else:
            # Cinematic expand from compact to full
            self.hud.expand_to_full(callback=lambda: self._finish_wakeup(response_text))

    def _finish_wakeup(self, response_text: str):
        """Complete the wakeup sequence. The greeting's TTS hard-stops the mic and
        the 2s-after-done restart (in _on_speaker_done) re-enables it — no manual
        resume here, which previously raced and let JARVIS hear its own voice."""
        self.hud.set_state_listening()
        self.hud.set_response(response_text)
        self.speaker.say(response_text)
        log(f"[JARVIS] Awake: {response_text}")

    def _on_sleep(self):
        """Handle sleep event -- shrink to compact + enter standby.

        The actual STANDBY transition is driven by the speaker's on_done once
        the 'going to standby' line finishes (mic stays off while speaking).
        If nothing is being/about to be spoken, transition immediately.
        """
        self._wake_intent = False
        self._auto_compact_timer.stop()
        # A conversation that has ended has no follow-up window and no
        # half-answered question hanging over it.
        self._follow_up_until = 0.0
        self.dispatcher.clear_pending()
        # Never keep the camera running in the background once we leave ACTIVE.
        if self.vision.is_running():
            log("[JARVIS] Standby -> turning vision OFF")
            self.vision.stop()
        self.hud.set_command("")
        self.hud.set_response('Say "Hey JARVIS" to activate...')
        self.hud.shrink_to_compact()
        log("[JARVIS] Going to standby...")

        # Normal path: the 'going to standby' line drives ACTIVE -> SPEAKING ->
        # STANDBY via the speaker callbacks. Safety net: if no speech ends up
        # running, force STANDBY shortly after.
        def _ensure_standby():
            if not self.speaker.is_speaking and not self.state_machine.is_standby():
                self.state_machine.to(State.STANDBY, "sleep (no speech)")
        QTimer.singleShot(500, _ensure_standby)

    def _on_minimize_clicked(self):
        """Minimize button -- enter standby + shrink to compact."""
        log("[JARVIS] Minimize clicked -- entering standby...")
        msg = self._in_user_language("Standby mein ja raha hoon, Sir.",
                                     "Going to standby, Sir.")
        self.speaker.say(msg)
        self.bridge.response_signal.emit(msg)
        self.bridge.sleep_signal.emit()

    def _on_compact_clicked(self):
        """Compact pill clicked -- wake up JARVIS."""
        if not self.is_awake:
            log("[JARVIS] Compact pill clicked -- waking up...")
            self._wake_intent = True
            self.last_activity_time = time.time()
            self.state_machine.to(State.ACTIVE, "compact pill clicked")
            self.hud.expand_to_full(callback=lambda: self._finish_wakeup("Yes sir, I'm listening."))
        elif self.hud.is_compact():
            # Already awake but HUD is compact — just expand
            log("[JARVIS] Expanding HUD (already awake)...")
            self.hud.expand_to_full()
            self._auto_compact_timer.stop()
            self._start_auto_compact()

    def _on_command(self, text: str):
        """Display user command on HUD."""
        self.hud.set_command(text)

    def _on_response(self, text: str):
        """Display JARVIS response on HUD."""
        self.hud.set_response(text)

    def _on_state_change(self, state: str):
        """Update HUD state indicator."""
        if state == "standby":
            self.hud.set_state_standby()
        elif state == "listening":
            self.hud.set_state_listening()
        elif state == "processing":
            self.hud.set_state_processing()
        elif state == "speaking":
            self.hud.set_state_speaking()

    def _on_online_status(self, is_online: bool):
        """Update HUD online/offline indicator."""
        self.hud.set_online_status(is_online)

    def _on_iron_man_effect(self):
        """Trigger the Iron Man Easter egg HUD visual effect."""
        self.hud.play_iron_man_effect()

    def _check_api_status(self):
        """Check Gemini API availability and update HUD."""
        online = is_gemini_available()
        self.bridge.online_signal.emit(online)

    def _show_hud(self):
        """Show the HUD from tray."""
        self._on_compact_clicked()

    def _quit(self):
        """Shut down JARVIS."""
        log("[JARVIS] Shutting down...")
        self._auto_compact_timer.stop()
        self.vision.stop()
        if getattr(self, "preview", None) is not None:
            self.preview.hide()
        self.listener.stop()
        self.speaker.stop()
        self.reminder_manager.cancel_all()
        self.tray.hide()
        self.app.quit()


def main():
    """Entry point."""
    log("=" * 50)
    log("  J.A.R.V.I.S.")
    log("  Just A Rather Very Intelligent System")
    log("  v1.0 -- Windows Desktop Assistant")
    log("=" * 50)
    log("")

    try:
        jarvis = JarvisAssistant()
        jarvis.start()
    except Exception as e:
        log(f"[JARVIS] FATAL ERROR: {e}")
        import traceback
        traceback.print_exc()
        input("Press Enter to exit...")


if __name__ == "__main__":
    main()
