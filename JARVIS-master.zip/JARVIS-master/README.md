<p align="center">
  <img src="assets/screenshots/banner.png" alt="J.A.R.V.I.S. Banner" width="100%">
</p>

<h1 align="center">🔵 J.A.R.V.I.S.</h1>

<h3 align="center">Just A Rather Very Intelligent System</h3>

<p align="center">
  <em>A local Windows desktop AI assistant inspired by Tony Stark's AI —<br>natural-language voice control in English &amp; Hinglish, computer vision,<br>hand gestures, and a floating arc-reactor HUD.</em>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/python-3.10+-blue?style=for-the-badge&logo=python&logoColor=white" alt="Python">
  <img src="https://img.shields.io/badge/platform-Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white" alt="Windows">
  <img src="https://img.shields.io/badge/UI-PyQt6-41CD52?style=for-the-badge&logo=qt&logoColor=white" alt="PyQt6">
  <img src="https://img.shields.io/badge/STT-faster--whisper-FF6F00?style=for-the-badge&logo=openai&logoColor=white" alt="Whisper">
  <img src="https://img.shields.io/badge/Vision-MediaPipe-00A67E?style=for-the-badge&logo=google&logoColor=white" alt="MediaPipe">
  <img src="https://img.shields.io/badge/AI-Gemini-8E75B2?style=for-the-badge&logo=google&logoColor=white" alt="Gemini">
  <img src="https://img.shields.io/badge/license-MIT-green?style=for-the-badge" alt="License">
</p>

---

<p align="center">
  <img src="assets/screenshots/features.png" alt="Features" width="80%">
</p>

## ✨ Highlights

- 🗣️ **Say it however you want** — every command goes through intent detection, not a list of hardcoded phrases. *"Chrome khol do"*, *"open Chrome"*, *"browser open karo"* and *"Chrome chala do"* all do the same thing
- 🇮🇳 **English, Hindi & Hinglish** — speak whichever comes naturally, and JARVIS answers in the same language, in the matching voice
- 🧠 **It remembers** — *"JARVIS yaad rakh kal meeting hai"* now, *"meri meeting kab hai?"* next week
- 💬 **Follow-up conversation** — keeps listening for 15s after answering, so you don't repeat the wake word every time
- 👁️ **Computer vision** — face recognition, hand-gesture control, and "what do you see?" scene descriptions
- 🔊 **Robust audio** — WebRTC VAD + noise reduction for noisy rooms, automatic mic selection with live headset hot-swap
- 🎛️ **Push-to-talk & hotkeys** — hold `Ctrl+Space` to talk, `F5` to recalibrate
- 🪟 **Cinematic HUD** — always-on-top glassmorphism widget with a pulsing arc reactor
- 🔒 **Never goes deaf** — if the API is rate-limited or offline, an offline parser takes over automatically

---

## ⚡ Quick Start

### 1. Run Setup (installs everything)
```bash
python setup.py
```

### 2. Set Gemini API Key — powers intent detection, AI Q&A and vision
```bash
# Create a .env file in the project root
echo GEMINI_API_KEY=your-api-key-here > .env
```
> Get a free API key from [Google AI Studio](https://aistudio.google.com/apikey)
>
> Without a key JARVIS still runs — it falls back to the built-in offline parser, which handles every core command in English and Hinglish.

### 3. Launch JARVIS
```bash
python main.py
```
> On Windows you can also just double-click **`launch_jarvis.bat`**.

Then say **"Hey JARVIS"** and give a command. 🎤

---

## 🖥️ Interface

<p align="center">
  <img src="assets/screenshots/hud_screenshot.png" alt="JARVIS HUD Interface" width="400">
</p>

<p align="center"><em>Floating glassmorphism HUD with arc reactor animation and a live mic-level bar</em></p>

---

## 🗣️ Talk To It However You Want

Older versions matched your speech against a list of fixed phrases — say it slightly differently and nothing happened. That's gone. Every command is now parsed for **intent**, so wording, word order and language don't matter.

| You can say any of these… | …and JARVIS does |
|---|---|
| "Chrome khol do" · "open Chrome" · "browser open karo" · "Chrome chala do" | Opens Chrome |
| "time kya hua" · "kitne baje hain" · "what time is it" · "bhai time bata" | Tells the time |
| "PC lock kar" · "lock it down" · "sab band kar de" · "lock karo" | Locks the PC |
| "gaana laga do" · "music play kar" · "kuch suna do" · "play some music" | Plays music |
| "battery kitni hai" · "charge kitna hai" · "battery level" | Reports battery |

It also handles **vague references** and **incomplete commands**:

- *"open that music app"* → figures out you mean Spotify
- *"koi browser khol do"* → opens Chrome
- *"call karo"* → asks back *"Sir, kise call karna hai?"* instead of silently doing nothing

Every command prints its full pipeline to the terminal, so you can always see what it understood:

```
HEARD: kuch music laga do -> INTENT: play_music (confidence: 0.85) -> ACTION: opening Spotify   [gemini, 1042ms]
```

---

## 🔘 Wake Words

| Say This | JARVIS Responds |
|---|---|
| **"Hey JARVIS"** (or just "JARVIS") | "Yes sir, I'm listening." |
| **"JARVIS, are you there?"** | "Online and ready, sir. How can I assist?" |
| **"Daddy's home"** | *Dramatic HUD bootup animation* + "Welcome back, sir." |

Wake words use **fuzzy matching**, so common mis-hearings ("hey Travis", "Jervis", "Javis") still work, and so does "that is home", which is how Whisper usually hears "Daddy's home".

### Follow-Up Conversation
After JARVIS answers, it stays listening for **15 seconds** — ask the next thing straight away, no wake word needed:

> **You:** "Hey JARVIS" → **You:** "kitne baje hain?" → **You:** "aur aaj date kya hai?" → **You:** "what did I just ask?"

It keeps the **last 5 turns** of the session, so follow-ups like *"what did I just ask"* and *"tell me more about that"* have context.

### Sleep Commands
- "JARVIS, standby" · "That'll be all, JARVIS" · "Go to sleep" · "Good night JARVIS"
- Auto-sleeps after **30 seconds** of inactivity

---

## 🤖 What JARVIS Can Do

| Command | Example (any phrasing works) | Offline |
|---|---|:---:|
| 🕐 **Time & Date** | "kitne baje hain", "what's today's date?" | ✅ |
| 📂 **Open Apps** | "Chrome khol do", "open that music app" | ✅ |
| ❌ **Close Apps** | "Notepad band karo", "kill Chrome" | ✅ |
| 📊 **System Info** | "battery kitni hai", "CPU load?", "system kaisa chal raha hai" | ✅ |
| 🔒 **Lock / Shutdown / Restart** | "lock kar de", "PC band kar do", "restart karo" | ✅ |
| 🔍 **Web Search** | "search kar Noida weather" | ✅ |
| 🎵 **Play Music** | "gaana laga do", "kuch suna do" | ✅ |
| ⏰ **Reminders** | "10 minute baad paani peene ka reminder" | ✅ |
| 🔊 **Volume** | "volume badha do", "mute karo" | ✅ |
| 📸 **Screenshot** | "screenshot le lo" | ✅ |
| 🧠 **Memory** | "yaad rakh kal meeting hai", "meri meeting kab hai" | ✅ |
| 🌅 **Daily Briefing** | "good morning JARVIS", "morning briefing" | ⚙️ |
| 👁️ **Vision** | "camera open kar do", "mujhe dekho", "what do you see?", "camera band karo" | ⚙️ |
| 🎛️ **Mic Control** | "sensitivity badhao", "recalibrate", "change microphone" | ✅ |
| 💬 **Small Talk** | "tell me a joke", "kaise ho?" | ☁️ |
| 🧠 **AI Q&A** | Any question → Gemini ("India ki capital kya hai") | ☁️ |
| 🦾 **Easter Egg** | "I am Iron Man" → arc-reactor sequence | ✅ |

> **Legend:** ✅ = the action itself runs fully offline · ☁️ = needs internet · ⚙️ = partly (weather / scene descriptions need internet)
>
> Intent detection normally uses the API, but drops to the offline parser automatically when it's unavailable — so everything marked ✅ keeps working with no internet at all.

---

## 🧠 Memory & Profile

JARVIS keeps two small JSON files next to the code.

**`memory.json`** — things you told it to remember, kept across restarts:

```
You:    "JARVIS yaad rakh kal 5 baje meeting hai"
JARVIS: "Yaad rakh liya, Sir: kal 5 baje meeting hai."

(next week)
You:    "meri meeting kab thi?"
JARVIS: "Aapne bataya tha — kal 5 baje meeting hai, Sir."

You:    "JARVIS bhool ja meeting wali baat"
JARVIS: "Bhool gaya, Sir: kal 5 baje meeting hai."
```

Memory is searched **before** any API call, so anything you've already told JARVIS is answered instantly and costs zero quota. This file is git-ignored — it can hold private things like passwords.

**`profile.json`** — who you are, used naturally in replies:

```json
{
  "name": "Yatharth",
  "nickname": "Sir",
  "language": "Hinglish",
  "location": "Noida",
  "timezone": "Asia/Kolkata"
}
```

---

## 🌅 Daily Briefing

Say **"good morning JARVIS"** or **"morning briefing"**:

> *"Good morning, Sir, Yatharth. Abhi 8:15 AM baj rahe hain, aur aaj Friday, 28 August hai. Noida mein abhi 32 degrees hai, mostly clear, mehsoos 38 jaisa ho raha hai. Aaj ka high 34 aur low 26 degrees rahega, humidity 71 percent. Aapke paas 1 pending reminder hai: standup at 10:00 AM. Kaam aisa kijiye ki result khud bol de."*

Time, date, weather for your location, pending reminders, and something to start the day on. Weather comes from **Open-Meteo** — no key, no account, no signup.

---

## 🛡️ Confirmation Before Risky Actions

Lock, shutdown and restart never fire on the first command. JARVIS asks first and waits:

> **You:** "sab band kar de"
> **JARVIS:** "Sir, PC lock karne ja raha hoon. Confirm kar dein?"
> **You:** "haan" → *locks* · **"nahi"** → *cancels*

Say something unrelated instead and the pending action is quietly dropped — it won't fire later by surprise. Shutdown and restart are scheduled with a 10-second delay, so `shutdown /a` still saves you.

Once one of these runs, JARVIS goes to standby and turns the camera off. There's nobody at the keyboard to follow up with, and the mic should never stay live behind a lock screen.

---

## 👁️ Vision & Hand Gestures

The camera is **OFF by default** and only ever runs when you explicitly ask for it — it is never kept alive in the background, and auto-powers-down after 30s of no activity.

Turn it on with **"camera open kar do"** / **"mujhe dekho"** / **"turn on the camera"**. "Camera" always means JARVIS's own vision, never the Windows Camera app. Then:

- 🧑 **Face recognition** — greets you by name (owner enrolled locally) and flags unknown faces
- 🖐️ **Hand-gesture control** (hold a gesture ~1.5s):

| Gesture | Action |
|:---:|---|
| ✊ **Fist** | Lock the PC |
| ✌️ **Peace** | Tell a joke |
| 👍 **Thumbs up** | "Understood, sir." |
| ✋ **Open palm** | Turn the camera off |

- 🔎 **Scene description** — "What do you see?" captures a frame and describes it via Gemini Vision
- 🪟 A small **live camera preview** window (320×240, draggable, always-on-top) shows the annotated feed

---

## 🎤 Microphone Intelligence

- **Automatic selection** — prefers a connected headset (Bluetooth / wired / USB), otherwise the laptop mic. No prompts.
- **Live hot-swap** — plug in a headset while running and JARVIS announces *"Aapke headset par switch kar raha hoon, Sir."* (and back again on disconnect)
- **Hinglish-accurate transcription** — commands use Whisper `small` decoding as English, which returns Hinglish in romanized script; wake words use the faster `base` model so "Hey JARVIS" stays instant
- **Noise-robust** — WebRTC VAD + spectral noise reduction filter out background chatter, so it works even with music playing
- **Adaptive threshold** — auto-calibrates to ambient room noise; say **"sensitivity badhao"** to fine-tune live
- **Recalibrate on demand** — "JARVIS recalibrate" or press **`F5`** when you change rooms
- **Push-to-talk** — hold **`Ctrl+Space`**, speak, release — captures only while held (perfect for loud environments)

---

## 🔊 Voice

JARVIS answers in the language you spoke, and the voice follows the answer:

| You say | JARVIS answers | Voice |
|---|---|---|
| "what time is it" | *"It's 7:10 PM, Sir."* | `en-GB-RyanNeural` |
| "kitne baje hain" | *"Abhi 7:10 PM ho rahe hain, Sir."* | `en-IN-PrabhatNeural` |
| "open Chrome" | *"Opening Chrome, Sir."* | `en-GB-RyanNeural` |
| "screenshot le lo" | *"Screenshot le liya, Sir."* | `en-IN-PrabhatNeural` |

It's decided per utterance, so you can switch back and forth freely. A bare "okay" carries no language, so it keeps the language of the command it confirms. The rule covers everything JARVIS says: command replies, the briefing, weather, reminders, Gemini answers, and the standby and error lines.

`en-IN-PrabhatNeural` is deliberately chosen over a pure Hindi voice: it's an English-engine voice with an Indian accent, so it pronounces Hindi words properly while staying close enough to Ryan in timbre that the switch isn't jarring.

Want to hear the alternatives side by side?

```bash
python preview_voices.py
```

Then set `EDGE_TTS_VOICE_HI` in `config.py`, or `TTS_AUTO_SWITCH_VOICE = False` to use one voice for everything.

---

## 🎨 UI Features

- **Floating HUD** — Always-on-top dark glass widget in the corner
- **Arc Reactor** — Pulsing animation that glows brighter when listening
- **State indicators** — Standby (dim) / Listening (cyan) / Processing (amber) / Speaking (green)
- **Live mic-level bar** — green when your voice is above threshold, red when it's background noise
- **Draggable** — Click and drag to reposition
- **System Tray** — Minimize to tray, click to restore
- **Compact Mode** — Minimizes to a small floating pill

---

## ⚙️ Tech Stack

| Component | Technology |
|---|---|
| 🖼️ UI | PyQt6 (floating glassmorphism HUD) |
| 🎤 STT | **faster-whisper** (CTranslate2, int8 CPU) — `base` for wake words, `small` for commands |
| 🗣️ Speech detection | **WebRTC VAD** + **noisereduce** (spectral) for noisy rooms |
| 🧭 Intent parsing | **Gemini `2.5-flash-lite`** — JSON mode, thinking off, 100-token cap (~1s) |
| 🛟 Intent fallback | Hinglish-aware regex parser, fully offline |
| 🔊 TTS | **edge-tts** — `en-GB-RyanNeural` / `en-IN-PrabhatNeural`, picked per response |
| 👁️ Vision | **OpenCV** + **MediaPipe** (hand gestures) + **face_recognition** (dlib) |
| 🔎 Visual Q&A | **Google Gemini Vision** (`google-genai`, base64 image input) |
| 🧠 AI Q&A | **Google Gemini** with automatic multi-model fallback chain |
| 🌤️ Weather | **Open-Meteo** (keyless) |
| ⌨️ Hotkeys | **pynput** (global `Ctrl+Space`, `F5`) |
| 📊 System stats | psutil |
| 🔈 Audio | PyAudio (input) + pygame (output) |

---

## 📁 Project Structure

```
JARVIS/
├── main.py                 # Entry point & orchestrator (state machine, signals, UI)
├── config.py               # All configuration + system prompts
├── setup.py                # One-click installer
├── test_intents.py         # Pipeline test suite (100+ checks)
├── preview_voices.py       # Generate & compare TTS voices
├── requirements.txt        # Dependencies
├── launch_jarvis.bat       # Windows double-click launcher
├── .env                    # API key (not tracked)
├── memory.json             # What you asked JARVIS to remember (not tracked)
├── profile.json            # Your name, language, location
├── core/
│   ├── pipeline.py         # Fast path -> intent -> dispatch -> log
│   ├── fast_path.py        # Offline wake / standby / easter-egg checks (<0.1s)
│   ├── intent_engine.py    # Gemini intent parsing + offline fallback
│   ├── dispatcher.py       # Local execution, confirmations, clarifications
│   ├── memory_store.py     # memory.json, profile.json, session context
│   ├── command_router.py   # Offline Hinglish intent parser (the safety net)
│   ├── language.py         # Hindi/English detection for TTS voice choice
│   ├── listener.py         # PyAudio + WebRTC VAD + noisereduce + Whisper STT
│   ├── speaker.py          # edge-tts + robust playback / device recovery
│   ├── wake_word.py        # Wake word detection (fuzzy)
│   ├── mic_select.py       # Automatic mic selection + hot-swap
│   └── state_machine.py    # STANDBY / ACTIVE / SPEAKING states
├── skills/
│   ├── time_date.py        # Time & date
│   ├── app_control.py      # Open/close apps + vague-name resolution
│   ├── system_info.py      # CPU, RAM, battery, disk
│   ├── system_actions.py   # Screenshot, volume, shutdown, restart
│   ├── web_search.py       # Web search
│   ├── media.py            # Music playback
│   ├── reminders.py        # Timed reminders
│   ├── briefing.py         # Daily briefing
│   ├── weather.py          # Open-Meteo weather
│   ├── persona.py          # Hinglish response generation
│   ├── small_talk.py       # Jokes & banter
│   ├── lock_pc.py          # Lock the workstation
│   ├── easter_eggs.py      # "I am Iron Man" sequence
│   ├── vision.py           # Camera, face recognition, gestures, scene Q&A
│   └── gemini_ai.py        # Gemini client (multi-model chain)
├── ui/
│   ├── hud_widget.py       # Main floating HUD + mic-level bar
│   ├── animations.py       # Arc reactor + bootup
│   ├── styles.py           # QSS dark theme
│   ├── system_tray.py      # Tray icon
│   └── camera_preview.py   # Live annotated camera window
└── assets/
    ├── screenshots/        # README images
    └── sounds/             # Startup / arc-reactor sounds
```

---

## 🔧 Key Technical Details

### The Command Pipeline
Every utterance runs through the same five stages (`core/pipeline.py`):

1. **Offline fast path** — wake words, standby commands and easter eggs are matched locally in **under 0.1 ms**. These are time-sensitive and must never wait on a network round trip.
2. **Pending answer** — a "haan"/"nahi" to a confirmation, or the missing detail for a clarification. Also offline.
3. **Intent parsing** — the utterance goes to Gemini with the session context and known memories attached, and comes back as `{"intent": ..., "params": {...}, "confidence": ...}`.
4. **Local execution** — `core/dispatcher.py` performs the action on your machine. Only `general_question` and open-ended small talk ever go back to the network.
5. **Log & context** — one pipeline line to the terminal, and the turn is added to the rolling 5-turn session context.

Splitting the thinking (`core/`) from the mic, HUD and speaker (`main.py`) is what makes the whole pipeline testable without Qt or a working audio device.

### Never Goes Deaf
The intent call is tuned for speed: fastest model tier, thinking disabled, JSON response mode, 100-token ceiling — around **1 second** end to end. When it fails anyway (quota, overload, no internet), the request falls through a model chain and then to a **fully offline Hinglish parser** that handles Hindi word order (`X khol do`) as well as English (`open X`). A dead API costs you accuracy on unusual phrasings, not your core commands. After a failure the API is skipped entirely for 45s rather than making you wait through a doomed call every time.

### Audio Pipeline (noisy-room ready)
The listener uses **direct PyAudio recording** at 16 kHz, then:
1. **WebRTC VAD** (30 ms frames) gates on actual human speech, backed by an adaptive RMS threshold auto-tuned from ambient noise.
2. **noisereduce** applies spectral noise reduction before transcription.
3. **faster-whisper** (int8, all CPU cores) transcribes on CPU; empty/too-short/too-quiet clips are silently rejected so background noise never triggers a command.

### Two Speech Models
In standby JARVIS only needs to spot a wake word, so it listens with the fast `base` model (~0.7s). Once awake, the exact Hindi words matter, so commands go through `small` (~2.7s). Both stay loaded and swap on state changes. Decoding is forced to English on purpose: auto-detect flips to Hindi on Hinglish and returns Devanagari ("time kya hua" → "अई क्या हूँ?"), which nothing downstream can read. Measured on synthesized Hinglish commands, scored by correct intent:

| Model | Language | Correct |
|---|---|:---:|
| `small` | English | **21/21** |
| `base` | auto-detect | 18/21 |
| `small` | auto-detect | 18/21 |
| `base` | English | 17/21 |

### Anti Self-Talk Loop
When JARVIS speaks, the mic input stream is **physically stopped** (not just flagged), guarded by a shared speaking-lock and a `SPEAKING` state, then flushed and restarted ~1s after playback ends — so it never hears its own voice.

### TTS Output Recovery
If audio playback produces no sound (e.g. a disconnected Bluetooth output device is the system default), the mixer is **re-initialised on a real, connected output device** and the line is replayed. Engine health is printed at boot: `TTS engine status: OK`.

### State Machine
A three-state machine (**STANDBY → ACTIVE → SPEAKING**) is the single source of truth — no API calls or command routing ever happen in STANDBY.

---

## 🧪 Testing

```bash
python test_intents.py             # full suite, uses the API
python test_intents.py --offline   # forces the offline parser path
```

Runs the real pipeline over every phrasing in the tables above plus memory, briefing, follow-up conversation, confirmations, vague references, fast-path timing and voice routing. It also checks that the reply language follows you when you switch between English and Hindi, and has regression tests for bugs found in daily use (wake word mishearings, camera phrasings, standby after lock). Side effects are disabled — nothing is launched, nothing is locked.

```
✅  'Chrome khol do'      -> open_app     [gemini]   ACTION: opening Chrome
✅  'browser open karo'   -> open_app     [gemini]   ACTION: opening Chrome
✅  'kitne baje hain'     -> time         [gemini]   ACTION: telling the time
✅  'sab band kar de'     -> lock_pc      [gemini]   ACTION: awaiting confirmation for lock_pc
...
✅ passed: 109/109
```

---

## 🔒 Privacy

- **Offline by default** — speech recognition (Whisper) runs entirely on your machine
- **Memory stays local** — `memory.json` is git-ignored; it can hold private things you told JARVIS to remember
- **Camera is opt-in** — off by default, only runs on command, auto-off when idle
- **Biometric data stays local** — the enrolled owner face encoding (`assets/owner_face.npy`) is git-ignored and never leaves your PC
- **API key stays local** — the `.env` file is excluded from git
- **Answers you already gave never leave** — memory is checked before any API call
- **Only optional features use the internet** — intent parsing, AI Q&A, weather and scene descriptions

---

## 📜 License

This project is open source and available under the [MIT License](LICENSE).

---

<p align="center">
  <em>"Sometimes you gotta run before you can walk."</em> — Tony Stark
</p>
