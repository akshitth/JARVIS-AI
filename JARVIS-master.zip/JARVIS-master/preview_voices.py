"""
J.A.R.V.I.S. — Voice Preview

Voice choice is a matter of taste, and it has to be HEARD, not read. This
generates the same two JARVIS lines — one Hinglish, one English — in each
candidate voice and plays them back to back so you can pick.

    python preview_voices.py            # generate + play every candidate
    python preview_voices.py --no-play  # just write the mp3 files

Once you have picked, set EDGE_TTS_VOICE_EN in config.py to that voice name
and restart JARVIS.
"""

import asyncio
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import edge_tts

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "assets", "voice_samples")

# Male voices that can carry BOTH English and romanized Hindi in one timbre.
CANDIDATES = [
    ("en-IN-PrabhatNeural",
     "Indian English male - natural Hinglish, Indian accent  [RECOMMENDED]"),
    ("hi-IN-MadhurNeural",
     "Hindi male - most natural Hindi, but a heavy accent on English"),
    ("en-GB-RyanNeural",
     "British male - crisp English, but mangles Hindi words"),
    ("en-US-BrianMultilingualNeural",
     "Multilingual male - handles both, but American accent"),
]

# Real JARVIS responses, so the sample reflects what you will actually hear.
LINES = [
    ("hinglish", "Abhi 7 baj kar 20 minute ho rahe hain, Sir. "
                 "Chrome khol raha hoon. Battery 40 percent hai, "
                 "aur aapki meeting kal subah hai."),
    ("english", "All systems nominal, sir. And I am the voice behind the suit."),
]


async def _generate(voice: str, text: str, path: str):
    await edge_tts.Communicate(text, voice).save(path)


def generate_all() -> list[tuple[str, str, str]]:
    """Render every candidate. Returns [(voice, kind, path), ...]."""
    os.makedirs(OUT_DIR, exist_ok=True)
    made = []
    for voice, _description in CANDIDATES:
        for kind, text in LINES:
            path = os.path.join(OUT_DIR, f"{voice}__{kind}.mp3")
            try:
                asyncio.run(_generate(voice, text, path))
                made.append((voice, kind, path))
            except Exception as e:
                print(f"  ! {voice} ({kind}) failed: {e}")
    return made


def play(path: str):
    """Play one sample and block until it finishes."""
    import pygame
    if not pygame.mixer.get_init():
        pygame.mixer.init(frequency=24000, size=-16, channels=1, buffer=4096)
    pygame.mixer.music.load(path)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        time.sleep(0.05)
    pygame.mixer.music.unload()


def main():
    print("=" * 74)
    print("  J.A.R.V.I.S. — VOICE PREVIEW")
    print("=" * 74)
    print("\nGenerating samples...\n")
    made = generate_all()
    if not made:
        print("No samples generated — check your internet connection.")
        return 1
    print(f"Wrote {len(made)} samples to {OUT_DIR}\n")

    if "--no-play" in sys.argv:
        print("Open that folder and play them yourself (--no-play was passed).")
        return 0

    for voice, description in CANDIDATES:
        samples = [(k, p) for v, k, p in made if v == voice]
        if not samples:
            continue
        print(f"\n{'-' * 74}\n  {voice}\n  {description}\n{'-' * 74}")
        for kind, path in samples:
            print(f"    playing the {kind} line...")
            try:
                play(path)
            except Exception as e:
                print(f"    ! playback failed: {e}")
            time.sleep(0.4)

    print(f"\n{'=' * 74}")
    print("  Pick the one you liked, then in config.py set:")
    print('      EDGE_TTS_VOICE_EN = "<that voice name>"')
    print("  and restart JARVIS.")
    print("=" * 74)
    return 0


if __name__ == "__main__":
    sys.exit(main())
