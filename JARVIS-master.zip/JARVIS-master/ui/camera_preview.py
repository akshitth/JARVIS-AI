"""
J.A.R.V.I.S. — Camera Preview Window

A small (320x240), frameless, always-on-top, draggable window that shows the
live (annotated) camera feed while vision is active. It is shown when vision
turns on and hidden when vision turns off. Frames are pushed in from the main
thread (which polls VisionSystem.get_preview_frame on a timer).
"""

import numpy as np

from PyQt6.QtWidgets import QWidget, QLabel, QVBoxLayout, QApplication
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QImage, QPixmap

try:
    import cv2
    _CV2_OK = True
except Exception:
    _CV2_OK = False

PREVIEW_W, PREVIEW_H = 320, 240


class CameraPreview(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setWindowTitle("JARVIS Vision")
        self.setFixedSize(PREVIEW_W, PREVIEW_H)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self._label = QLabel("Vision starting…")
        self._label.setFixedSize(PREVIEW_W, PREVIEW_H)
        self._label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._label.setStyleSheet(
            "border: 2px solid #00E5FF; background-color: #000; color: #00E5FF;"
        )
        layout.addWidget(self._label)

        self._drag_pos = None
        self._move_to_bottom_left()

    def _move_to_bottom_left(self):
        screen = QApplication.primaryScreen()
        if screen:
            geo = screen.availableGeometry()
            self.move(geo.left() + 20, geo.bottom() - PREVIEW_H - 20)

    # ── Frame update ─────────────────────────────────
    def update_frame(self, bgr_frame):
        """Display a BGR (OpenCV) frame."""
        if bgr_frame is None or not _CV2_OK:
            return
        rgb = cv2.cvtColor(bgr_frame, cv2.COLOR_BGR2RGB)
        rgb = np.ascontiguousarray(rgb)
        h, w, ch = rgb.shape
        img = QImage(rgb.data, w, h, ch * w, QImage.Format.Format_RGB888).copy()
        pix = QPixmap.fromImage(img).scaled(
            PREVIEW_W, PREVIEW_H,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        self._label.setPixmap(pix)

    def show_preview(self):
        self._move_to_bottom_left()
        self.show()
        self.raise_()

    # ── Dragging ─────────────────────────────────────
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if self._drag_pos is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event):
        self._drag_pos = None
